import java.time.LocalDate;
import java.util.Scanner;

public class Validaciones {

    private Scanner scanner;

    //constructor
    public Validaciones(Scanner scanner) {
        this.scanner = scanner;
    }


    //Metodo para validar la fecha
    public String validarFecha() {
        // Instanciar un objeto de la clase Scanner para recibir datos
        Scanner scanner = new Scanner(System.in);
        String entrada;
        while (true) {
            entrada = scanner.nextLine();
            // Verificar si la fecha tiene el formato dd/mm/aaaa
            if (entrada.matches("^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/\\d{4}$")) {
                // Retornar la fecha si es válida
                return entrada;
            } else {
                System.out.println("Formato de fecha inválido! Ingresa la fecha en formato dd/mm/aaaa:");
            }
        }
    }

    //Metodo para confirmar la decisión del usuario
    public String confirmar_Decision(){

        Scanner scanner = new Scanner(System.in);
        String decision;
        System.out.println("\n ¿Desea guardar los cambios realizados?  (1: si  , 2: no)");
        do{
            decision = scanner.nextLine();
        }while(!decision.equals("1") && !decision.equals("2"));
        return decision;
    }

    //Metodo para validar que solo se ingresen números
    public String validarSoloNumeros() {
        Scanner scanner = new Scanner(System.in);
        String input;
        while (true) {
            input = scanner.nextLine();
            if (input.matches("\\d+")) {
                return input;
            } else {
                System.out.println("Solo se permiten números! Intente de nuevo:");
            }
        }
    }

    //Metodo para validar que solo se ingresen numeros positivos
    public  int validarNumeroPositivo() {
        Scanner scanner = new Scanner(System.in);
        int numero;
        while (true) {
            if (scanner.hasNextInt() && (numero = scanner.nextInt()) > 0) {
                return numero;
            }
            System.out.println("Ingresa un número válido mayor a 0:");
            scanner.next(); // Limpiar el buffer del scanner
        }
    }

    //Metodo para validar que solo se ingresen letras
    public String validarSoloLetras() {
        // Instanciar un objeto de la clase Scanner para recibir datos
        Scanner scanner = new Scanner(System.in);
        String entrada;
        while (true) {
            entrada = scanner.nextLine();
            // Verificar si la cadena contiene solo letras (incluyendo acentos y ñ)
            if (entrada.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ]+")) {
                // Retornar la cadena si es válida
                return entrada;
            } else {
                System.out.println("No es una entrada válida! Ingresa nuevamente:");
            }
        }
    }

    //Metodo para obtener la fecha actual
    public LocalDate fechaActual() {
        // Obtener la fecha actual (sin hora)
        return LocalDate.now();
    }

    // Metodo para validar contraseñas (entre 4 y 8 caracteres)
    public String validarContrasenia() {
        Scanner scanner = new Scanner(System.in);
        String contrasenia;
        while (true) {
            contrasenia = scanner.nextLine();
            if (contrasenia.matches(".{4,8}")) {
                return contrasenia;
            } else {
                System.out.println("La contraseña debe tener entre 4 y 8 caracteres. Intente de nuevo:");
            }
        }
    }

    // Función para borrar la pantalla después de presionar Enter
    public static void borrarPantalla(boolean lista) {
        try {
            // Siempre espera a que el usuario presione Enter
            System.out.println("Presiona Enter para continuar...");
            new Scanner(System.in).nextLine(); // Espera a que el usuario presione Enter

            // Borrar la pantalla
            if (System.getProperty("os.name").contains("Windows")) {
                // Comando para Windows
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                // Comando para Unix/Linux o macOS
                new ProcessBuilder("clear").inheritIO().start().waitFor();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
