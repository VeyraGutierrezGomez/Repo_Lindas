
/*
Programa para una Consulta medica. Donde existe un asistente, y un doctor;
El asistente gestiona la solicitud que genere el paciente, es decir, agenda la consulta,
modifica la conducta o cancela la conducta. Y también se encarga de registrar el pago
del paciente por la consulta. El doctor se encarga de analizar el
historial del paciente, y obviamente realiza la consulta para posteriormente realizar
la receta medica.

Un menu principal:

1. Asistente (dentro tendra el sub menu de agregar y lo demas)
2. Doctor (consultar)
3. Salir

*/

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

class Consultas {

    private List<Cita> citas;
    private List<Historial> historiales;
    private Scanner scanner;

    public Consultas(Scanner scanner) {
        this.citas = new ArrayList<>();
        this.historiales = new ArrayList<>();
        this.scanner = scanner;
    }

    public void agregarCita() {
        System.out.print("Ingrese el username del paciente: ");
        String username = scanner.nextLine();
        System.out.print("Ingrese la fecha de la cita (dd/mm/yyyy): ");
        String fecha = scanner.nextLine();
        System.out.print("Ingrese la hora de la cita: ");
        String hora = scanner.nextLine();
        citas.add(new Cita(username, fecha, hora));
        System.out.println("Cita agregada con éxito.");
    }

    public void modificarCita() {
        System.out.print("Ingrese el username de la cita a modificar: ");
        String username = scanner.nextLine();
        for (Cita cita : citas) {
            if (cita.username.equals(username)) {
                System.out.print("Ingrese la nueva fecha: ");
                cita.fecha = scanner.nextLine();
                System.out.print("Ingrese la nueva hora: ");
                cita.hora = scanner.nextLine();
                System.out.println("Cita modificada exitosamente.");
                return;
            }
        }
        System.out.println("Cita no encontrada.");
    }

    public void eliminarCita() {
        System.out.print("Ingrese el username de la cita a eliminar: ");
        String username = scanner.nextLine();
        citas.removeIf(cita -> cita.username.equals(username));
        System.out.println("Cita eliminada si existía.");
    }

    //doctor
    public void realizarConsulta() {
        System.out.print("Ingrese el username del paciente: ");
        String username = scanner.nextLine();
        Historial historial = buscarHistorial(username);

        System.out.print("Ingrese el peso del paciente: ");
        String peso = scanner.nextLine();
        System.out.print("Ingrese la altura del paciente: ");
        String altura = scanner.nextLine();
        System.out.print("¿Tiene alergias? (Sí/No): ");
        String alergias = scanner.nextLine();

        String consulta = "Peso: " + peso + ", Altura: " + altura + ", Alergias: " + alergias;
        if (historial == null) {
            historial = new Historial(username);
            historiales.add(historial);
            System.out.println("No había historial previo, se ha creado uno nuevo.");
        }
        historial.agregarConsulta(consulta);
        historial.mostrarHistorial();

        pagarConsulta();
    }

    public void pagarConsulta() {
        System.out.print("Ingrese el monto de la consulta: $");
        double monto = Double.parseDouble(scanner.nextLine());

        System.out.println("Seleccione método de pago: 1. Efectivo  2. Tarjeta");
        String metodo = scanner.nextLine();
        String pago = metodo.equals("1") ? "Efectivo" : "Tarjeta";

        System.out.println("¿Desea generar factura? (Sí/No): ");
        if (scanner.nextLine().equalsIgnoreCase("Sí")) {
            System.out.print("Ingrese RFC: ");
            String rfc = scanner.nextLine();
            System.out.print("Ingrese nombre o razón social: ");
            String nombre = scanner.nextLine();
            System.out.print("Ingrese dirección: ");
            String direccion = scanner.nextLine();

            double iva = monto * 0.16;
            double total = monto + iva;

            System.out.println("\nFactura generada:");
            System.out.println("-----------------------------");
            System.out.println("RFC: " + rfc);
            System.out.println("Nombre/Razón Social: " + nombre);
            System.out.println("Dirección: " + direccion);
            System.out.println("Monto: $" + monto);
            System.out.println("IVA (16%): $" + iva);
            System.out.println("Total a pagar: $" + total);
            System.out.println("Método de pago: " + pago);
            System.out.println("-----------------------------");
        } else {
            System.out.println("Pago realizado con " + pago + ". No se generó factura.");
        }
    }

    private Historial buscarHistorial(String username) {
        for (Historial historial : historiales) {
            if (historial.username.equals(username)) {
                return historial;
            }
        }
        return null;
    }

}


class Historial {
    String username;
    List<String> consultas;

    public Historial(String username) {
        this.username = username;
        this.consultas = new ArrayList<>();
    }

    public void agregarConsulta(String consulta) {
        consultas.add(consulta);
    }

    public void mostrarHistorial() {
        System.out.println("Historial de: " + username);
        for (String consulta : consultas) {
            System.out.println(consulta);
        }
    }
}

class Cita {
    String username;
    String fecha;
    String hora;

    public Cita(String username, String fecha, String hora) {
        this.username = username;
        this.fecha = fecha;
        this.hora = hora;
    }

    public String toString() {
        return "Usuario: " + username + ", Fecha: " + fecha + ", Hora: " + hora;
    }
}


public class Main {
    //Asistente
    public static void proceso_asistente(Scanner scanner, Consultas consulta) {
        Validaciones vali = new Validaciones(scanner);

        //variables:
        String seleccion_menu_asistente;

        System.out.println("\n \n ───────────");
        System.out.print("Ingrese el usuario: ");
        String usuario = scanner.nextLine();
        System.out.print("Ingrese la contraseña: ");
        String contrasenia = vali.validarContrasenia();

        //validar que la cuenta ingresada sea la del administrador
        if (usuario.equals("admin") && contrasenia.equals("admin")) {
            //el usuario si es administrador
            System.out.println("Ingreso exitoso.....");
            System.out.println(" ───────────");
        } else {
            System.out.println("Datos incorrectos");
            System.out.println("\n \n ───────────");
            return;
        }

        //
        do {
            Validaciones.borrarPantalla(false);
            System.out.println("\n\n\n");
            System.out.println("\t \t \t \t \t \t \t \t \t ────────────✧･ﾟ: *✧･ﾟ:* ⚕Astromedicine *:･ﾟ✧*:･ﾟ✧────────────");
            System.out.println("\t \t \t \t \t \t \t \t \t \t BIENVENID@ ASISTENTE ");
            System.out.println("\t \t \t \t \t \t \t \t ");
            System.out.println("\n ");
            System.out.println("Opciones disponibles: ");
            System.out.println("1. Agregar cita");
            System.out.println("2. Modificar cita");
            System.out.println("3. Eliminar cita");
            System.out.println("4. Salir");
            System.out.println("\n───────────");
            System.out.println("Selecciona una opción de las anteriores: ");
            seleccion_menu_asistente = scanner.nextLine();

            switch (seleccion_menu_asistente) {
                case "1":
                    //Gestionar Subgerentes
                    System.out.println("\n \n ───────────");
                    consulta.agregarCita();
                    System.out.println(" ───────────");
                    break;
                case "2":
                    //Gestionar Cuentas
                    consulta.modificarCita();
                    break;
                case "3":
                    //Gestionar SubCuentas
                    consulta.eliminarCita();
                    break;
                case "4":
                    //Salir
                    System.out.println("Cerrando sesión......");
                    System.out.println(" ───────────");
                    return;
                default:
                    System.out.println("Opcion inválida, intente de nuevo");
                    seleccion_menu_asistente = scanner.nextLine();
                    break;
            }
        } while (!seleccion_menu_asistente.equals("4"));
    }
    //Asistente
    public static void proceso_doctor(Scanner scanner, Consultas consulta) {

        Validaciones vali = new Validaciones(scanner);

        //variables:
        String seleccion_menu_doc;

        System.out.println("\n \n ───────────");
        System.out.print("Ingrese el usuario: ");
        String usuario = scanner.nextLine();
        System.out.print("Ingrese la contraseña: ");
        String contrasenia = vali.validarContrasenia();

        //validar que la cuenta ingresada sea la del administrador
        if (usuario.equals("doctor") && contrasenia.equals("doctor")) {
            //el usuario si es administrador
            System.out.println("Ingreso exitoso.....");
            System.out.println(" ───────────");
        } else {
            System.out.println("Datos incorrectos");
            System.out.println("\n \n ───────────");
            return;
        }

        //
        do {
            Validaciones.borrarPantalla(false);
            System.out.println("\n\n\n");
            System.out.println("\t \t \t \t \t \t \t \t \t ────────────✧･ﾟ: *✧･ﾟ:* ⚕Astromedicine *:･ﾟ✧*:･ﾟ✧────────────");
            System.out.println("\t \t \t \t \t \t \t \t \t \t BIENVENID@ DOCTOR ");
            System.out.println("\t \t \t \t \t \t \t \t ");
            System.out.println("\n ");
            System.out.println("Opciones disponibles: ");
            System.out.println("1. Realizar consulta médica");
            System.out.println("2. Salir");
            System.out.println("\n───────────");
            System.out.println("Selecciona una opción de las anteriores: ");
            seleccion_menu_doc = scanner.nextLine();

            switch (seleccion_menu_doc) {
                case "1":
                    //Gestionar Subgerentes
                    System.out.println("\n \n ───────────");
                    consulta.realizarConsulta();
                    System.out.println(" ───────────");
                    break;
                case "2":
                    //Salir
                    System.out.println("Cerrando sesión......");
                    System.out.println(" ───────────");
                    return;
                default:
                    System.out.println("Opcion inválida, intente de nuevo");
                    seleccion_menu_doc = scanner.nextLine();
                    break;
            }
        } while (!seleccion_menu_doc.equals("4"));
    }

    public static void main(String[] args) {
        //variables:
        String seleccion_menu_principal;
        Scanner scanner = new Scanner(System.in);
        Consultas consulta = new Consultas(scanner);
        Validaciones vali = new Validaciones(scanner);

        boolean salir = false;

        do {
            // Menú cuando hay usuarios registrados
            System.out.println("\n\n\n");
            System.out.println("\t \t \t \t \t \t \t \t \t ────────────✧･ﾟ: *✧･ﾟ:* ⚕Astromedicine *:･ﾟ✧*:･ﾟ✧────────────");
            System.out.println("\t \t \t \t \t \t \t \t ");
            System.out.println("\n ");
            System.out.println("Opciones disponibles: ");
            System.out.println("1. Asistente");
            System.out.println("2. Doctor");
            System.out.println("3. Salir");
            System.out.println("\n───────────");
            System.out.println("Selecciona una opción de las anteriores: ");

            seleccion_menu_principal = scanner.nextLine();

            switch (seleccion_menu_principal) {
                case "1":
                    // Entrar al banco
                    proceso_asistente(scanner, consulta);
                    break;
                case "2":
                    // Entrar al banco
                    proceso_doctor(scanner, consulta);
                    break;
                case "3":
                    // Salir
                    System.out.println("Bye.....");
                    salir = true;
                    break;
                default:
                    System.out.println("Opción inválida, intente de nuevo");
                    break;
            }
        } while (!salir);
    }
}










/*
Act4. Complemento de diagrama de cuarto completo
Act5 o Act 4.1 . Interfaz de cuarto netbins
Act 5 o 6. Sistema de cuyos
Act. 6 o 7. Clases herencia multinivel. Reino Animal
Act.7 0 8. Sistema de prestamos de libros
act 8 o 9. Programacion de la consulta medica.
 */
