/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package universo_micuarto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author veyra
 */
public class Muebles extends javax.swing.JFrame {
    
     private int nextId=1;
    private final String ARCHIVO="muebles.csv";
    
    DefaultTableModel dtm=new DefaultTableModel(){
        @Override
        public boolean isCellEditable(int row, int column){
            return false;
        }
    };
    
    private GestCategorias parentWindow;
    
    
    public Muebles(GestCategorias parent) {
        this.parentWindow = parent;
        initComponents();
        setLocationRelativeTo(null);
        String[] titulo = new String[]{"ID", "Nombre", "Estado"};
        dtm.setColumnIdentifiers(titulo);
        TablaMuebles.setModel(dtm);
        
        txtIdM.setEditable(false);
        cargarDatos();
        
        TablaMuebles.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
            @Override
            public void valueChanged(ListSelectionEvent e){
                int fila = TablaMuebles.getSelectedRow();
                if (fila >= 0) {
                    txtIdM.setText(dtm.getValueAt(fila, 0).toString());
                    txtNombreM.setText(dtm.getValueAt(fila, 1).toString());
                    txtEstadoM.setText(dtm.getValueAt(fila, 2).toString());
                }
            }
        });
    }

    /**
     * Creates new form Muebles
     */
    public Muebles() {
        initComponents();
        setLocationRelativeTo(null);
    String[] titulo= new String[]{"ID", "Nombre", "Estado"};
       dtm.setColumnIdentifiers(titulo);
       TablaMuebles.setModel(dtm);
    
       txtIdM.setEditable(false);

       cargarDatos();
       
       TablaMuebles.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
    
        @Override
        public void valueChanged(ListSelectionEvent e){
        int fila = TablaMuebles.getSelectedRow();
        if (fila >= 0) {
            txtIdM.setText(dtm.getValueAt(fila,0).toString());
            txtNombreM.setText(dtm.getValueAt(fila,1).toString());
            txtEstadoM.setText(dtm.getValueAt(fila,2).toString());
        }
       }
    });
    }
    
    void agregar(){
        dtm.addRow(new Object[]{
        nextId++, txtNombreM.getText(), txtEstadoM.getText()
        });
    }
    
    void eliminar(){
        int fila = TablaMuebles.getSelectedRow();        
        if (fila >= 0) {
            dtm.removeRow(fila);
            limpiarCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un mueble para eliminar.");
        }
    }
    
    void actualizar(){
        int fila = TablaMuebles.getSelectedRow(); 
        if (fila >= 0) {
            dtm.setValueAt(txtNombreM.getText(),fila, 1);
            dtm.setValueAt(txtEstadoM.getText(),fila, 2);
        limpiarCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un mueble para actualizar.");
        }
    }
    
    void limpiarCampos(){
    txtIdM.setText("");
    txtNombreM.setText("");
    txtEstadoM.setText("");
    TablaMuebles.clearSelection();
    }
    
     // Método para guardar los datos en un archivo CSV
    void guardarDatos() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ARCHIVO))) {
            int filas = dtm.getRowCount();
            int columnas = dtm.getColumnCount();
            for (int i = 0; i < filas; i++) {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < columnas; j++) {
                    sb.append(dtm.getValueAt(i, j));
                    if (j < columnas - 1) {
                        sb.append(","); // separador CSV
                    }
                }
                pw.println(sb.toString());
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar los datos: " + e.getMessage());
        }
    }
    
    // Método para cargar los datos desde un archivo CSV
    void cargarDatos() {
        File file = new File(ARCHIVO);
        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String linea;
                while ((linea = br.readLine()) != null) {
                    StringTokenizer st = new StringTokenizer(linea, ",");
                    Object[] fila = new Object[3];
                    int index = 0;
                    while (st.hasMoreTokens() && index < 3) {
                        fila[index++] = st.nextToken();
                    }
                    dtm.addRow(fila);
                    
                    // Actualizamos nextId para que siempre sea mayor que el último ID cargado
                    int idActual = Integer.parseInt(fila[0].toString());
                    if (idActual >= nextId) {
                        nextId = idActual + 1;
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error al cargar los datos: " + e.getMessage());
            }
        }
    }

    // Se sobrescribe el método dispose para guardar antes de cerrar la ventana
    @Override
    public void dispose() {
        guardarDatos();
        super.dispose();
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtEstadoM = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtIdM = new javax.swing.JTextField();
        BtnEliminar = new javax.swing.JButton();
        BtnModificar = new javax.swing.JButton();
        BtnIngresar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        BtnRegresar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaMuebles = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        txtNombreM = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        txtEstadoM.setBackground(new java.awt.Color(235, 248, 255));

        jLabel3.setFont(new java.awt.Font("Candara", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 65, 139));
        jLabel3.setText("Estado del Mueble");

        txtIdM.setBackground(new java.awt.Color(235, 248, 255));
        txtIdM.setText("Automatico");

        BtnEliminar.setFont(new java.awt.Font("Candara", 1, 12)); // NOI18N
        BtnEliminar.setForeground(new java.awt.Color(0, 50, 133));
        BtnEliminar.setText("Eliminar");
        BtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEliminarActionPerformed(evt);
            }
        });

        BtnModificar.setFont(new java.awt.Font("Candara", 1, 12)); // NOI18N
        BtnModificar.setForeground(new java.awt.Color(0, 50, 133));
        BtnModificar.setText("Actualizar");
        BtnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnModificarActionPerformed(evt);
            }
        });

        BtnIngresar.setFont(new java.awt.Font("Candara", 1, 12)); // NOI18N
        BtnIngresar.setForeground(new java.awt.Color(0, 50, 133));
        BtnIngresar.setText("Ingresar");
        BtnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnIngresarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Candara", 3, 30)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 55, 139));
        jLabel1.setText("--- Muebles ---");

        BtnRegresar.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        BtnRegresar.setForeground(new java.awt.Color(0, 55, 139));
        BtnRegresar.setText("<--");
        BtnRegresar.setBorder(null);
        BtnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRegresarActionPerformed(evt);
            }
        });

        jScrollPane1.setBackground(new java.awt.Color(232, 253, 255));

        TablaMuebles.setBackground(new java.awt.Color(224, 255, 255));
        TablaMuebles.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Estado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TablaMuebles);

        jLabel6.setFont(new java.awt.Font("Candara", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 65, 139));
        jLabel6.setText("ID del Mueble");

        txtNombreM.setBackground(new java.awt.Color(235, 248, 255));

        jLabel2.setFont(new java.awt.Font("Candara", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 65, 139));
        jLabel2.setText("Nombre del Mueble");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(txtIdM, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(txtNombreM, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(txtEstadoM, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(BtnRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(219, 219, 219)
                                .addComponent(jLabel1))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(129, 129, 129)
                                .addComponent(BtnIngresar)
                                .addGap(84, 84, 84)
                                .addComponent(BtnModificar)
                                .addGap(91, 91, 91)
                                .addComponent(BtnEliminar)))
                        .addGap(0, 128, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(BtnRegresar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtIdM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNombreM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtEstadoM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(27, 27, 27)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnIngresar)
                    .addComponent(BtnModificar)
                    .addComponent(BtnEliminar))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEliminarActionPerformed
        eliminar();
    }//GEN-LAST:event_BtnEliminarActionPerformed

    private void BtnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnModificarActionPerformed
        actualizar();
    }//GEN-LAST:event_BtnModificarActionPerformed

    private void BtnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnIngresarActionPerformed
        agregar();
    }//GEN-LAST:event_BtnIngresarActionPerformed

    private void BtnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRegresarActionPerformed
        this.setVisible(false);
        if(parentWindow != null){
        parentWindow.showFrame();
        }
    }//GEN-LAST:event_BtnRegresarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Muebles.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Muebles.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Muebles.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Muebles.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Muebles().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnEliminar;
    private javax.swing.JButton BtnIngresar;
    private javax.swing.JButton BtnModificar;
    private javax.swing.JButton BtnRegresar;
    private javax.swing.JTable TablaMuebles;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtEstadoM;
    private javax.swing.JTextField txtIdM;
    private javax.swing.JTextField txtNombreM;
    // End of variables declaration//GEN-END:variables
}
