import java.util.Scanner;

public class Main {
    //--------------------AGREGAR LIBROS-------------------------------------------------------------------------------------------------------------------------------------------------

            // Menú de libros
            public static void menuLibros() {
                System.out.println("**** LIBROS ****");
                System.out.println("1) Agregar libro");
                System.out.println("2) Lista de libros");
                System.out.println("3) Actualizar libro");
                System.out.println("4) Eliminar libro");
                System.out.println("5) Salir");
            }

            //Agregar libros
            public static void agregarLibro(String[][] libros, int c_libros, String[][] categorias, int c_categorias, String[][] editoriales, int c_editoriales) {
                Scanner scanner = new Scanner(System.in);

                // Verificar si alguna de las matrices está vacía (es decir, si no hay categorías, autores o editoriales registrados)
                if ((categorias[0][0] == null || categorias[0][0].isEmpty()) ||  (editoriales[0][0] == null || editoriales[0][0].isEmpty())) {
                    System.out.println("No se puede agregar un libro. Debe haber al menos una categoría, un autor y una editorial registrados.");
                    return;
                }

                //Solicito los datos del libro
                System.out.println("Vamos a llenar el registro:");

                //Solicictamos primero los datos para despues almacenarlos, si el usuario acepta
                System.out.print("Titulo: ");
                String titulo = scanner.nextLine();
                System.out.print("Año: ");
                String anio = scanner.nextLine();
                System.out.print("Idioma: ");
                String idioma = scanner.nextLine();
                System.out.print("Número de Páginas: ");
                String num_paginas = scanner.nextLine();

                //Seleccionar categorias
                System.out.println("Selecciona una o más Categorías. Ingresa '0' para finalizar.");
                listarCategorias(categorias, c_categorias);

                StringBuilder categoriasBuilder = new StringBuilder();
                int id_categoria;

                while (true) {
                    System.out.print("Ingresa el ID de la categoría (0 para terminar): ");
                    id_categoria = scanner.nextInt();
                    scanner.nextLine(); // Limpiar el buffer

                    if (id_categoria == 0) {
                        break; // Salir del ciclo si el usuario ingresa 0
                    }

                    // Verificar si el ID es válido
                    if (id_categoria < 1 || id_categoria > c_categorias || categorias[id_categoria - 1][1] == null) {
                        System.out.println("ID inválido. Inténtalo de nuevo.");
                        continue; // Volver a pedir el ID
                    }

                    // Agregar la categoría a la lista si aún no está agregada
                    String categoriaNombre = categorias[id_categoria - 1][1];
                    if (!categoriasBuilder.toString().contains(categoriaNombre)) {
                        if (!categoriasBuilder.isEmpty()) {
                            categoriasBuilder.append(", ");
                        }
                        categoriasBuilder.append(categoriaNombre);
                    } else {
                        System.out.println("La categoría ya fue seleccionada.");
                    }
                }
                // Almacenar las categorías en la matriz libros
                //Libros[i][6] = categoriasBuilder.toString();

                //--------------------LIBRO-AUTOR-------------------------------------------------------------------------

                //Seleccionar editorial
                System.out.print(" Selecciona una Editorial: \n");
                listarEditoriales(editoriales, c_editoriales);
                int id_editorial;
                do {
                    //Buscar la categoria seleccionada por ID
                    System.out.print("Ingresa el ID del editorial: ");
                    id_editorial = scanner.nextInt();
                    scanner.nextLine(); // borrar buffer

                    // Verificar si el ID es válido
                }while(id_editorial < 1 || id_editorial > c_editoriales || editoriales[id_editorial - 1][1] == null);
                // Almacenar el nombre de la categoría en la matriz libros
                String editorial = editoriales[id_editorial - 1][1];

                //------------------------------------------------------------------------------------------------------------
                System.out.println("Esta seguro de guardar los siguientes datos? ( 1. Si / 2. No)");
                int selec = scanner.nextInt();
                //Dependiendo la selecciona, se guarda o se retorna
                if (selec == 1){
                    //Utilizo el string value, para cambiar el tipo de dato de "c" al ID
                    libros[c_libros][0] = String.valueOf(c_libros + 1);
                    libros[c_libros][1] = titulo;
                    libros[c_libros][3] = anio;
                    libros[c_libros][4] = idioma;
                    libros[c_libros][5] = num_paginas;
                    libros[c_libros][6] = categoriasBuilder.toString();
                    libros[c_libros][7] = editorial;

                }else {
                    System.out.println("Se cancelo la operación.");
                    return;
                }
                //Banner de exito
                System.out.println("Libro agregado exitosamente.");
            }

            //Consultas para listar para el libro
            public static void listarLibros(String[][] libros, int c_libros) {
                //Utilizo una varibale boleana para determina si se encontro libro al imprimir
                //se inicializa en false
                boolean encontroLibros = false;
                //Se imprime hasta que sea menor que el contador ya que inicia en 0
                for (int i = 0; i < c_libros; i++) {
                    //se pregunta si el campo es distinto de nulo y si el campo no esta vacio
                    if (libros[i][1] != null && !libros[i][1].isEmpty()) {
                        //imprime los datos del registro
                        System.out.println("ID: " + libros[i][0] + ", Titulo: " + libros[i][1] + ", Año: " + libros[i][3] + ", Idioma: " + libros[i][4] + ", No. Páginas: " + libros[i][5] + ", Categoría: " + libros[i][6] + ", Editorial: " + libros[i][7] );
                        //se cambia la variable a verdadera
                        encontroLibros = true;
                    }
                }
                //si al no encontrarse es false, entonces no hay libros por mostrar
                if (!encontroLibros) {
                    System.out.println("No hay libros registrados.");
                }
            }

            public static void consultarLibroPorID(String[][] libros, int c_libros, int id) {
                for (int i = 0; i < c_libros; i++) {
                    if (Integer.parseInt(libros[i][0]) == id) {
                        System.out.println("Libro encontrado: " + libros[i][1]);
                        return;
                    }
                }
                System.out.println("Libro no encontrado.");
            }

            public static void consultarLibroPorNombre(String[][] libros, int c_libros, String nombre) {
                for (int i = 0; i < c_libros; i++) {
                    if (libros[i][1].toLowerCase().contains(nombre.toLowerCase())) {
                        System.out.println("Libro encontrado: " + libros[i][1]);
                    }
                }
            }

            public static void consultarLibroPorCategorias(String[][] categorias, int c_categorias, String categoria) {
                for (int i = 0; i < c_categorias; i++) {
                    if (categorias[i][1].toLowerCase().contains(categoria.toLowerCase())) {
                        System.out.println("Libro encontrado: " + categorias[i][1]);
                    }
                }
            }

            public static void consultarLibroPorAutor(String[][] libros, int c_libros, String autor) {
                for (int i = 0; i < c_libros; i++) {
                    if (libros[i][3].toLowerCase().contains(autor.toLowerCase())) {
                        System.out.println("Libro encontrado: " + libros[i][1]);
                    }
                }
            }

            public static void consultarLibroPorEditorial(String[][] libros, int c_libros, String editorial) {
                for (int i = 0; i < c_libros; i++) {
                    if (libros[i][4].toLowerCase().contains(editorial.toLowerCase())) {
                        System.out.println("Libro encontrado: " + libros[i][1]);
                    }
                }
            }

            //Actualizar registro
            public static void actualizarLibro(String[][] libros, int id, int c_libros, String[][] categorias, int c_categorias, String[][] editoriales, int c_editoriales) {
                Scanner scanner = new Scanner(System.in);

                //Comparo si el id es menor a uno o mayor al contador o esta en nulo
                //entonces no existe el libro
                if (id < 1 || id > c_libros || libros[id - 1][1] == null) {
                    System.out.println("No existe libro.");
                    return;
                }

                String titulo = libros[id - 1][1];
                String anio = libros[id - 1][2];
                String idioma = libros[id - 1][3];
                String num_paginas = libros[id - 1][4];
                String categorias_save = libros[id - 1][5];
                String editorial = libros[id - 1][6];


                //Solicitamos los datos por si se quieren actualizar
                System.out.println("Actualizar datos del libro " + id + ":");
                System.out.print("Titulo: ");
                String titulo_2 = scanner.nextLine();
                if (libros[id - 1][1].isBlank()) {
                    libros[id - 1][1] = titulo;
                }

                System.out.print("Año: ");
                String anio_2 = scanner.nextLine();
                if (libros[id - 1][2].isBlank()) {
                    libros[id - 1][2] = anio;
                }

                System.out.print("Idioma: ");
                String idioma_2 = scanner.nextLine();
                if (libros[id - 1][3].isBlank()) {
                    libros[id - 1][3] = idioma;
                }

                System.out.print("Número de paginas: ");
                String num_paginas_2 = scanner.nextLine();
                if (libros[id - 1][4].isBlank()) {
                    libros[id - 1][4] = num_paginas;
                }

                //Actualizar las categorias
                System.out.println("¿Deseas editar las categorías? (1.Si / 2.No)");

                int opcion;
                StringBuilder categoriasBuilder = new StringBuilder(categorias_save);

                do{
                     // Inicializar con categorías previas
                    opcion = scanner.nextInt();
                    if(opcion == 1){
                        System.out.println("Selecciona una o más Categorías. Ingresa '0' para finalizar.");
                        listarCategorias(categorias, c_categorias);

                        int id_categoria;

                        while (true) {
                            System.out.print("Ingresa el ID de la categoría (0 para terminar): ");
                            id_categoria = scanner.nextInt();
                            scanner.nextLine(); //Limpiar el buffer

                            if (id_categoria == 0) {
                                break; //salir del ciclo si se ingresa 0
                            }

                            //verificar si el id es válido
                            if (id_categoria < 1 || id_categoria > c_categorias || categorias[id_categoria - 1][1] == null) {
                                System.out.println("ID inválido. Inténtalo de nuevo.");
                                continue; //volver a pedir el id
                            }

                            //agregar la categoría a la lista si aún no está agregada
                            String categoriaNombre = categorias[id_categoria - 1][1];
                            if (!categoriasBuilder.toString().contains(categoriaNombre)) {
                                if (!categoriasBuilder.isEmpty()) {
                                    categoriasBuilder.append(", ");
                                }
                                categoriasBuilder.append(categoriaNombre);
                            } else {
                                System.out.println("La categoría ya fue seleccionada.");
                            }

                        }

                    }

                    if(opcion == 2){
                        System.out.println("No se realizaron cambios");
                        libros[id - 1][5] = categorias_save;
                    }

                }while (opcion > 2 || opcion < 0);

                //actualizar editorial
                System.out.print(" Selecciona una Editorial: \n");
                listarEditoriales(editoriales, c_editoriales);
                int id_editorial;
                //Buscar la categoria seleccionada por ID
                System.out.print("Ingresa el ID de la categoría: ");
                id_editorial = scanner.nextInt();
                scanner.nextLine(); // borrar buffer
                // Verificar si el ingreso ID
                if (String.valueOf(id_editorial).isBlank()) {
                    libros[id - 1][6] = editorial;
                }

                System.out.println("Esta seguro de guardar los siguientes datos? ( 1. Si / 2. No)");
                int selec = scanner.nextInt();
                //Dependiendo la seleccion, se guarda o se retorna
                if (selec == 1){
                    //Utilizo el string value, para cambiar el tipo de dato de "c" al ID
                    libros[id - 1][1] = titulo_2;
                    libros[id - 1][2] = anio_2;
                    libros[id - 1][3] = idioma_2;
                    libros[id - 1][4] = num_paginas_2;
                    libros[id - 1][5] = categoriasBuilder.toString();
                    libros[id - 1][6] = editoriales[id_editorial - 1][1];

                }else {
                    System.out.println("Se cancelo la operación.");
                    return;
                }

                System.out.println("Libro actualizado exitosamente.");
            }

            //Accion libro-autor
            public static void accionLibroAutor(String[][] libros, int c_libros, String[][] autorEditor, int c_autorEditor, String[][] libroAutor, int c_autorLibro){
                Scanner scanner = new Scanner(System.in);
                System.out.println("Seleccione un libro:");
                listarLibros(libros, c_libros);

                System.out.print("Ingrese el número de fila del libro en la matriz: ");
                int filaLibro = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea

                if (filaLibro < 0 || filaLibro > c_libros) {
                    System.out.println("Selección inválida.");
                    return;
                }

                System.out.println("\nSeleccione un Autor-Editorial:");
                listarAutoresEditoriales(autorEditor, c_autorEditor);

                System.out.print("Ingrese el número de fila del Autor-Editorial en la matriz: ");
                int filaAutorEditorial = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea

                if (filaAutorEditorial < 0 || filaAutorEditorial > c_autorEditor) {
                    System.out.println("Selección inválida.");
                    return;
                }

                // Verificar si la editorial del libro coincide con la editorial del autor
                if (libros[filaLibro-1][4].equals(autorEditor[filaAutorEditorial-1][1])) {
                    libroAutor[c_autorLibro][0] = String.valueOf(c_autorLibro);
                    libroAutor[c_autorLibro][1] = autorEditor[filaAutorEditorial-1][0]; //Autor
                    libroAutor[c_autorLibro][2] = libros[filaLibro-1][0]; //ID del Libro
                    c_autorLibro++;
                    System.out.println("Relación Autor - Libro guardada exitosamente.");
                } else {
                    System.out.println("El autor no pertenece a la editorial del libro.");
                }
            }

            // Borrar registro
            public static void borrarLibros(String[][] libros, int id, int c_libros) {
                //al igual que el proceso de actualizar
                //valido si existe el id, si no no existe
                if (id < 1 || id > c_libros || libros[id - 1][1] == null) {
                    System.out.println("No existe libro.");
                    return;
                }

                //Borro los campo del registro
                libros[id - 1][0] = null;
                libros[id - 1][1] = null;
                libros[id - 1][2] = null;
                libros[id - 1][3] = null;
                libros[id - 1][4] = null;
                libros[id - 1][5] = null;
                libros[id - 1][6] = null;
                libros[id - 1][7] = null;

                System.out.println("Libro eliminado exitosamente.");
            }
    //--------------------FIN LIBROS------------------------------------------------------------------------------------------------------------------------------------------------

    //--------------------EDITORIALES------------------------------------------------------------------------------------------------------------------------------------------------

            // Menú de las editoriales
            public static void menuEditorial() {
                System.out.println("**** EDITORIAL ****");
                System.out.println("1) Agregar editorial");
                System.out.println("2) Lista de editoriales");
                System.out.println("3) Actualizar editorial");
                System.out.println("4) Eliminar editorial");
                System.out.println("5) Salir");
            }

            // Llenado del registro
            public static void agregarEditorial(String[][] editoriales, int c_editoriales) {
                Scanner scanner = new Scanner(System.in);

                System.out.print("Nombre de la Editorial: ");
                String nombre = scanner.nextLine();
                System.out.print("Ubicación: ");
                String ubi = scanner.nextLine();
                System.out.print("Correo: ");
                String email = scanner.nextLine();
                System.out.print("RFC: ");
                String RFC = scanner.nextLine();

                System.out.println("Esta seguro de guardar los siguientes datos? ( 1. Si / 2. No)");
                int selec = scanner.nextInt();
                //Dependiendo la selecciona, se guarda o se retorna
                if (selec == 1){
                    //Utilizo el string value, para cambiar el tipo de dato de "c" al ID
                    editoriales[c_editoriales][0] = String.valueOf(c_editoriales+ 1);
                    editoriales[c_editoriales][1] = nombre;
                    editoriales[c_editoriales][2] = ubi;
                    editoriales[c_editoriales][3] = email;
                    editoriales[c_editoriales][4] = RFC;

                }else {
                    System.out.println("Se cancelo la operación.");
                    return;
                }

                //Banner de exito
                System.out.println("Editorial agregada exitosamente.");
            }

            // Actualizar registro
            public static void actualizarEditorial(String[][] editoriales, int id, int c_editoriales) {
                Scanner scanner = new Scanner(System.in);

                //Comparo si el id es menor a uno o mayor al contador o esta en nulo
                //entonces no existe la editorial
                if (id < 1 || id > c_editoriales || editoriales[id - 1][1] == null) {
                    System.out.println("No existe editorial.");
                    return;
                }

                String editorial = editoriales[id - 1][1];
                String ubicacion = editoriales[id - 1][2];
                String correo = editoriales[id - 1][3];
                String RFC = editoriales[id - 1][4];


                //Solicitamos los datos por si se quieren actualizar
                System.out.println("Actualizar la editorial del id " + id + ":");

                System.out.print("Nombre ("+ editoriales[id-1][1]+"): ");
                String nombre_2 = scanner.nextLine();
                if (editoriales[id - 1][1].isBlank()) {
                    editoriales[id - 1][1] = editorial;
                }
                System.out.print("Ubicacion ("+ editoriales[id-1][2]+"): ");
                String ubi_2= scanner.nextLine();
                if (editoriales[id - 1][2].isBlank()) {
                    editoriales[id - 1][2] = ubicacion;
                }
                System.out.print("Correo ("+ editoriales[id-1][3]+"): ");
                String email_2 = scanner.nextLine();
                if (editoriales[id - 1][3].isBlank()) {
                    editoriales[id - 1][3] = correo;
                }
                System.out.print("RFC ("+ editoriales[id-1][4]+"): ");
                String RFC_2= scanner.nextLine();
                if (editoriales[id - 1][4].isBlank()) {
                    editoriales[id - 1][4] = RFC;
                }

                System.out.println("Esta seguro de guardar los siguientes datos? ( 1. Si / 2. No)");
                int selec = scanner.nextInt();
                //Dependiendo la selecciona, se guarda o se retorna
                if (selec == 1){
                    //Utilizo el string value, para cambiar el tipo de dato de "c" al ID
                    editoriales[c_editoriales][1] = nombre_2;
                    editoriales[c_editoriales][2] = ubi_2;
                    editoriales[c_editoriales][3] = email_2;
                    editoriales[c_editoriales][4] = RFC_2;

                }else {
                    System.out.println("Se cancelo la operación.");
                    return;
                }

                System.out.println("Editorial actualizada exitosamente.");
            }

            // Mostrar la lista de editoriales
            public static void listarEditoriales(String[][] editoriales, int c_editoriales) {
                //Utilizo una varibale boleana para determina si se encontro una editorial al imprimir
                //se inicializa en false
                boolean encontroEditorial = false;
                //Se imprime hasta que sea menor que el contador ya que inicia en 0
                for (int i = 0; i < c_editoriales; i++) {
                    //se pregunta si el campo es distinto de nulo y si el campo no esta vacio
                    if (editoriales[i][1] != null && !editoriales[i][1].isEmpty()) {
                        //imprime los datos del registro
                        System.out.println("ID: " + editoriales[i][0] + ", Nombre: " + editoriales[i][1] + ", Ubicación: " + editoriales[i][2] + ", Correo: " + editoriales[i][3] + ", Razón Social: " + editoriales[i][4] + ". ");
                        //se cambia la variable a verdadera
                        encontroEditorial = true;
                    }
                }
                //si al no encontrarse es false, entonces no hay editoriales por mostrar
                if (!encontroEditorial) {
                    System.out.println("No hay editoriales registradas.");
                }
            }

            // Borrar registro - logico ??
            public static void borrarEditorial(String[][] editoriales, int id, int c_editoriales) {
                //al igual que el proceso de actualizar
                //valido si existe el id, si no no existe
                if (id < 1 || id > c_editoriales || editoriales[id - 1][1] == null) {
                    System.out.println("No existe editorial.");
                    return;
                }

                //Borro los campo del registro - borrado logico ?
                editoriales[id - 1][1] = null;
                editoriales[id - 1][2] = null;
                editoriales[id - 1][3] = null;
                editoriales[id - 1][4] = null;



                System.out.println("Editorial eliminada exitosamente.");
            }

    //------------------- FIN EDITORIALES-------------------------------------------------------------------------------------------------------

    //--------------------CATEGORIAS------------------------------------------------------------------------------------------------------------------------------------------------

            // Menú de categorias
            public static void menuCategoria() {
                System.out.println("**** CATEGORIAS ****");
                System.out.println("1) Agregar categoría");
                System.out.println("2) Lista de categorías");
                System.out.println("3) Actualizar categoria");
                System.out.println("4) Eliminar categoria");
                System.out.println("5) Salir");
            }

            // Llenado del registro
            public static void agregarCategoria(String[][] categorias, int c_categoria) {
                Scanner scanner = new Scanner(System.in);

                System.out.print("Nombre de la categoria: ");
                String nombre = scanner.nextLine();

                System.out.println("Esta seguro de guardar los siguientes datos? ( 1. Si / 2. No)");
                int selec = scanner.nextInt();
                //Dependiendo la selecciona, se guarda o se retorna
                if (selec == 1){
                    //Utilizo el string value, para cambiar el tipo de dato de "c" al ID
                    categorias[c_categoria][0] = String.valueOf(c_categoria + 1);
                    categorias[c_categoria][1] = nombre;

                }else {
                    System.out.println("Se cancelo la operación.");
                    return;
                }

                //Banner de exito
                System.out.println("Categoria agregada exitosamente.");
            }

            // Actualizar registro
            public static void actualizarCategoria(String[][] categorias, int id, int c_categoria) {
                Scanner scanner = new Scanner(System.in);

                //Comparo si el id es menor a uno o mayor al contador o esta en nulo
                //entonces no existe la categoria
                if (id < 1 || id > c_categoria || categorias[id - 1][1] == null) {
                    System.out.println("No existe categoria.");
                    return;
                }

                String categoria = categorias[id - 1][1];

                //Solicitamos los datos por si se quieren actualizar
                System.out.println("Actualizar categoria del id " + id + ":");
                System.out.print("Categoria ("+ categorias[id-1][1]+"): ");
                String categoria_2 = scanner.nextLine();

                System.out.println("Esta seguro de guardar los siguientes datos? ( 1. Si / 2. No)");
                int selec = scanner.nextInt();
                //Dependiendo la selecciona, se guarda o se retorna
                if (selec == 1){
                    //Utilizo el string value, para cambiar el tipo de dato de "c" al ID
                    categorias[c_categoria][1] = categoria_2;
                    if (categoria_2.isBlank()) {
                        categorias[id - 1][1] = categoria;
                    }else{
                        categorias[id - 1][1] = categoria_2;
                    }

                }else {
                    System.out.println("Se cancelo la operación.");
                    return;
                }


                System.out.println("Categoria actualizada exitosamente.");
            }

            // Mostrar la lista de categorias
            public static void listarCategorias(String[][] categorias, int c_categoria) {
                //Utilizo una varibale boleana para determina si se encontro una categoria al imprimir
                //se inicializa en false
                boolean encontroCategoria = false;
                //Se imprime hasta que sea menor que el contador ya que inicia en 0
                for (int i = 0; i < c_categoria; i++) {
                    //se pregunta si el campo es distinto de nulo y si el campo no esta vacio
                    if (categorias[i][1] != null && !categorias[i][1].isEmpty()) {
                        //imprime los datos del registro
                        System.out.println(categorias[i][0] + ". " + categorias[i][1] + ". ");
                        //se cambia la variable a verdadera
                        encontroCategoria = true;
                    }
                }
                //si al no encontrarse es false, entonces no hay categorias por mostrar
                if (!encontroCategoria) {
                    System.out.println("No hay categorias registradas.");
                }
            }

            // Borrar registro
            public static void borrarCategoria(String[][] categorias, int id, int c_categoria) {
                //al igual que el proceso de actualizar
                //valido si existe el id, si no no existe
                if (id < 1 || id > c_categoria || categorias[id - 1][1] == null) {
                    System.out.println("No existe categoria.");
                    return;
                }

                //Borro los campo del registro
                categorias[id - 1][1] = null;

                System.out.println("Categoria eliminada exitosamente.");
            }


    //--------------------FIN CATEGORIAS------------------------------------------------------------------------------------------------------------------------------------------------

    //--------------------AUTORES------------------------------------------------------------------------------------------------------------------------------------------------

            // Menú de los autores
            public static void menuAutores() {
                System.out.println("**** AUTORES ****");
                System.out.println("1) Agregar autores");
                System.out.println("2) Lista de autores");
                System.out.println("3) Actualizar autor");
                System.out.println("4) Eliminar autor");
                System.out.println("5) Salir");
            }

            // Llenado del registro
            public static void agregarAutor(String[][] autores, int c_autores, String[][] editoriales, int c_editoriales, String[][] autorEditor, int c_autorEditor) {
                Scanner scanner = new Scanner(System.in);

                if (c_editoriales == 0) {
                    System.out.println("Al menos una editorial debe estar registrada antes de agregar un autor");
                    return;
                }

                //Utilizo el string value, para cambiar el tipo de dato de "c" al ID
                String id = String.valueOf(c_autores + 1);
                System.out.print("Nombre del autor: ");
                String nombreAutor = scanner.nextLine();
                System.out.print("Fecha de nacimiento: ");
                String fecha = scanner.nextLine();
                System.out.print("Nacionalidad: ");
                String nacionality = scanner.nextLine();
                System.out.print("Correo: ");
                String email = scanner.nextLine();


                //--------------------EDITORIAL-AUTOR-------------------------------------------------------------------------
                System.out.println("Cuantas editoriales tiene el autor ");
                int numEditoriales;
                do {
                    numEditoriales = scanner.nextInt();
                    scanner.nextLine(); //Limpiar buffer
                    if (numEditoriales < 1 || numEditoriales > c_editoriales) {
                        System.out.println("Cantidad inválida.");
                    }
                } while (numEditoriales < 1 || numEditoriales > c_editoriales);

                for (int i = 0; i < numEditoriales; i++) {
                    System.out.println("Seleccione la editorial " + (i + 1) + " para el autor " + nombreAutor + ":");
                    for (int j = 0; j < c_editoriales; j++) {
                        System.out.println((j + 1) + ") " + editoriales[j][1]); //Mostrar editoriales disponibles
                    }

                    int editorialIndex;
                    do {
                        editorialIndex = scanner.nextInt();
                        editorialIndex = editorialIndex - 1;
                        scanner.nextLine(); //Limpiar buffer
                        if (editorialIndex < 0 || editorialIndex >= c_editoriales) {
                            System.out.println("Selección inválida. Intente nuevamente.");
                        }
                    } while (editorialIndex < 0 || editorialIndex >= c_editoriales);

                    System.out.println("Esta seguro de guardar los siguientes datos? ( 1. Si / 2. No)");
                    int selec = scanner.nextInt();
                    //Dependiendo la selecciona, se guarda o se retorna
                    if (selec == 1) {
                        //Utilizo el string value, para cambiar el tipo de dato de "c" al ID
                        autores[c_autores][0] = id;
                        autores[c_autores][1] = nombreAutor;
                        autores[c_autores][2] = fecha;
                        autores[c_autores][3] = nacionality;
                        autores[c_autores][4] = email;

                        // Guardar en la matriz de Autor-Editorial
                        autorEditor[c_autorEditor][0] = String.valueOf(c_autorEditor); // ID relación
                        autorEditor[c_autorEditor][1] = nombreAutor;
                        autorEditor[c_autorEditor][2] = editoriales[editorialIndex][1]; // Nombre de la editorial
                        c_autorEditor++;
                    } else {
                        System.out.println("Se cancelo la operación.");
                        return;
                    }
                }
            }

            // Actualizar registro
            public static void actualizarAutor(String[][] autores, int id, int c_autores, int c_editoriales, String [][] editoriales, int c_autorEditor, String [][] autorEditor) {
                Scanner scanner = new Scanner(System.in);

                //Comparo si el id es menor a uno o mayor al contador o esta en nulo
                //entonces no existe el autor
                if (id < 1 || id > c_autores || autores[id - 1][1] == null) {
                    System.out.println("No existe autor.");
                    return;
                }

                String nombre = autores[id - 1][1];
                String fecha = autores[id - 1][2];
                String nacionalidad = autores[id - 1][3];
                String correo = autores[id - 1][4];

                String editorial = autores[id - 1][5];

                //Solicitamos los datos por si se quieren actualizar
                System.out.println("Actualizar autor del id " + id + ":");
                System.out.print("Nombre del autor (" + autores[id - 1][1] + "): ");
                String nombre_2 = scanner.nextLine();

                System.out.print("Fecha de nacimiento del autor (" + autores[id - 1][2] + "): ");
                String fecha_2 = scanner.nextLine();

                System.out.print("Nacionalidad del autor (" + autores[id - 1][3] + "): ");
                String nacionality_2 = scanner.nextLine();

                System.out.print("Correo del autor (" + autores[id - 1][4] + "): ");
                String email_2 = scanner.nextLine();

                //--------------------EDITORIAL-AUTOR-------------------------------------------------------------------------
                System.out.println("Cuantas editoriales tiene el autor ");
                int numEditoriales;
                do {
                    numEditoriales = scanner.nextInt();
                    scanner.nextLine(); //Limpiar buffer
                    if (numEditoriales < 1 || numEditoriales > c_editoriales) {
                        System.out.println("Cantidad inválida.");
                    }
                } while (numEditoriales < 1 || numEditoriales > c_editoriales);

                for (int i = 0; i < numEditoriales; i++) {
                    System.out.println("Seleccione la editorial " + (i + 1) + " para el autor " + nombre_2 + ":");
                    for (int j = 0; j < c_editoriales; j++) {
                        System.out.println((j + 1) + ") " + editoriales[j][1]); //mostrar editoriales disponibles
                    }

                    int editorialIndex;
                    do {
                        editorialIndex = scanner.nextInt();
                        editorialIndex = editorialIndex - 1;
                        scanner.nextLine(); //Limpiar buffer
                        if (editorialIndex < 0 || editorialIndex >= c_editoriales) {
                            System.out.println("Selección inválida. Intente nuevamente.");
                        }
                    } while (editorialIndex < 0 || editorialIndex >= c_editoriales);

                    System.out.println("Esta seguro de guardar los siguientes datos? ( 1. Si / 2. No)");
                    int selec = scanner.nextInt();
                    //Dependiendo la selecciona, se guarda o se retorna
                    if (selec == 1) {
                        //Utilizo el string value, para cambiar el tipo de dato de "c" al ID
                        autores[c_autores][1] = nombre_2;
                        if (nombre_2.isBlank()) {
                            autores[id - 1][1] = nombre;
                        }

                        autores[c_autores][2] = fecha_2;
                        if (fecha_2.isBlank()) {
                            autores[id - 1][2] = fecha;
                        }

                        autores[c_autores][3] = nacionality_2;
                        if (nacionality_2.isBlank()) {
                            autores[id - 1][3] = nacionalidad;
                        }
                        autores[c_autores][4] = email_2;
                        if (email_2.isBlank()) {
                            autores[id - 1][4] = correo;
                        }

                        //Guardar en la matriz de Autor-Editorial
                        autorEditor[c_autorEditor][1] = nombre_2;
                        autorEditor[c_autorEditor][2] = editoriales[editorialIndex][1]; //Nombre de la editorial
                        c_autorEditor++;
                    } else {
                        System.out.println("Se cancelo la operación.");
                        return;
                    }


                    System.out.println("Autor actualizad@ exitosamente.");
                }
            }

            // Mostrar la lista de categorias
            public static void listarAutores(String[][] autores, int c_autores) {
                //Utilizo una varibale boleana para determina si se encontro un autor al imprimir
                //se inicializa en false
                boolean encontroAutor = false;
                //Se imprime hasta que sea menor que el contador ya que inicia en 0
                for (int i = 0; i < c_autores; i++) {
                    //se pregunta si el campo es distinto de nulo y si el campo no esta vacio
                    if (autores[i][1] != null && !autores[i][1].isEmpty()) {
                        //imprime los datos del registro
                        System.out.println("ID: " + autores[i][0] + ", Nombre: " + autores[i][1] + ", Fecha de nacimiento:  " + autores[i][2] + ", Nacionalidad: " + autores[i][3] + ", Correo: "  + autores[i][4]  + "." );
                        //se cambia la variable a verdadera
                        encontroAutor = true;
                    }
                }
                //si al no encontrarse es false, entonces no hay autores por mostrar
                if (!encontroAutor) {
                    System.out.println("No hay autores registradas.");
                }
            }

            // Borrar registro
            public static void borrarAutor(String[][] autores, int id, int c_autores) {
                //al igual que el proceso de actualizar
                //valido si existe el id, si no no existe
                if (id < 1 || id > c_autores || autores[id - 1][1] == null) {
                    System.out.println("No existe autor.");
                    return;
                }

                //Borro los campo del registro
                autores[id - 1][1] = null;
                autores[id - 1][2] = null;
                autores[id - 1][3] = null;
                autores[id - 1][4] = null;
                autores[id - 1][5] = null;


                System.out.println("Autor eliminad@ exitosamente.");
            }

    //--------------------FIN AUTORES------------------------------------------------------------------------------------------------------------------------------------------------

    public static void listarAutoresEditoriales(String[][] autorEditor, int c_autorEditor) {
        System.out.println("**** Listado de Autores y Editoriales ****");
        if (c_autorEditor == 0) {
            System.out.println("No hay registros en la matriz de autores-editoriales.");
            return;
        }
        for (int i = 0; i < c_autorEditor; i++) {
            System.out.println("Autor: " + autorEditor[i][1] + " - Editorial: " + autorEditor[i][2]);
        }
    }

    public static void listarAutoresLibro(String[][] libroAutor, int c_autorlibro) {
        System.out.println("**** Listado de Autores y Editoriales ****");
        if (c_autorlibro == 0) {
            System.out.println("No hay registros en la matriz de autores-editoriales.");
            return;
        }
        for (int i = 0; i < c_autorlibro; i++) {
            System.out.println("Autor: " + libroAutor[i][1] + " - Editorial: " + libroAutor[i][2]);
        }
    }

    //--------------------MENU PARA CONSULTAS----------------------------------------------------------------------------------------------------------------------------------------
    public static void submenuConsultasLibros() {
        System.out.println("**** CONSULTAS ****");
        System.out.println("1) GENERAL");
        System.out.println("2) POR ID");
        System.out.println("3) POR NOMBRE");
        System.out.println("4) POR AUTOR");
        System.out.println("5) POR EDITORIAL");
        System.out.println("6) SALIR");
    }

    //-------------------MENU PRINCIPAL-----------------------------------------------------------------------------------------------------------------------------------------------
    public static void menuGeneral() {
        System.out.println("**** Sistema de libros ****");
        System.out.println("1) LIBROS");
        System.out.println("2) CATEGORIAS");
        System.out.println("3) EDITORIALES");
        System.out.println("4) AUTORES");
        System.out.println("5) AUTORES_EDITORIALES");
        System.out.println("6) LIBROS_AUTORES");
        System.out.println("7) SALIR");
    }

    //--------------------FUNCION PRINCIPAL----------------------------------------------------
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //defino variables a utilizar
        int opcion, id, opcion_general;

        //Definir matrices
        String[][] libros = new String[100][8];
        String[][] categorias = new String[100][2];
        String[][] autores = new String[100][6];
        String[][] editoriales = new String[100][5];
        String[][] autorEditor = new String[100][3];
        String[][] libroAutor = new String[100][8];

        //contador para el control del id de las matrices
        int c_libros = 0;
        int c_categoria = 0;
        int c_autores = 0;
        int c_editoriales = 0;
        int c_autorEditor = 0;
        int c_autorLibro = 0;

        //-------------------------MENÚ GENERAL-----------------------------------------

        do {
            //se imprime el menu y leemos la opcion
            menuGeneral();
            System.out.print("Seleccione una opción: ");
            opcion_general = scanner.nextInt();
            // Limpiamos el buffer
            scanner.nextLine();

            switch (opcion_general) {
                case 1:
                    //--------------LIBROS-------------------------------------------------------------------------
                    do {
                        //se imprime el menu y leemos la opcion
                        menuLibros();
                        System.out.print("Seleccione una opción: ");
                        opcion = scanner.nextInt();
                        // Limpiamos el buffer
                        scanner.nextLine();

                        switch (opcion) {
                            case 1:
                                agregarLibro(libros, c_libros,categorias,c_categoria,editoriales, c_editoriales);
                                //aumentamos el contador en 1 al agregar libro
                                if(c_editoriales != 0 && c_autores != 0 && c_categoria != 0 ) {
                                    c_libros++;
                                }
                                break;

                            case 2:
                                System.out.println("**** Listado de libros ****");
                                submenuConsultasLibros();
                                System.out.print("Seleccione una opción: ");
                                opcion = scanner.nextInt();
                                // Limpiamos el buffer
                                scanner.nextLine();
                                //Selecciona opcion de consulta
                                switch (opcion) {
                                    case 1:
                                        System.out.println("Listado general de libros:");
                                        listarLibros(libros, c_libros);
                                        break;

                                    case 2:
                                        System.out.print("Ingrese el ID del libro: ");
                                        int id_libro = scanner.nextInt();
                                        consultarLibroPorID(libros,c_libros, id_libro);
                                        break;

                                    case 3:
                                        System.out.print("Ingrese el nombre del libro: ");
                                        listarLibros(libros, c_libros);
                                        String nombre_libro = scanner.nextLine();
                                        consultarLibroPorNombre(libros,c_libros, nombre_libro);
                                        break;

                                    case 4:
                                        System.out.print("Ingrese la editorial (nombre): ");
                                        listarEditoriales(editoriales,c_editoriales);
                                        String nombre_editorial = scanner.nextLine();
                                        consultarLibroPorEditorial(libros,c_libros, nombre_editorial);
                                        break;

                                    case 5:
                                        System.out.print("Ingrese la categoría (nombre): ");
                                        listarCategorias(categorias,c_categoria);
                                        String nombre_categoria = scanner.nextLine();
                                        consultarLibroPorCategorias(libros,c_libros, nombre_categoria);
                                        break;

                                    case 6:
                                        System.out.print("Ingrese el autor (nombre): ");
                                        listarCategorias(categorias,c_categoria);
                                        String nombre_autor = scanner.nextLine();
                                        consultarLibroPorAutor(libros,c_libros, nombre_autor);
                                        break;

                                    default:
                                        System.out.println("Opción no válida.");
                                }
                                break;

                            case 3:
                                System.out.println("Actualizar los datos de los libros");
                                System.out.print("Ingresa ID: ");
                                id = scanner.nextInt();
                                // Limpiamos el buffer
                                scanner.nextLine();
                                //llamamos metodos y variables
                                actualizarLibro(libros, id, c_libros, categorias, c_categoria, editoriales,c_editoriales);
                                break;

                            case 4:
                                System.out.println("Borrar el libro");
                                System.out.print("Ingresa ID: ");
                                id = scanner.nextInt();
                                // Limpiar el buffer
                                scanner.nextLine();
                                //llamamos metodos y variables
                                borrarLibros(libros, id, c_libros);
                                break;

                            case 5:
                                System.out.println("Bye...");
                                break;

                            default:
                                System.out.println("Opcion no valida.");
                                break;
                        }
                    } while (opcion != 5);
                    //-----------------------------------------------------------------------------------------
                    break;

                case 2:
                    //-------------CATEGORIAS----------------------------------------------------------------------------

                    do {
                        //se imprime el menu y leemos la opcion
                        menuCategoria();
                        System.out.print("Seleccione una opción: ");
                        opcion = scanner.nextInt();
                        // Limpiamos el buffer
                        scanner.nextLine();

                        switch (opcion) {
                            case 1:
                                agregarCategoria(categorias, c_categoria);
                                //aumentamos el contador en 1 al agregar categoria
                                c_categoria++;
                                break;

                            case 2:
                                System.out.println("**** Listado de categorias ****");
                                //llamamos metodos y variables
                                listarCategorias(categorias, c_categoria);
                                break;

                            case 3:
                                System.out.println("Actualizar categoria");
                                System.out.print("Ingresa ID: ");
                                id = scanner.nextInt();
                                // Limpiamos el buffer
                                scanner.nextLine();
                                //llamamos metodos y variables
                                actualizarCategoria(categorias, id, c_categoria);
                                break;

                            case 4:
                                System.out.println("Borrar la categoria");
                                System.out.print("Ingresa ID: ");
                                id = scanner.nextInt();
                                // Limpiar el buffer
                                scanner.nextLine();
                                //llamamos metodos y variables
                                borrarCategoria(categorias, id, c_categoria);
                                break;

                            case 5:
                                System.out.println("Bye...");
                                break;

                            default:
                                System.out.println("Opcion no valida.");
                                break;
                        }
                    } while (opcion != 5);

                    //--------------------------------------------------------------------------------------
                    break;

                case 3:
                    //-------------EDITORIALES----------------------------------------------------------------------------

                    do {
                        //se imprime el menu y leemos la opcion
                        menuEditorial();
                        System.out.print("Seleccione una opción: ");
                        opcion = scanner.nextInt();
                        // Limpiamos el buffer
                        scanner.nextLine();

                        switch (opcion) {
                            case 1:
                                agregarEditorial(editoriales, c_editoriales);
                                //aumentamos el contador en 1 al agregar editorial
                                c_editoriales++;
                                break;

                            case 2:
                                System.out.println("**** Listado de editoriales ****");
                                //llamamos metodos y variables
                                listarEditoriales(editoriales, c_editoriales);
                                break;

                            case 3:
                                System.out.println("Actualizar editorial");
                                System.out.print("Ingresa ID: ");
                                id = scanner.nextInt();
                                // Limpiamos el buffer
                                scanner.nextLine();
                                //llamamos metodos y variables
                                actualizarEditorial(editoriales, id, c_editoriales);
                                break;

                            case 4:
                                System.out.println("Borrar la editorial");
                                System.out.print("Ingresa ID: ");
                                id = scanner.nextInt();
                                // Limpiar el buffer
                                scanner.nextLine();
                                //llamamos metodos y variables
                                borrarEditorial(editoriales, id, c_editoriales);
                                break;

                            case 5:
                                System.out.println("Bye...");
                                break;

                            default:
                                System.out.println("Opcion no valida.");
                                break;
                        }
                    } while (opcion != 5);

                    //-------------------------------------------------------------------------------------
                    break;

                case 4:
                    //---------------AUTORES-------------------------------------------------

                    do {
                        //se imprime el menu y leemos la opcion
                        menuAutores();
                        System.out.print("Seleccione una opción: ");
                        opcion = scanner.nextInt();
                        // Limpiamos el buffer
                        scanner.nextLine();

                        switch (opcion) {
                            case 1:
                                agregarAutor(autores, c_autores,editoriales,c_editoriales,autorEditor, c_autorEditor);
                                //aumentamos el contador en 1 al agregar un autor
                                if(c_editoriales != 0) {
                                    c_autores++;
                                }
                                break;

                            case 2:
                                System.out.println("**** Listado de autores ****");
                                //llamamos metodos y variables
                                listarAutores(autores, c_autores);
                                break;

                            case 3:
                                System.out.println("Actualizar datos del autor");
                                System.out.print("Ingresa ID: ");
                                id = scanner.nextInt();
                                // Limpiamos el buffer
                                scanner.nextLine();
                                //llamamos metodos y variables
                                actualizarAutor(autores, id, c_autores,c_autorEditor, autorEditor, c_editoriales, editoriales);
                                break;

                            case 4:
                                System.out.println("Borrar autor");
                                System.out.print("Ingresa ID: ");
                                id = scanner.nextInt();
                                // Limpiar el buffer
                                scanner.nextLine();
                                //llamamos metodos y variables
                                borrarAutor(autores, id, c_autores);
                                break;

                            case 5:
                                System.out.println("Bye...");
                                break;

                            default:
                                System.out.println("Opcion no valida.");
                                break;
                        }
                    } while (opcion != 5);

                    //----------------------------------------------------------------------
                    break;

                case 5:
                    //--------------- AUTORES - EDITORIALES -------------------------------------------------

                    listarAutoresEditoriales(autorEditor, c_autorLibro);

                    //-------------------------------------------------

                    break;

                case 6:

                    //--------------- LIBROS - AUTORES -------------------------------------------------

                    accionLibroAutor(libros,c_libros,autorEditor,c_autorEditor,libroAutor,c_autorLibro);

                    //-------------------------------------------------

                    break;

                case 7:
                    System.out.println("Bye...");
                    break;

                default:
                    System.out.println("Opcion no valida.");
                    break;
            }
        } while (opcion_general != 7);
        //---------FIN GENERAL-------------------------------------------------------------------------------
        scanner.close();

    }
    //-----------------------------------------------------------------------------------------
}