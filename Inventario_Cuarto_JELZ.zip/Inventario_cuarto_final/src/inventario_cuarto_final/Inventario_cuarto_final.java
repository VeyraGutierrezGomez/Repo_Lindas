/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */ 

package inventario_cuarto_final;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Emmanuel López
 */
public class Inventario_cuarto_final {
    
    
    private static final String URL = "jdbc:mysql://localhost:3306/inventario_poo";
    private static final String USUARIO = "root";  // Cambia según tu usuario
    private static final String PASSWORD = "";     // Si tienes contraseña, agrégala aquí

    private static Connection conexion = null;
    
    
    //clase para conexión      
    public static Connection getConexion() {
        if (conexion == null) { // Si no hay conexión, la creamos
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conexion = DriverManager.getConnection(URL, USUARIO, PASSWORD);
                System.out.println("Conexión exitosa a la base de datos.");
            } catch (ClassNotFoundException e) {
                System.err.println("Error: No se encontró el driver JDBC.");
                e.printStackTrace();
            } catch (SQLException e) {
                System.err.println("Error de conexión con la base de datos.");
                e.printStackTrace();
            }
        }
        return conexion;
    }
    
    //login del usuario
    public static boolean autenticarUsuario(String nombre, String password) {
            boolean accesoPermitido = false;

            try {
                Connection conexion = Inventario_cuarto_final.getConexion(); // Método para obtener conexión a la BD
                String sql = "SELECT * FROM usuarios WHERE nombre = ? AND password = ?";
                PreparedStatement pst = conexion.prepareStatement(sql);
                pst.setString(1, nombre);
                pst.setString(2, password);
                ResultSet rs = pst.executeQuery();

                if (rs.next()) { // Si hay resultados, las credenciales son correctas
                    accesoPermitido = true;
                }

                rs.close();
                pst.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            return accesoPermitido;
    }

    //clase principal
    public static void main(String[] args) {
        getConexion();
        
        Universo_cuarto nextFrame = new Universo_cuarto();
        nextFrame.setVisible(true);
        
    }
}
