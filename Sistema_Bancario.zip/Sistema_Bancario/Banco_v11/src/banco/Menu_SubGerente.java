/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package banco;

import static banco.Banco.fechaActual;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;


public class Menu_SubGerente extends javax.swing.JFrame {

    private Banco banco;
    private List<Cuenta> cuentas;
    private List<Usuario> usuarios;
    private List<SubCuenta> subCuentas;
    private List<SolicitudInversion> solicitudes;
    private String idUsuario;
    private String idCuenta;
    private String idSubcuenta;
    private String numeroTarjeta;
    private String claveInterbancaria;
    private String claveTransferencia;
    
    //cuenta del subgerente
    private String iduser;
    private String user;
    
    /**
     * Creates new form Subgerente
     */
    public Menu_SubGerente(Banco banco, String iduser, String user) {
        this.banco = banco;
        this.cuentas = banco.getCuentas();
        this.usuarios = banco.getUsuarios();
        this.subCuentas = banco.getSubCuentas();
        this.solicitudes = banco.getSolicitudes();
        this.iduser = iduser;
        this.user = user;
        initComponents();
        this.setLocationRelativeTo(null);
        inicializarValores();
        tblSubcuentas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 
        tblReporteSolicitud.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        cargarSubCuentasATabla();
        cargarSolicitudesATabla();
        
        tblSubcuentas.getModel().addTableModelListener(e -> {
            int columna = e.getColumn();
            int filaSeleccionada = e.getFirstRow();

            // Solo si se modificó la columna "Elección"
            if (columna == 6) {
                Boolean valorSeleccionado = (Boolean) tblSubcuentas.getValueAt(filaSeleccionada, columna);

                // Si se marcó en true, desmarcar el resto
                if (valorSeleccionado != null && valorSeleccionado) {
                    for (int i = 0; i < tblSubcuentas.getRowCount(); i++) {
                        if (i != filaSeleccionada) {
                            tblSubcuentas.setValueAt(false, i, columna);
                        }
                    }
                }
            }
        });
        
        //subcuenta
        txtIdSubcuenta.setEditable(false);
        txtNumeroSubcuenta.setEditable(false);
        txtIdUsuario.setEditable(false);
        txtFechaSubcuenta.setEditable(false);
        txtTitular.setEditable(false);                                                
        txtNombreUsuarioSubcuenta.setEditable(false);
        txtCorreoSubcuenta.setEditable(false);
        txtClaveIntSubcuenta.setEditable(false);
        txtClaveTranSubcuenta.setEditable(false);
        
        // Listener para seleccionar fila y cargar datos a subcuenta
        tblSubcuentas.getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent event) {
                if (!event.getValueIsAdjusting() && tblSubcuentas.getSelectedRow() != -1) {
                    int fila = tblSubcuentas.getSelectedRow();
                    DefaultTableModel modelo = (DefaultTableModel) tblSubcuentas.getModel();

                    // Cargar datos visibles de la tabla
                    txtIdSubcuenta.setText(modelo.getValueAt(fila, 0).toString());
                    txtNumeroSubcuenta.setText(modelo.getValueAt(fila, 1).toString());
                    txtIdUsuario.setText(modelo.getValueAt(fila, 2).toString());
                    cmbTipoCuenta.setSelectedItem(modelo.getValueAt(fila, 3).toString());
                    txtSaldoSubcuenta.setText(modelo.getValueAt(fila, 4).toString());
                    

                    // Buscar datos ocultos desde listas
                    String idSubcuenta = modelo.getValueAt(fila, 0).toString();
                    String idUsuario = modelo.getValueAt(fila, 2).toString();
                    
                    for (SubCuenta subcuenta : subCuentas) {
                        if (subcuenta.getIdCuenta().equals(idSubcuenta)){
                            txtNipSubcuenta.setText(subcuenta.getNip());
                            txtClaveIntSubcuenta.setText(subcuenta.getSubClaveInterbancaria());
                            txtClaveTranSubcuenta.setText(subcuenta.getSubClaveTransferencia());
                            break;
                        }
                    }

                    for (Usuario usuario : usuarios) {
                        if (usuario.getIdUsuario().equals(idUsuario)) { // Suponiendo misma relación de ID
                            txtFechaSubcuenta.setText(usuario.getFechaNacimiento());
                            txtTitular.setText(usuario.getNombre());                                                      
                            txtNombreUsuarioSubcuenta.setText(usuario.getNombreUsuario());
                            txtCorreoSubcuenta.setText(usuario.getCorreoElectronico());
                            break;
                        }
                    }
                    
                    for (Cuenta cuentaeje : cuentas){
                        if(cuentaeje.getIdUsuario().equals(idUsuario)){
                          txtCuentaEje.setText(cuentaeje.getNumeroTarjeta());
                          txtNipCuentaEje.setText(cuentaeje.getNip());
                        }
                    }
                }
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Subgerente = new javax.swing.JTabbedPane();
        Subcuentas = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblSubcuentas = new javax.swing.JTable();
        txtCuentaEje = new javax.swing.JTextField();
        btnEliminarSubcuenta = new javax.swing.JButton();
        btnIngresarSubcuenta = new javax.swing.JButton();
        btnActualizarSubcuenta = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        txtNipCuentaEje = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        txtIdUsuario = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        txtTitular = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        txtFechaSubcuenta = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        txtNombreUsuarioSubcuenta = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        txtCorreoSubcuenta = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        txtClaveIntSubcuenta = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        txtClaveTranSubcuenta = new javax.swing.JTextField();
        txtSaldoSubcuenta = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        txtNumeroSubcuenta = new javax.swing.JTextField();
        txtNipSubcuenta = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        txtIdSubcuenta = new javax.swing.JTextField();
        cmbTipoCuenta = new javax.swing.JComboBox<>();
        btnRegresar2 = new javax.swing.JButton();
        Solicitudes = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblReporteSolicitud = new javax.swing.JTable();
        btnRegresar3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Subgerente.setBackground(new java.awt.Color(206, 231, 255));

        Subcuentas.setBackground(new java.awt.Color(255, 255, 255));

        jLabel18.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 102));
        jLabel18.setText("Numero de Cuenta Eje:");

        tblSubcuentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id", "# Subcuenta", "Id Usuario", "Tipo de Cuenta", "Saldo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(tblSubcuentas);

        txtCuentaEje.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtCuentaEje.setText("Numero de cuenta eje");

        btnEliminarSubcuenta.setBackground(new java.awt.Color(0, 0, 102));
        btnEliminarSubcuenta.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnEliminarSubcuenta.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminarSubcuenta.setText("ELIMINAR");
        btnEliminarSubcuenta.setToolTipText("");
        btnEliminarSubcuenta.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEliminarSubcuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarSubcuentaActionPerformed(evt);
            }
        });

        btnIngresarSubcuenta.setBackground(new java.awt.Color(0, 0, 102));
        btnIngresarSubcuenta.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnIngresarSubcuenta.setForeground(new java.awt.Color(255, 255, 255));
        btnIngresarSubcuenta.setText("INGRESAR");
        btnIngresarSubcuenta.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnIngresarSubcuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarSubcuentaActionPerformed(evt);
            }
        });

        btnActualizarSubcuenta.setBackground(new java.awt.Color(0, 0, 102));
        btnActualizarSubcuenta.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnActualizarSubcuenta.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizarSubcuenta.setText("ACTUALIZAR");
        btnActualizarSubcuenta.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnActualizarSubcuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarSubcuentaActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 102));
        jLabel19.setText("NIP Cuenta Eje:");

        txtNipCuentaEje.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNipCuentaEje.setText("Nip de cuenta eje");
        txtNipCuentaEje.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtNipCuentaEjeFocusLost(evt);
            }
        });
        txtNipCuentaEje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNipCuentaEjeActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 102));
        jLabel20.setText("Id Usuario:");

        txtIdUsuario.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtIdUsuario.setText("Id del usuario");

        jLabel21.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 102));
        jLabel21.setText("Nombre del Titular:");

        txtTitular.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtTitular.setText("Nombre completo del titular");

        jLabel22.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 0, 102));
        jLabel22.setText("Fecha de Nacimiento:");

        txtFechaSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtFechaSubcuenta.setText("DD/MM/AAAA");

        jLabel24.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 0, 102));
        jLabel24.setText("Nombre de Usuario:");

        txtNombreUsuarioSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNombreUsuarioSubcuenta.setText("Nombre del usuario");

        jLabel27.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(0, 0, 102));
        jLabel27.setText("Correo:");

        txtCorreoSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtCorreoSubcuenta.setText("coreo@dominio.com");
        txtCorreoSubcuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoSubcuentaActionPerformed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 0, 102));
        jLabel28.setText("Clave Interbancaria Subcuenta:");

        txtClaveIntSubcuenta.setFont(new java.awt.Font("Candara", 0, 10)); // NOI18N
        txtClaveIntSubcuenta.setText("Clave interbancaria subcuenta automatica");
        txtClaveIntSubcuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtClaveIntSubcuentaActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("Candara", 1, 12)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(0, 0, 102));
        jLabel29.setText("Clave de Transferencia Subcuenta:");

        txtClaveTranSubcuenta.setFont(new java.awt.Font("Candara", 0, 10)); // NOI18N
        txtClaveTranSubcuenta.setText("Clave de transferencia subcuneta automatica");

        txtSaldoSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtSaldoSubcuenta.setText("Saldo inicial subcuenta");
        txtSaldoSubcuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSaldoSubcuentaActionPerformed(evt);
            }
        });

        jLabel30.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(0, 0, 102));
        jLabel30.setText("Numero de Subcuenta:");

        jLabel31.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(0, 0, 102));
        jLabel31.setText("Tipo de Cuenta:");

        jLabel33.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(0, 0, 102));
        jLabel33.setText("NIP Subcuenta:");

        txtNumeroSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNumeroSubcuenta.setText("Numero de subcuenta automatico");

        txtNipSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNipSubcuenta.setText("NIP de la subcuenta");

        jLabel34.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(0, 0, 102));
        jLabel34.setText("Saldo Inicial Subcuenta:");

        jLabel36.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(0, 0, 102));
        jLabel36.setText("Id:");

        txtIdSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtIdSubcuenta.setText("Id automatico");

        cmbTipoCuenta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ahorro", "Corriente", "Plazo Fijo", "Nomina" }));

        btnRegresar2.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar2.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar2.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar2.setText("REGRESAR");
        btnRegresar2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SubcuentasLayout = new javax.swing.GroupLayout(Subcuentas);
        Subcuentas.setLayout(SubcuentasLayout);
        SubcuentasLayout.setHorizontalGroup(
            SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SubcuentasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 513, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SubcuentasLayout.createSequentialGroup()
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtFechaSubcuenta)
                            .addComponent(txtNombreUsuarioSubcuenta)
                            .addComponent(txtIdUsuario)
                            .addComponent(txtTitular)
                            .addGroup(SubcuentasLayout.createSequentialGroup()
                                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNipCuentaEje, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtCuentaEje, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(SubcuentasLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNumeroSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtClaveIntSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel28)
                                    .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtClaveTranSubcuenta)
                                        .addComponent(txtNipSubcuenta)
                                        .addComponent(txtSaldoSubcuenta)
                                        .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(cmbTipoCuenta, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(SubcuentasLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(SubcuentasLayout.createSequentialGroup()
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdSubcuenta, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCorreoSubcuenta))))
                .addGap(15, 15, 15))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SubcuentasLayout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(btnEliminarSubcuenta)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnActualizarSubcuenta)
                .addGap(128, 128, 128)
                .addComponent(btnIngresarSubcuenta)
                .addGap(148, 148, 148)
                .addComponent(btnRegresar2)
                .addGap(50, 50, 50))
        );
        SubcuentasLayout.setVerticalGroup(
            SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SubcuentasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(SubcuentasLayout.createSequentialGroup()
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtIdSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCorreoSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SubcuentasLayout.createSequentialGroup()
                                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtCuentaEje, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNumeroSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(16, 16, 16)
                                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtNipCuentaEje, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtClaveIntSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(20, 20, 20)
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtIdUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtTitular, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbTipoCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtFechaSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNombreUsuarioSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SubcuentasLayout.createSequentialGroup()
                                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtClaveTranSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(45, 45, 45)
                                .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNipSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtSaldoSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jScrollPane3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminarSubcuenta)
                    .addComponent(btnActualizarSubcuenta)
                    .addComponent(btnIngresarSubcuenta)
                    .addComponent(btnRegresar2))
                .addGap(20, 20, 20))
        );

        Subgerente.addTab("Subcuentas", Subcuentas);

        Solicitudes.setBackground(new java.awt.Color(255, 255, 255));

        tblReporteSolicitud.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Id", "Numero de SubTarjeta ", "Estado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(tblReporteSolicitud);

        btnRegresar3.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar3.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar3.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar3.setText("REGRESAR");
        btnRegresar3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SolicitudesLayout = new javax.swing.GroupLayout(Solicitudes);
        Solicitudes.setLayout(SolicitudesLayout);
        SolicitudesLayout.setHorizontalGroup(
            SolicitudesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SolicitudesLayout.createSequentialGroup()
                .addGap(404, 404, 404)
                .addComponent(btnRegresar3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SolicitudesLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 927, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        SolicitudesLayout.setVerticalGroup(
            SolicitudesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SolicitudesLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnRegresar3)
                .addGap(94, 94, 94))
        );

        Subgerente.addTab("Solicitudes", Solicitudes);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Subgerente, javax.swing.GroupLayout.PREFERRED_SIZE, 970, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Subgerente, javax.swing.GroupLayout.PREFERRED_SIZE, 559, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void verificarCuentaEjeYNip() {
        String numeroCuenta = txtCuentaEje.getText().trim();
        String nip = txtNipCuentaEje.getText().trim();

        for (Cuenta cuenta : cuentas) {
            if (cuenta.getNumeroTarjeta().equals(numeroCuenta) && cuenta.getNip().equals(nip)) {
                txtIdUsuario.setText(cuenta.getIdUsuario());
                // Buscar usuario por idUsuario
                
                String idUsuariobus = cuenta.getIdUsuario();
                for (Usuario usuario : usuarios) {
                    if (usuario.getIdUsuario().equals(idUsuariobus)) {
                        txtTitular.setText(usuario.getNombre());
                        txtFechaSubcuenta.setText(usuario.getFechaNacimiento());
                        txtNombreUsuarioSubcuenta.setText(usuario.getNombreUsuario());
                        txtCorreoSubcuenta.setText(usuario.getCorreoElectronico());
                        break;
                    }
                }
                
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "Cuenta o NIP incorrecto.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void cargarSubCuentasATabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) tblSubcuentas.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos

        for (SubCuenta subcuenta : subCuentas) {
            // Obtener nombre del titular desde la lista de usuarios
            String nombreTitular = "";
            String estado = "";
            for (Usuario usuario : usuarios) {
                if (usuario.getIdUsuario().equals(subcuenta.getIdUsuario())) {
                    nombreTitular = usuario.getNombre();
                    break;
                }
            }
            
            if(subcuenta.getEstado()== false){ estado="Apagada";}
            if(subcuenta.getEstado()==true){ estado="Encendida";}

            modeloTabla.addRow(new Object[]{
                subcuenta.getIdCuenta(),
                subcuenta.getSubNumeroTarjeta(),
                subcuenta.getIdUsuario(),
                subcuenta.getTipoCuenta(),
                subcuenta.getSaldo(),
                estado
            });
        }
    }
    
   private void cargarSolicitudesATabla() {
        DefaultTableModel modelo = (DefaultTableModel) tblReporteSolicitud.getModel();
        modelo.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos
        int i=1;
        String estado = "";
        // Llenar la tabla con las solicitudes filtradas
        
        for (SolicitudInversion solicitud : solicitudes) {
            if (solicitud.getCuenta1().equals(user)) {
                
                if(solicitud.getEstado()==1){ estado="Aprobada";}
                if(solicitud.getEstado()==2){ estado="Rechazada";}
                if(solicitud.getEstado()==3){ estado="En espera";}
                modelo.addRow(new Object[]{
                    i,
                    solicitud.getNumeroCuenta(),
                    estado,
                });
            }
            i++;
        }
    }
    
    private void inicializarValores() {
        int[] contadores = banco.getContadores();

        idUsuario = String.valueOf(contadores[1]);
        idCuenta = String.valueOf(contadores[0]);
        idSubcuenta = String.valueOf(contadores[5]);
        numeroTarjeta = banco.generarNumeroTarjeta();
        claveInterbancaria = banco.generarClaveInterbancaria();
        claveTransferencia = banco.generarClaveTransferencia();
        
        //comprobar que el numero de tarjeta no exista
        do{
            if (banco.existeNumeroTarjeta(numeroTarjeta)) {
                numeroTarjeta= banco.generarNumeroTarjeta();
            }
        } while(banco.existeNumeroTarjeta(numeroTarjeta));
        
        
        //comprobar que la cable interbancaria no exista
        do{
            if (banco.existeClaveInterbancaria(claveInterbancaria)) {
                claveInterbancaria= banco.generarClaveInterbancaria();
            }
        } while(banco.existeClaveInterbancaria(claveInterbancaria));
        
        
        //comprobar que la clave de transferencia  no exista
        do{
            if (banco.existeClaveTransferencia(claveTransferencia)) {
                claveTransferencia= banco.generarClaveTransferencia();
            }
        } while(banco.existeClaveTransferencia(claveTransferencia));
        
              
        //--------------SUBCUENTAS-------------------------------
        
        //Mostrar en los campos de texto
        txtIdSubcuenta.setText(idSubcuenta);
        txtNumeroSubcuenta.setText(numeroTarjeta);
        txtClaveIntSubcuenta.setText(claveInterbancaria);
        txtClaveTranSubcuenta.setText(claveTransferencia);
       
        //Evitar que se editen
        txtIdSubcuenta.setEditable(false);
        txtNumeroSubcuenta.setEditable(false);
        txtClaveIntSubcuenta.setEditable(false);
        txtClaveTranSubcuenta.setEditable(false);
        txtIdUsuario.setEditable(false);
        txtTitular.setEditable(false);
        txtFechaSubcuenta.setEditable(false);
        
    }
    
    private void txtClaveIntSubcuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtClaveIntSubcuentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtClaveIntSubcuentaActionPerformed

    private void txtCorreoSubcuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoSubcuentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoSubcuentaActionPerformed

    private void txtNipCuentaEjeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNipCuentaEjeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNipCuentaEjeActionPerformed

    public void actualizarSaldoConInteres(int semanaActual) {

        for(SubCuenta subcuentas : subCuentas) {
            if (subcuentas.getTipoCuenta().equals("Ahorro") || subcuentas.getTipoCuenta().equals("Plazo Fijo")){
                int semanasTranscurridas = semanaActual - subcuentas.getSemanaUltimaConsulta();
                if (semanasTranscurridas > 0) {
                    double tasaInteres = 0.0005; //ejemplo 0.05% semanal
                    double saldoConInteres = subcuentas.getSaldo() * Math.pow(1 + tasaInteres, semanasTranscurridas);
                    subcuentas.setSaldo(saldoConInteres);
                    subcuentas.setSemanaUltimaConsulta(semanaActual); //actualizar la última semana consultada
                }
            }
        }
    }
    
    private void btnIngresarSubcuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarSubcuentaActionPerformed
        // TODO add your handling code here:
        
          // TODO add your handling code here:
        int[] contadores = banco.getContadores();
        
        //simular saldo con intereses
        contadores[6]++;
        actualizarSaldoConInteres(contadores[6]);
        
        if(contadores[0] == 1){
            System.out.println("No hay cuentas (eje) registradas");
            return;
        }
        
        String idSubCuenta = txtIdSubcuenta.getText();    
        String tipoCuenta = (String) cmbTipoCuenta.getSelectedItem();
        String numeroSubTarjeta = txtNumeroSubcuenta.getText();       
        String claveSubInterbancaria = txtClaveIntSubcuenta.getText();  
        String claveSubTransferencia = txtClaveTranSubcuenta.getText();  
        String idUsuariosub = txtIdUsuario.getText();
        String nipSubCuenta = txtNipSubcuenta.getText();
        String saldoSubCuenta = txtSaldoSubcuenta.getText();
        
        
        //Validar que los campos no estén vacíos
        if (nipSubCuenta.isEmpty() || tipoCuenta.isEmpty() || saldoSubCuenta.isEmpty() ) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        double saldo;
        double saldoBanco = banco.getSaldoBanco();

        try {
            saldo = Double.parseDouble(saldoSubCuenta);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Saldo inválido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (saldo > saldoBanco) {
            JOptionPane.showMessageDialog(this, "El banco no tiene fondos suficientes", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String [] movimientossubc = new String [99];
        int cont_movimientossubc = 0;
        boolean estadosub = true; //activar la tarjeta
        
        // Mostrar ventana de confirmación
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas agregar esta subcuenta?",
                "Confirmar ingreso",
                JOptionPane.YES_NO_OPTION
        );
        
        if (opcion == JOptionPane.YES_OPTION) {
            SubCuenta subcuenta = new SubCuenta(idSubCuenta,tipoCuenta,numeroSubTarjeta,claveSubInterbancaria,claveSubTransferencia,idUsuariosub,nipSubCuenta,saldo,movimientossubc,cont_movimientossubc,estadosub, contadores[6]);
            contadores[5]++;
            subCuentas.add(subcuenta);
            JOptionPane.showMessageDialog(this, "Subcuenta agregada con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
            String estadoString = "";
            
            if(estadosub == true){estadoString = "Encendida";}
            // Agregar a la tabla
            DefaultTableModel modeloTabla = (DefaultTableModel) tblSubcuentas.getModel();
            modeloTabla.addRow(new Object[]{
                idSubCuenta,
                numeroSubTarjeta,
                idUsuariosub,
                tipoCuenta,
                saldo,
                estadoString
            });

            
            String nombreTitular = txtTitular.getText();
            
            //Limpiar campos
            
            txtIdSubcuenta.setText(""); 
            txtCuentaEje.setText("");  
            txtNipCuentaEje.setText("");
            txtNumeroSubcuenta.setText("");       
            txtClaveIntSubcuenta.setText("");  
            txtClaveTranSubcuenta.setText("");  
            txtIdUsuario.setText("");
            txtNipSubcuenta.setText("");
            txtSaldoSubcuenta.setText("");
            
            SolicitudInversion solicitud = new SolicitudInversion(
                numeroSubTarjeta, 
                user, 
                "-------", 
                3 //se crea como en espera
            );
            
            solicitudes.add(solicitud);
            cargarSolicitudesATabla();
            
            //Registrar movimiento en el banco
            int contador = banco.getCont_Movimientos();
            String movimiento;

            movimiento=
                        "Acción: El subgerente "+user+" ha creado la subCuenta "+numeroSubTarjeta+".\n" +
                                "Rol: Usuario\n" +
                                "Nombre del titular: " + nombreTitular + "\n" +
                                "Fecha: " + fechaActual();
            banco.setMovimientos(movimiento, contador);
            contador++; 
            inicializarValores();
            
        } else {
            JOptionPane.showMessageDialog(this, "Operación cancelada", "Cancelado", JOptionPane.INFORMATION_MESSAGE);
        }       
        
    }//GEN-LAST:event_btnIngresarSubcuentaActionPerformed

    private void btnActualizarSubcuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarSubcuentaActionPerformed
        // TODO add your handling code here:
        
         int fila = tblSubcuentas.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una subcuenta para actualizar");
            return;
        }

          
        String tipoCuenta = (String) cmbTipoCuenta.getSelectedItem();
        String numeroSubTarjeta = txtNumeroSubcuenta.getText();       
        String claveSubInterbancaria = txtClaveIntSubcuenta.getText();  
        String claveSubTransferencia = txtClaveTranSubcuenta.getText();  
        String idUsuariosub = txtIdUsuario.getText();
        String nipSubCuenta = txtNipSubcuenta.getText();
        String saldoSubCuenta = txtSaldoSubcuenta.getText();
        
        
        //Validar que los campos no estén vacíos
        if (nipSubCuenta.isEmpty() || tipoCuenta.isEmpty() || saldoSubCuenta.isEmpty() ) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double saldo;
        try {
            saldo = Double.parseDouble(saldoSubCuenta);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Saldo inválido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String idSubCuenta = txtIdSubcuenta.getText();  
        
        //Checar si la subcuenta no está en estado de espera
        for(SolicitudInversion solicitud: solicitudes){
            if(solicitud.getNumeroCuenta().equals(numeroSubTarjeta) && (solicitud.getEstado()==3)){
                JOptionPane.showMessageDialog(this, "La subcuenta seleccionada está en revision", "Movimiento Denegado", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }

        //Confirmación
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Deseas actualizar los datos de esta subcuenta?",
            "Confirmar actualización",
            JOptionPane.YES_NO_OPTION
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Operación cancelada", "Cancelado", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        //Actualizar en listas
        for (SubCuenta subcuenta : subCuentas) {
            if (subcuenta.getIdCuenta().equals(idSubCuenta)) {
                subcuenta.setSaldo(saldo);
                subcuenta.setNip(nipSubCuenta);
                subcuenta.setTipoCuenta(tipoCuenta);
                break;
            }
        }

       
        // Actualizar visualmente en la tabla
        DefaultTableModel modelo = (DefaultTableModel) tblSubcuentas.getModel();
        modelo.setValueAt(tipoCuenta, fila, 3);
        modelo.setValueAt(saldo, fila, 4);

        JOptionPane.showMessageDialog(this, "Subcuenta actualizada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        String nombreTitular = txtTitular.getText();
        
        //Limpiar campos
            txtIdSubcuenta.setText(""); 
            txtCuentaEje.setText("");  
            txtNipCuentaEje.setText("");
            txtNumeroSubcuenta.setText("");       
            txtClaveIntSubcuenta.setText("");  
            txtClaveTranSubcuenta.setText("");  
            txtIdUsuario.setText("");
            txtNipSubcuenta.setText("");
            txtSaldoSubcuenta.setText("");
        
        tblSubcuentas.clearSelection();
        
         //Registrar movimiento en el banco
        int contador = banco.getCont_Movimientos();
        String movimiento;

        movimiento=
                        "Acción: El subgerente "+user+" ha modificado la subCuenta "+numeroSubTarjeta+".\n" +
                                "Rol: Usuario\n" +
                                "Nombre del titular: " + nombreTitular + "\n" +
                                "Fecha: " + fechaActual();
        banco.setMovimientos(movimiento, contador);
        contador++; 
            
        inicializarValores();
        
        
    }//GEN-LAST:event_btnActualizarSubcuentaActionPerformed

    private void btnEliminarSubcuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarSubcuentaActionPerformed
        // TODO add your handling code here:
        
        // TODO add your handling code here:
        int fila = tblSubcuentas.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una subcuenta a eliminar");
            return;
        }

        // Obtener el modelo de la tabla
        DefaultTableModel modelo = (DefaultTableModel) tblSubcuentas.getModel();

        
        String idSubcuentaEli = modelo.getValueAt(fila, 0).toString();
        SubCuenta subcuentaEliminar = null;
        String nombreTitular="";
        String numeroCuenta="";
        
        for (SubCuenta subcuenta : subCuentas) {
            if (subcuenta.getIdCuenta().equals(idSubcuentaEli)) {
                subcuentaEliminar = subcuenta;
                nombreTitular = subcuenta.getIdUsuario();
                numeroCuenta = subcuenta.getSubNumeroTarjeta();
                break;
            }
        }
        
        //Checar si la subcuenta no está en estado de espera
        for(SolicitudInversion solicitud: solicitudes){
            if(solicitud.getNumeroCuenta().equals(numeroCuenta) && (solicitud.getEstado()==3)){
                JOptionPane.showMessageDialog(this, "La subcuenta seleccionada está en revision", "Movimiento Denegado", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        
        for(Usuario usuario: usuarios){
            if(usuario.getIdUsuario().equals(nombreTitular)){
                nombreTitular=usuario.getNombre();
            }
        }

        if (subcuentaEliminar != null) {
            subCuentas.remove(subcuentaEliminar);
        }
        
        // Eliminar la fila seleccionada
        modelo.removeRow(fila);
        
        //Registrar movimiento en el banco
        int contador = banco.getCont_Movimientos();
        String movimiento;

        movimiento=
                        "Acción: El subgerente "+user+" ha eliminado la subCuenta "+numeroCuenta+".\n" +
                                "Rol: Usuario\n" +
                                "Nombre del titular: " + nombreTitular + "\n" +
                                "Fecha: " + fechaActual();
        banco.setMovimientos(movimiento, contador);
        contador++; 

        JOptionPane.showMessageDialog(this, "Subcuenta eliminada");
        
    }//GEN-LAST:event_btnEliminarSubcuentaActionPerformed

    private void txtNipCuentaEjeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNipCuentaEjeFocusLost
        // TODO add your handling code here:
        verificarCuentaEjeYNip();
    }//GEN-LAST:event_txtNipCuentaEjeFocusLost

    private void btnRegresar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar2ActionPerformed
        // TODO add your handling code here:
        InicioSesion nextFrame = new InicioSesion(banco);
        nextFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresar2ActionPerformed

    private void btnRegresar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar3ActionPerformed
        // TODO add your handling code here:
        InicioSesion nextFrame = new InicioSesion(banco);
        nextFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresar3ActionPerformed

    private void txtSaldoSubcuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSaldoSubcuentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSaldoSubcuentaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu_SubGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu_SubGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu_SubGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu_SubGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Solicitudes;
    private javax.swing.JPanel Subcuentas;
    private javax.swing.JTabbedPane Subgerente;
    private javax.swing.JButton btnActualizarSubcuenta;
    private javax.swing.JButton btnEliminarSubcuenta;
    private javax.swing.JButton btnIngresarSubcuenta;
    private javax.swing.JButton btnRegresar2;
    private javax.swing.JButton btnRegresar3;
    private javax.swing.JComboBox<String> cmbTipoCuenta;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable tblReporteSolicitud;
    private javax.swing.JTable tblSubcuentas;
    private javax.swing.JTextField txtClaveIntSubcuenta;
    private javax.swing.JTextField txtClaveTranSubcuenta;
    private javax.swing.JTextField txtCorreoSubcuenta;
    private javax.swing.JTextField txtCuentaEje;
    private javax.swing.JTextField txtFechaSubcuenta;
    private javax.swing.JTextField txtIdSubcuenta;
    private javax.swing.JTextField txtIdUsuario;
    private javax.swing.JTextField txtNipCuentaEje;
    private javax.swing.JTextField txtNipSubcuenta;
    private javax.swing.JTextField txtNombreUsuarioSubcuenta;
    private javax.swing.JTextField txtNumeroSubcuenta;
    private javax.swing.JTextField txtSaldoSubcuenta;
    private javax.swing.JTextField txtTitular;
    // End of variables declaration//GEN-END:variables
}
