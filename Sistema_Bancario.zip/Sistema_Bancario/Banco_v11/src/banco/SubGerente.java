/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author eliag
 */
public class SubGerente {

    private String idSubgerente;              // [0] (PK)
    private String Nombre;                 // [1] Nombre
    private String FechaNacimiento;       // [2] Fecha de nacimiento
    private String Contrasenia;            // [3] Contrasenia
    private String NombreUsuario;          // [4] Nombre de usuario
    private String Correo;     // [5] Correo electrónico

    //Constructor
    public SubGerente(String idSubgerente, String Nombre, String FechaNacimiento, String Contrasenia, String NombreUsuario, String Correo) {
        this.idSubgerente = idSubgerente;
        this.Nombre = Nombre;
        this.FechaNacimiento = FechaNacimiento;
        this.Contrasenia = Contrasenia;
        this.NombreUsuario = NombreUsuario;
        this.Correo = Correo;
    }

    //Get y Set
    public String getIdSubgerente() {
        return idSubgerente;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getFechaNacimiento() {
        return FechaNacimiento;
    }

    public String getContrasenia() {
        return Contrasenia;
    }

    public String getNombreUsuario() {
        return NombreUsuario;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public void setContrasenia(String Contrasenia) {
        this.Contrasenia = Contrasenia;
    }

    public void setNombreUsuario(String NombreUsuario) {
        this.NombreUsuario = NombreUsuario;
    }

}

