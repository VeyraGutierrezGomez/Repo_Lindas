/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author eliag
 */
public class Usuario {
     /* [0] ID_Usuario (PK), [1] Nombre [2] Fecha_Nacimiento, [3] Contraseña */
    private String idUsuario;              // [0] (PK)
    private String Nombre;                 // [1] Nombre
    private String FechaNacimiento;        // [2] Fecha de nacimiento
    private String Contrasenia;            // [3] Contrasenia
    private String NombreUsuario;          // [4] Nombre de usuario
    private String correoElectronico;      // [5] Correo electrónico

    //Constructor
    public Usuario(String idUsuario, String Nombre, String FechaNacimiento, String Contrasenia, String NombreUsuario, String correoElectronico) {
        this.idUsuario = idUsuario;
        this.Nombre = Nombre;
        this.FechaNacimiento = FechaNacimiento;
        this.Contrasenia = Contrasenia;
        this.NombreUsuario = NombreUsuario;
        this.correoElectronico = correoElectronico;
    }

    //Get y Set
    public String getIdUsuario() {
        return idUsuario;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getFechaNacimiento() {
        return FechaNacimiento;
    }

    public String getContrasenia() {
        return Contrasenia;
    }

    public String getNombreUsuario() {
        return NombreUsuario;
    }

    public String getCorreoElectronico(){
        return correoElectronico;
    }
    
    public void setCorreoElectronico(String correoElectronico){
        this.correoElectronico = correoElectronico;
    }


    public void setNombreCompleto(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.FechaNacimiento = fechaNacimiento;
    }

    public void setContrasenia(String Contrasenia) {
        this.Contrasenia = Contrasenia;
    }

    public void setNombreUsuario(String NombreUsuario) {
        this.NombreUsuario = NombreUsuario;
    }

}