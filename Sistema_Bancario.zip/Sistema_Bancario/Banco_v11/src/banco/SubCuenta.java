/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author eliag
 */

public class SubCuenta {
    private String idCuenta;      // [0] ID_Cuenta (PK)
    private String tipoCuenta;    // [1] Tipo_Cuenta
    private String numeroSubTarjeta;       // [2] Numero_Cuenta
    private String claveSubInterbancaria;  // [3] Numero_Cuenta
    private String claveSubTransferencia;  // [4] Numero_Cuenta
    private String idUsuario;     // [5] ID_Usuario (FK)
    private String nip;           // [6] NIP
    private double saldo;         // [7] Saldo
    private String[] movimientos; // [8] Movimientos
    private int cont_movimientos; // [9] contador de los movimientos
    private boolean estado;       // [10] Tarjeta  (0)(false) desactivada  (1)(true) activada
    private int semanaUltimaConsulta;


    // Constructor
    public SubCuenta(String idCuenta, String tipoCuenta, String numeroSubTarjeta,String claveSubInterbancaria, String claveSubTransferencia, String idUsuario, String nip, double saldo,String[] movimientos, int cont_movimientos, boolean estado, int semanaUltimaConsulta) {
        this.idCuenta = idCuenta;
        this.tipoCuenta = tipoCuenta;
        this.numeroSubTarjeta = numeroSubTarjeta;
        this.claveSubInterbancaria = claveSubInterbancaria;
        this.claveSubTransferencia = claveSubTransferencia;
        this.idUsuario = idUsuario;
        this.nip = nip;
        this.saldo = saldo;
        this.movimientos = movimientos;
        this.cont_movimientos = cont_movimientos;
        this.estado = estado;
        this.semanaUltimaConsulta = semanaUltimaConsulta;
    }

    //Get
    public String getIdCuenta() {
        return idCuenta;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public String getSubNumeroTarjeta() {
        return numeroSubTarjeta;
    }
    
    public String getSubClaveInterbancaria() {
        return claveSubInterbancaria;
    }
    
    public String getSubClaveTransferencia() {
        return claveSubTransferencia;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public String[] getMovimientos() {
        return movimientos;
    }

    public int getCont_movimientos(){
        return cont_movimientos;
    }

    public String getNip() {
        return nip;
    }

    public double getSaldo() {
        return saldo;
    }

    public boolean getEstado() {
        return estado;
    }

    //set
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }
    
     public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public int getSemanaUltimaConsulta() {
        return semanaUltimaConsulta;
    }

    public void setSemanaUltimaConsulta(int semanaUltimaConsulta) {
        this.semanaUltimaConsulta = semanaUltimaConsulta;
    }

    public void setMovimientos(String movimiento,int cont_movimientos){
        this.movimientos[cont_movimientos] = movimiento;
        this.cont_movimientos = cont_movimientos+1;
    }

}