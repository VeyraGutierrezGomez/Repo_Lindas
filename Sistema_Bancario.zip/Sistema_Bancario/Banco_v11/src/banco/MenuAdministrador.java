/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package banco;

import static banco.Banco.fechaActual;
import java.awt.Component;
import java.util.List;
import java.util.Scanner;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;


public class MenuAdministrador extends javax.swing.JFrame {

    private Banco banco;
    private List<Cuenta> cuentas;
    private List<Usuario> usuarios;
    private List<SubCuenta> subCuentas;
    private List<SubGerente> subGerentes;
    private String idUsuario;
    private String idCuenta;
    private String idSubGerente;
    private String idSubcuenta;
    private String numeroTarjeta;
    private String claveInterbancaria;
    private String claveTransferencia;
       
    /**
     * Creates new form Adminstrador
     */
    public MenuAdministrador(Banco banco) {
    
        this.banco = banco;
        this.cuentas = banco.getCuentas();
        this.usuarios = banco.getUsuarios();
        this.subCuentas = banco.getSubCuentas();
        this.subGerentes = banco.getSubGerentes();
        
        initComponents();
        this.setLocationRelativeTo(null);
        
        
       
        inicializarValores();
        inicializarTablaBanco();
        inicializarTablaMovimientos();
        cargarSolicitudesATablaAdmin();
        
        tblCuentas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 
        tblSubcuentas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 
        tblSubgerentes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblMovimientosBanco.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        cargarCuentasATabla();
        cargarSubCuentasATabla();
        cargarSubGerentesATabla();
        cargarMovimientosBancoATabla();
        cargarReportesATablaAdmin("");
       
        
        tblCuentas.getModel().addTableModelListener(e -> {
            int columna = e.getColumn();
            int filaSeleccionada = e.getFirstRow();

            // Solo si se modificó la columna "Elección"
            if (columna == 5) {
                Boolean valorSeleccionado = (Boolean) tblCuentas.getValueAt(filaSeleccionada, columna);

                // Si se marcó en true, desmarcar el resto
                if (valorSeleccionado != null && valorSeleccionado) {
                    for (int i = 0; i < tblCuentas.getRowCount(); i++) {
                        if (i != filaSeleccionada) {
                            tblCuentas.setValueAt(false, i, columna);
                        }
                    }
                }
            }
        });
        
        tblSubcuentas.getModel().addTableModelListener(e -> {
            int columna = e.getColumn();
            int filaSeleccionada = e.getFirstRow();

            // Solo si se modificó la columna "Elección"
            if (columna == 6) {
                Boolean valorSeleccionado = (Boolean) tblSubcuentas.getValueAt(filaSeleccionada, columna);

                // Si se marcó en true, desmarcar el resto
                if (valorSeleccionado != null && valorSeleccionado) {
                    for (int i = 0; i < tblSubcuentas.getRowCount(); i++) {
                        if (i != filaSeleccionada) {
                            tblSubcuentas.setValueAt(false, i, columna);
                        }
                    }
                }
            }
        });
        
        tblSubgerentes.getModel().addTableModelListener(e -> {
            int columna = e.getColumn();
            int filaSeleccionada = e.getFirstRow();

            // Solo si se modificó la columna "Elección"
            if (columna == 5) {
                Boolean valorSeleccionado = (Boolean) tblSubgerentes.getValueAt(filaSeleccionada, columna);

                // Si se marcó en true, desmarcar el resto
                if (valorSeleccionado != null && valorSeleccionado) {
                    for (int i = 0; i < tblSubgerentes.getRowCount(); i++) {
                        if (i != filaSeleccionada) {
                            tblSubgerentes.setValueAt(false, i, columna);
                        }
                    }
                }
            }
        });
        
        // Bloquear campos que no deben editarse tanto en cuenta, subcuenta y subgerente
        
        //cuenta
        txtIdCuenta.setEditable(false);
        txtNumeroTarjeta.setEditable(false);
        txtClaveInterbancaria.setEditable(false);
        txtClaveTransferencia.setEditable(false);
        
        //subcuenta
        txtIdSubcuenta.setEditable(false);
        txtNumeroSubcuenta.setEditable(false);
        txtIdUsuario.setEditable(false);
        txtFechaSubcuenta.setEditable(false);
        txtTitular.setEditable(false);                                                
        txtNombreUsuarioSubcuenta.setEditable(false);
        txtCorreoSubcuenta.setEditable(false);
        txtClaveIntSubcuenta.setEditable(false);
        txtClaveTranSubcuenta.setEditable(false);
        
        //subgerente
        txtIdSubgerente.setEditable(false);
        

        //Listener para seleccionar fila y cargar datos a cuenta y + dar clic para deseleccionar cuentas
        
        //Variable para controlar los clics
        final int[] ultimaFilaSeleccionada = {-1};

        //MouseListener para detectar doble clic en la misma fila
        tblCuentas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                int fila = tblCuentas.rowAtPoint(evt.getPoint());

                if (fila == ultimaFilaSeleccionada[0]) {
                    tblCuentas.clearSelection();
                    ultimaFilaSeleccionada[0] = -1;

                    //Limpiar campos
                    txtIdCuenta.setText("");
                    txtNumeroTarjeta.setText("");
                    txtNombreTitular.setText("");
                    txtSaldoInicialCuenta.setText("");
                    txtNipCuenta.setText("");
                    txtClaveInterbancaria.setText("");
                    txtClaveTransferencia.setText("");
                    txtFecha.setText("");
                    txtUsuarioCuenta.setText("");
                    txtContraseniaCuenta.setText("");
                    txtCorreoCuenta.setText("");
                }
            }
        });

        //ListSelectionListener para cargar datos
        tblCuentas.getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent event) {
                if (!event.getValueIsAdjusting() && tblCuentas.getSelectedRow() != -1) {
                    int fila = tblCuentas.getSelectedRow();
                    ultimaFilaSeleccionada[0] = fila;

                    DefaultTableModel modelo = (DefaultTableModel) tblCuentas.getModel();

                    txtIdCuenta.setText(modelo.getValueAt(fila, 0).toString());
                    txtNumeroTarjeta.setText(modelo.getValueAt(fila, 1).toString());
                    txtNombreTitular.setText(modelo.getValueAt(fila, 2).toString());
                    txtSaldoInicialCuenta.setText(modelo.getValueAt(fila, 3).toString());

                    String idCuenta = modelo.getValueAt(fila, 0).toString();

                    for (Cuenta cuenta : cuentas) {
                        if (cuenta.getIdCuenta().equals(idCuenta)) {
                            txtNipCuenta.setText(cuenta.getNip());
                            txtClaveInterbancaria.setText(cuenta.getClaveInterbancaria());
                            txtClaveTransferencia.setText(cuenta.getClaveTransferencia());
                            break;
                        }
                    }

                    for (Usuario usuario : usuarios) {
                        if (usuario.getIdUsuario().equals(idCuenta)) {
                            txtFecha.setText(usuario.getFechaNacimiento());
                            txtUsuarioCuenta.setText(usuario.getNombreUsuario());
                            txtContraseniaCuenta.setText(usuario.getContrasenia());
                            txtCorreoCuenta.setText(usuario.getCorreoElectronico());
                            break;
                        }
                    }
                }
            }
        });

        
        //Listener para seleccionar fila y cargar datos a cuenta y + dar clic para deseleccionar subcuentas
  
        //Variable para controlar los clics
        final int[] ultimaFilaSeleccionadaSub = {-1};

        //MouseListener para detectar clic repetido en la misma fila
        tblSubcuentas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                int fila = tblSubcuentas.rowAtPoint(evt.getPoint());

                if (fila == ultimaFilaSeleccionadaSub[0]) {
                    tblSubcuentas.clearSelection();
                    ultimaFilaSeleccionadaSub[0] = -1;

                    // Limpiar campos
                    txtIdSubcuenta.setText("");
                    txtNumeroSubcuenta.setText("");
                    txtIdUsuario.setText("");
                    cmbTipoCuenta.setSelectedIndex(-1);
                    txtSaldoSubcuenta.setText("");
                    txtNipSubcuenta.setText("");
                    txtClaveIntSubcuenta.setText("");
                    txtClaveTranSubcuenta.setText("");
                    txtFechaSubcuenta.setText("");
                    txtTitular.setText("");
                    txtNombreUsuarioSubcuenta.setText("");
                    txtCorreoSubcuenta.setText("");
                    txtCuentaEje.setText("");
                    txtNipCuentaEje.setText("");
                }
            }
        });

        // ListSelectionListener para cargar datos
        tblSubcuentas.getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent event) {
                if (!event.getValueIsAdjusting() && tblSubcuentas.getSelectedRow() != -1) {
                    int fila = tblSubcuentas.getSelectedRow();
                    ultimaFilaSeleccionadaSub[0] = fila;

                    DefaultTableModel modelo = (DefaultTableModel) tblSubcuentas.getModel();

                    txtIdSubcuenta.setText(modelo.getValueAt(fila, 0).toString());
                    txtNumeroSubcuenta.setText(modelo.getValueAt(fila, 1).toString());
                    txtIdUsuario.setText(modelo.getValueAt(fila, 2).toString());
                    cmbTipoCuenta.setSelectedItem(modelo.getValueAt(fila, 3).toString());
                    txtSaldoSubcuenta.setText(modelo.getValueAt(fila, 4).toString());

                    String idSubcuenta = modelo.getValueAt(fila, 0).toString();
                    String idUsuario = modelo.getValueAt(fila, 2).toString();

                    for (SubCuenta subcuenta : subCuentas) {
                        if (subcuenta.getIdCuenta().equals(idSubcuenta)) {
                            txtNipSubcuenta.setText(subcuenta.getNip());
                            txtClaveIntSubcuenta.setText(subcuenta.getSubClaveInterbancaria());
                            txtClaveTranSubcuenta.setText(subcuenta.getSubClaveTransferencia());
                            break;
                        }
                    }

                    for (Usuario usuario : usuarios) {
                        if (usuario.getIdUsuario().equals(idUsuario)) {
                            txtFechaSubcuenta.setText(usuario.getFechaNacimiento());
                            txtTitular.setText(usuario.getNombre());
                            txtNombreUsuarioSubcuenta.setText(usuario.getNombreUsuario());
                            txtCorreoSubcuenta.setText(usuario.getCorreoElectronico());
                            break;
                        }
                    }

                    for (Cuenta cuentaeje : cuentas) {
                        if (cuentaeje.getIdUsuario().equals(idUsuario)) {
                            txtCuentaEje.setText(cuentaeje.getNumeroTarjeta());
                            txtNipCuentaEje.setText(cuentaeje.getNip());
                        }
                    }
                }
            }
        });

        
               
        //Listener para seleccionar fila y cargar datos a cuenta y + dar clic para deseleccionar subgerentes
        //Variable para controlar los clic
        final int[] ultimaFilaSeleccionadaGerente = {-1};

        tblSubgerentes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                int fila = tblSubgerentes.rowAtPoint(evt.getPoint());

                if (fila == ultimaFilaSeleccionadaGerente[0]) {
                    tblSubgerentes.clearSelection();
                    ultimaFilaSeleccionadaGerente[0] = -1;

                    //Limpiar campos
                    txtIdSubgerente.setText("");
                    txtNombreSubgerente.setText("");
                    txtFechaSubgerente.setText("");
                    txtCorreoSubgerente.setText("");
                    txtUsuarioSubgerente.setText("");
                    txtContraseniaSubgerente.setText("");
                }
            }
        });

        tblSubgerentes.getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent event) {
                if (!event.getValueIsAdjusting() && tblSubgerentes.getSelectedRow() != -1) {
                    int fila = tblSubgerentes.getSelectedRow();
                    ultimaFilaSeleccionadaGerente[0] = fila;

                    DefaultTableModel modelo = (DefaultTableModel) tblSubgerentes.getModel();

                    txtIdSubgerente.setText(modelo.getValueAt(fila, 0).toString());
                    txtNombreSubgerente.setText(modelo.getValueAt(fila, 1).toString());
                    txtUsuarioSubgerente.setText(modelo.getValueAt(fila, 2).toString());
                    txtCorreoSubgerente.setText(modelo.getValueAt(fila, 3).toString());

                    //cargar datos ocultos
                    for (SubGerente subgerente : subGerentes) {
                        if (subgerente.getNombreUsuario().equals(modelo.getValueAt(fila, 2).toString())) {
                            txtFechaSubgerente.setText(subgerente.getFechaNacimiento());
                            txtContraseniaSubgerente.setText(subgerente.getContrasenia());
                            break;
                        }
                    }
                }
            }
        });

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Administrador = new javax.swing.JTabbedPane();
        Subgerentes = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSubgerentes = new javax.swing.JTable();
        txtNombreSubgerente = new javax.swing.JTextField();
        btnEliminarSubgerente = new javax.swing.JButton();
        btnIngresarSubgerente = new javax.swing.JButton();
        btnActualizarSubgerente = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txtFechaSubgerente = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtUsuarioSubgerente = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtContraseniaSubgerente = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtCorreoSubgerente = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtIdSubgerente = new javax.swing.JTextField();
        btnRegresar2 = new javax.swing.JButton();
        Cuentas = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblCuentas = new javax.swing.JTable();
        txtNumeroTarjeta = new javax.swing.JTextField();
        btnEliminarCuenta = new javax.swing.JButton();
        btnIngresarCuenta = new javax.swing.JButton();
        btnActualizarCuenta = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        txtClaveInterbancaria = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtClaveTransferencia = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtNombreTitular = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtUsuarioCuenta = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtContraseniaCuenta = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtNipCuenta = new javax.swing.JTextField();
        txtCorreoCuenta = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtSaldoInicialCuenta = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        txtIdCuenta = new javax.swing.JTextField();
        btnRegresar = new javax.swing.JButton();
        Subcuentas = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblSubcuentas = new javax.swing.JTable();
        txtCuentaEje = new javax.swing.JTextField();
        btnEliminarSubcuenta = new javax.swing.JButton();
        btnIngresarSubcuenta = new javax.swing.JButton();
        btnActualizarSubcuenta = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        txtNipCuentaEje = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        txtIdUsuario = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        txtTitular = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        txtFechaSubcuenta = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        txtNombreUsuarioSubcuenta = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        txtCorreoSubcuenta = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        txtClaveIntSubcuenta = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        txtClaveTranSubcuenta = new javax.swing.JTextField();
        txtSaldoSubcuenta = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        txtNumeroSubcuenta = new javax.swing.JTextField();
        txtNipSubcuenta = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        txtIdSubcuenta = new javax.swing.JTextField();
        cmbTipoCuenta = new javax.swing.JComboBox<>();
        btnRegresar3 = new javax.swing.JButton();
        ReportesSolicitudes = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblReporteSolicitud = new javax.swing.JTable();
        btnInicioSesionAdmin9 = new javax.swing.JButton();
        btnInicioSesionAdmin11 = new javax.swing.JButton();
        txtReporteSolicitud = new javax.swing.JTextField();
        btnBuscarReporteSolicitud = new javax.swing.JButton();
        btnRegresar4 = new javax.swing.JButton();
        Movimientos = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtMovimientos = new javax.swing.JTable();
        txtMovimiento = new javax.swing.JTextField();
        btnBuscarMovimiento = new javax.swing.JButton();
        btnRegresar5 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblMovimientosBanco = new javax.swing.JTable();
        btnRegresar6 = new javax.swing.JButton();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblSolicitud = new javax.swing.JTable();
        btnRegresar7 = new javax.swing.JButton();
        btnInicioSesionAdmin12 = new javax.swing.JButton();
        btnInicioSesionAdmin10 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        Administrador.setBackground(new java.awt.Color(206, 231, 255));

        Subgerentes.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 102));
        jLabel2.setText("Nombre Completo:");

        tblSubgerentes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Usuario", "Correo", "Eleccion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblSubgerentes);

        txtNombreSubgerente.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNombreSubgerente.setText("Nombre del subgerente");

        btnEliminarSubgerente.setBackground(new java.awt.Color(0, 0, 102));
        btnEliminarSubgerente.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnEliminarSubgerente.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminarSubgerente.setText("ELIMINAR");
        btnEliminarSubgerente.setToolTipText("");
        btnEliminarSubgerente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEliminarSubgerente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarSubgerenteActionPerformed(evt);
            }
        });

        btnIngresarSubgerente.setBackground(new java.awt.Color(0, 0, 102));
        btnIngresarSubgerente.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnIngresarSubgerente.setForeground(new java.awt.Color(255, 255, 255));
        btnIngresarSubgerente.setText("INGRESAR");
        btnIngresarSubgerente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnIngresarSubgerente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarSubgerenteActionPerformed(evt);
            }
        });

        btnActualizarSubgerente.setBackground(new java.awt.Color(0, 0, 102));
        btnActualizarSubgerente.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnActualizarSubgerente.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizarSubgerente.setText("ACTUALIZAR");
        btnActualizarSubgerente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnActualizarSubgerente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarSubgerenteActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 102));
        jLabel3.setText("Fecha de Nacimiento:");

        txtFechaSubgerente.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtFechaSubgerente.setText("DD/MM/AAAA");
        txtFechaSubgerente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechaSubgerenteActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 102));
        jLabel4.setText("Usuario:");

        txtUsuarioSubgerente.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtUsuarioSubgerente.setText("Usuario");

        jLabel5.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("Contraseña:");

        txtContraseniaSubgerente.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtContraseniaSubgerente.setText("•••••••••••••");

        jLabel6.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("Correo:");

        txtCorreoSubgerente.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtCorreoSubgerente.setText("coreo@dominio.com");

        jLabel17.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 0, 102));
        jLabel17.setText("Id:");

        txtIdSubgerente.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtIdSubgerente.setText("Id Automático");

        btnRegresar2.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar2.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar2.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar2.setText("REGRESAR");
        btnRegresar2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SubgerentesLayout = new javax.swing.GroupLayout(Subgerentes);
        Subgerentes.setLayout(SubgerentesLayout);
        SubgerentesLayout.setHorizontalGroup(
            SubgerentesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SubgerentesLayout.createSequentialGroup()
                .addGroup(SubgerentesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SubgerentesLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(SubgerentesLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addGroup(SubgerentesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtFechaSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombreSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 173, Short.MAX_VALUE)
                        .addGroup(SubgerentesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUsuarioSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtContraseniaSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCorreoSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(91, 91, 91))
                    .addGroup(SubgerentesLayout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(btnEliminarSubgerente)
                        .addGap(156, 156, 156)
                        .addComponent(btnActualizarSubgerente)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnIngresarSubgerente)
                        .addGap(121, 121, 121)
                        .addComponent(btnRegresar2)
                        .addGap(36, 36, 36)))
                .addContainerGap())
        );
        SubgerentesLayout.setVerticalGroup(
            SubgerentesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SubgerentesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SubgerentesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(SubgerentesLayout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCorreoSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(SubgerentesLayout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtIdSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(SubgerentesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(SubgerentesLayout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtUsuarioSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtContraseniaSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(SubgerentesLayout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombreSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtFechaSubgerente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addGroup(SubgerentesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminarSubgerente)
                    .addComponent(btnActualizarSubgerente)
                    .addComponent(btnIngresarSubgerente)
                    .addComponent(btnRegresar2))
                .addGap(20, 20, 20))
        );

        Administrador.addTab("Subgerentes", Subgerentes);

        Cuentas.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Id:");

        tblCuentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "# de Cuenta", "Titular", "Saldo", "Tarjeta", "Eleccion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.String.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblCuentas);

        txtNumeroTarjeta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNumeroTarjeta.setText("Numero de trajeta automatico");

        btnEliminarCuenta.setBackground(new java.awt.Color(0, 0, 102));
        btnEliminarCuenta.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnEliminarCuenta.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminarCuenta.setText("ELIMINAR");
        btnEliminarCuenta.setToolTipText("");
        btnEliminarCuenta.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEliminarCuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarCuentaActionPerformed(evt);
            }
        });

        btnIngresarCuenta.setBackground(new java.awt.Color(0, 0, 102));
        btnIngresarCuenta.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnIngresarCuenta.setForeground(new java.awt.Color(255, 255, 255));
        btnIngresarCuenta.setText("INGRESAR");
        btnIngresarCuenta.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnIngresarCuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarCuentaActionPerformed(evt);
            }
        });

        btnActualizarCuenta.setBackground(new java.awt.Color(0, 0, 102));
        btnActualizarCuenta.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnActualizarCuenta.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizarCuenta.setText("ACTUALIZAR");
        btnActualizarCuenta.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnActualizarCuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarCuentaActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("Clave Interbancaria:");

        txtClaveInterbancaria.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtClaveInterbancaria.setText("Clave interbancaria automatica");
        txtClaveInterbancaria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtClaveInterbancariaActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("Clave de Transferencia:");

        txtClaveTransferencia.setFont(new java.awt.Font("Candara", 0, 10)); // NOI18N
        txtClaveTransferencia.setText("Clave de transferencia automatica");
        txtClaveTransferencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtClaveTransferenciaActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 102));
        jLabel10.setText("Nombre del Titular:");

        txtNombreTitular.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNombreTitular.setText("Nombre completo del titular");

        jLabel11.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 102));
        jLabel11.setText("Fecha de Nacimiento:");

        txtFecha.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtFecha.setText("DD/MM/AAAA");

        jLabel12.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 102));
        jLabel12.setText("Usuario:");

        txtUsuarioCuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtUsuarioCuenta.setText("Nombre de usuario (Aplicacion)");

        jLabel13.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 102));
        jLabel13.setText("NIP:");

        jLabel14.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 102));
        jLabel14.setText("Contraseña:");

        txtContraseniaCuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtContraseniaCuenta.setText("•••••• (Aplicacion)");
        txtContraseniaCuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContraseniaCuentaActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 102));
        jLabel15.setText("Correo:");

        txtNipCuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNipCuenta.setText("NIP de la tarjeta");

        txtCorreoCuenta.setFont(new java.awt.Font("Candara", 0, 11)); // NOI18N
        txtCorreoCuenta.setText("coreo@dominio.com (Aplicacion)");

        jLabel16.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 102));
        jLabel16.setText("Saldo Inicial:");

        txtSaldoInicialCuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtSaldoInicialCuenta.setText("$$$");
        txtSaldoInicialCuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSaldoInicialCuentaActionPerformed(evt);
            }
        });

        jLabel35.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(0, 0, 102));
        jLabel35.setText("Numero de Cuenta:");

        txtIdCuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtIdCuenta.setText("Id automatico");

        btnRegresar.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar.setText("REGRESAR");
        btnRegresar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout CuentasLayout = new javax.swing.GroupLayout(Cuentas);
        Cuentas.setLayout(CuentasLayout);
        CuentasLayout.setHorizontalGroup(
            CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CuentasLayout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CuentasLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(txtCorreoCuenta, javax.swing.GroupLayout.DEFAULT_SIZE, 184, Short.MAX_VALUE)
                    .addComponent(txtUsuarioCuenta)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtIdCuenta)
                    .addComponent(txtNumeroTarjeta)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtClaveInterbancaria)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtClaveTransferencia))
                .addGap(18, 18, 18)
                .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnRegresar, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombreTitular)
                    .addComponent(txtFecha)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNipCuenta)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtSaldoInicialCuenta)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtContraseniaCuenta, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE))
                .addGap(29, 29, 29))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CuentasLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(btnEliminarCuenta)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnActualizarCuenta)
                .addGap(222, 222, 222)
                .addComponent(btnIngresarCuenta)
                .addGap(142, 142, 142))
        );
        CuentasLayout.setVerticalGroup(
            CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CuentasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CuentasLayout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtIdCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnRegresar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNumeroTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombreTitular, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtClaveInterbancaria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtClaveTransferencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNipCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtUsuarioCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSaldoInicialCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtContraseniaCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(txtCorreoCuenta))
                        .addGap(0, 40, Short.MAX_VALUE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(27, 27, 27)
                .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnActualizarCuenta)
                    .addComponent(btnIngresarCuenta)
                    .addComponent(btnEliminarCuenta))
                .addGap(39, 39, 39))
        );

        Administrador.addTab("Cuentas", Cuentas);

        Subcuentas.setBackground(new java.awt.Color(255, 255, 255));

        jLabel18.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 102));
        jLabel18.setText("Numero de Cuenta Eje:");

        tblSubcuentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "# Subcuenta", "Id Usuario", "Tipo de Cuenta", "Saldo", "Eleccion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Double.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(tblSubcuentas);

        txtCuentaEje.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtCuentaEje.setText("Numero de cuenta eje");

        btnEliminarSubcuenta.setBackground(new java.awt.Color(0, 0, 102));
        btnEliminarSubcuenta.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnEliminarSubcuenta.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminarSubcuenta.setText("ELIMINAR");
        btnEliminarSubcuenta.setToolTipText("");
        btnEliminarSubcuenta.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEliminarSubcuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarSubcuentaActionPerformed(evt);
            }
        });

        btnIngresarSubcuenta.setBackground(new java.awt.Color(0, 0, 102));
        btnIngresarSubcuenta.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnIngresarSubcuenta.setForeground(new java.awt.Color(255, 255, 255));
        btnIngresarSubcuenta.setText("INGRESAR");
        btnIngresarSubcuenta.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnIngresarSubcuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarSubcuentaActionPerformed(evt);
            }
        });

        btnActualizarSubcuenta.setBackground(new java.awt.Color(0, 0, 102));
        btnActualizarSubcuenta.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnActualizarSubcuenta.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizarSubcuenta.setText("ACTUALIZAR");
        btnActualizarSubcuenta.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnActualizarSubcuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarSubcuentaActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 102));
        jLabel19.setText("NIP Cuenta Eje:");

        txtNipCuentaEje.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNipCuentaEje.setText("Nip de cuenta eje");
        txtNipCuentaEje.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtNipCuentaEjeFocusLost(evt);
            }
        });
        txtNipCuentaEje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNipCuentaEjeActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 102));
        jLabel20.setText("Id Usuario:");

        txtIdUsuario.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtIdUsuario.setText("Id del usuario");

        jLabel21.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 102));
        jLabel21.setText("Nombre del Titular:");

        txtTitular.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtTitular.setText("Nombre completo del titular");
        txtTitular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTitularActionPerformed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 0, 102));
        jLabel22.setText("Fecha de Nacimiento:");

        txtFechaSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtFechaSubcuenta.setText("DD/MM/AAAA");

        jLabel24.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 0, 102));
        jLabel24.setText("Nombre de Usuario:");

        txtNombreUsuarioSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNombreUsuarioSubcuenta.setText("Nombre del usuario");

        jLabel27.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(0, 0, 102));
        jLabel27.setText("Correo:");

        txtCorreoSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtCorreoSubcuenta.setText("coreo@dominio.com");
        txtCorreoSubcuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoSubcuentaActionPerformed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 0, 102));
        jLabel28.setText("Clave Interbancaria Subcuenta:");

        txtClaveIntSubcuenta.setFont(new java.awt.Font("Candara", 0, 10)); // NOI18N
        txtClaveIntSubcuenta.setText("Clave interbancaria subcuenta automatica");
        txtClaveIntSubcuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtClaveIntSubcuentaActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("Candara", 1, 12)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(0, 0, 102));
        jLabel29.setText("Clave de Transferencia Subcuenta:");

        txtClaveTranSubcuenta.setFont(new java.awt.Font("Candara", 0, 10)); // NOI18N
        txtClaveTranSubcuenta.setText("Clave de transferencia subcuneta automatica");

        txtSaldoSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtSaldoSubcuenta.setText("Saldo inicial subcuenta");

        jLabel30.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(0, 0, 102));
        jLabel30.setText("Numero de Subcuenta:");

        jLabel31.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(0, 0, 102));
        jLabel31.setText("Tipo de Cuenta:");

        jLabel33.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(0, 0, 102));
        jLabel33.setText("NIP Subcuenta:");

        txtNumeroSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNumeroSubcuenta.setText("Numero de subcuenta automatico");

        txtNipSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtNipSubcuenta.setText("NIP de la subcuenta");

        jLabel34.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(0, 0, 102));
        jLabel34.setText("Saldo Inicial Subcuenta:");

        jLabel36.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(0, 0, 102));
        jLabel36.setText("Id:");

        txtIdSubcuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtIdSubcuenta.setText("Id automatico");

        cmbTipoCuenta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ahorro", "Corriente", "Plazo Fijo", "Nomina" }));

        btnRegresar3.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar3.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar3.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar3.setText("REGRESAR");
        btnRegresar3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SubcuentasLayout = new javax.swing.GroupLayout(Subcuentas);
        Subcuentas.setLayout(SubcuentasLayout);
        SubcuentasLayout.setHorizontalGroup(
            SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SubcuentasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 525, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SubcuentasLayout.createSequentialGroup()
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtFechaSubcuenta)
                            .addComponent(txtNombreUsuarioSubcuenta)
                            .addComponent(txtIdUsuario)
                            .addComponent(txtTitular)
                            .addGroup(SubcuentasLayout.createSequentialGroup()
                                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNipCuentaEje, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtCuentaEje, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNumeroSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtClaveIntSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28)
                            .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtClaveTranSubcuenta)
                            .addComponent(txtNipSubcuenta)
                            .addComponent(txtSaldoSubcuenta)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbTipoCuenta, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(SubcuentasLayout.createSequentialGroup()
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCorreoSubcuenta))))
                .addGap(15, 15, 15))
            .addGroup(SubcuentasLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(btnEliminarSubcuenta)
                .addGap(147, 147, 147)
                .addComponent(btnActualizarSubcuenta)
                .addGap(144, 144, 144)
                .addComponent(btnIngresarSubcuenta)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnRegresar3, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
        );
        SubcuentasLayout.setVerticalGroup(
            SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SubcuentasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(SubcuentasLayout.createSequentialGroup()
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtIdSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCorreoSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCuentaEje, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNumeroSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNipCuentaEje, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtClaveIntSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtIdUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtClaveTranSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTitular, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbTipoCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtFechaSubcuenta, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SubcuentasLayout.createSequentialGroup()
                                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNipSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SubcuentasLayout.createSequentialGroup()
                                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNombreUsuarioSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SubcuentasLayout.createSequentialGroup()
                                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtSaldoSubcuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnEliminarSubcuenta)
                    .addGroup(SubcuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnActualizarSubcuenta)
                        .addComponent(btnIngresarSubcuenta))
                    .addComponent(btnRegresar3))
                .addGap(24, 24, 24))
        );

        Administrador.addTab("Subcuentas", Subcuentas);

        ReportesSolicitudes.setBackground(new java.awt.Color(255, 255, 255));

        tblReporteSolicitud.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Id", "Descripcion", "Estado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(tblReporteSolicitud);

        btnInicioSesionAdmin9.setBackground(new java.awt.Color(0, 0, 102));
        btnInicioSesionAdmin9.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnInicioSesionAdmin9.setForeground(new java.awt.Color(255, 255, 255));
        btnInicioSesionAdmin9.setText("EN PROCESO");
        btnInicioSesionAdmin9.setToolTipText("");
        btnInicioSesionAdmin9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnInicioSesionAdmin9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioSesionAdmin9ActionPerformed(evt);
            }
        });

        btnInicioSesionAdmin11.setBackground(new java.awt.Color(0, 0, 102));
        btnInicioSesionAdmin11.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnInicioSesionAdmin11.setForeground(new java.awt.Color(255, 255, 255));
        btnInicioSesionAdmin11.setText("FINALIZADO");
        btnInicioSesionAdmin11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnInicioSesionAdmin11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioSesionAdmin11ActionPerformed(evt);
            }
        });

        txtReporteSolicitud.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtReporteSolicitud.setText("Numero de Cuenta");
        txtReporteSolicitud.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtReporteSolicitudActionPerformed(evt);
            }
        });

        btnBuscarReporteSolicitud.setBackground(new java.awt.Color(0, 0, 102));
        btnBuscarReporteSolicitud.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnBuscarReporteSolicitud.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscarReporteSolicitud.setText("BUSCAR");
        btnBuscarReporteSolicitud.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBuscarReporteSolicitud.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarReporteSolicitudActionPerformed(evt);
            }
        });

        btnRegresar4.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar4.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar4.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar4.setText("REGRESAR");
        btnRegresar4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ReportesSolicitudesLayout = new javax.swing.GroupLayout(ReportesSolicitudes);
        ReportesSolicitudes.setLayout(ReportesSolicitudesLayout);
        ReportesSolicitudesLayout.setHorizontalGroup(
            ReportesSolicitudesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ReportesSolicitudesLayout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addGroup(ReportesSolicitudesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 920, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(ReportesSolicitudesLayout.createSequentialGroup()
                        .addComponent(txtReporteSolicitud, javax.swing.GroupLayout.PREFERRED_SIZE, 748, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnBuscarReporteSolicitud, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(25, 25, 25))
            .addGroup(ReportesSolicitudesLayout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addComponent(btnInicioSesionAdmin9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnInicioSesionAdmin11)
                .addGap(234, 234, 234)
                .addComponent(btnRegresar4, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61))
        );
        ReportesSolicitudesLayout.setVerticalGroup(
            ReportesSolicitudesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReportesSolicitudesLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(ReportesSolicitudesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtReporteSolicitud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarReporteSolicitud))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(ReportesSolicitudesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInicioSesionAdmin9)
                    .addComponent(btnInicioSesionAdmin11)
                    .addComponent(btnRegresar4))
                .addContainerGap(49, Short.MAX_VALUE))
        );

        Administrador.addTab("Reportes", ReportesSolicitudes);

        Movimientos.setBackground(new java.awt.Color(255, 255, 255));

        txtMovimientos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Id", "Descripcion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(txtMovimientos);

        txtMovimiento.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N
        txtMovimiento.setText("Numero de Cuenta");
        txtMovimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMovimientoActionPerformed(evt);
            }
        });

        btnBuscarMovimiento.setBackground(new java.awt.Color(0, 0, 102));
        btnBuscarMovimiento.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnBuscarMovimiento.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscarMovimiento.setText("BUSCAR");
        btnBuscarMovimiento.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBuscarMovimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarMovimientoActionPerformed(evt);
            }
        });

        btnRegresar5.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar5.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar5.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar5.setText("REGRESAR");
        btnRegresar5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MovimientosLayout = new javax.swing.GroupLayout(Movimientos);
        Movimientos.setLayout(MovimientosLayout);
        MovimientosLayout.setHorizontalGroup(
            MovimientosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MovimientosLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(MovimientosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(MovimientosLayout.createSequentialGroup()
                        .addComponent(txtMovimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 96, Short.MAX_VALUE)
                        .addComponent(btnBuscarMovimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane5))
                .addGap(73, 73, 73))
            .addGroup(MovimientosLayout.createSequentialGroup()
                .addGap(403, 403, 403)
                .addComponent(btnRegresar5, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        MovimientosLayout.setVerticalGroup(
            MovimientosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MovimientosLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(MovimientosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMovimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarMovimiento))
                .addGap(30, 30, 30)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(btnRegresar5)
                .addGap(24, 24, 24))
        );

        Administrador.addTab("Movimientos de una cuenta", Movimientos);

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        tblMovimientosBanco.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Id", "Descripcion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane6.setViewportView(tblMovimientosBanco);

        btnRegresar6.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar6.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar6.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar6.setText("REGRESAR");
        btnRegresar6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(34, Short.MAX_VALUE)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 898, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(400, 400, 400)
                .addComponent(btnRegresar6, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(btnRegresar6)
                .addGap(19, 19, 19))
        );

        jTabbedPane1.addTab("", jPanel1);

        Administrador.addTab("Movimientos del banco", jTabbedPane1);

        jTabbedPane2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        tblSolicitud.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Id", "Descripcion", "Estado", "SubGerente"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane7.setViewportView(tblSolicitud);

        btnRegresar7.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar7.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar7.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar7.setText("REGRESAR");
        btnRegresar7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar7ActionPerformed(evt);
            }
        });

        btnInicioSesionAdmin12.setBackground(new java.awt.Color(0, 0, 102));
        btnInicioSesionAdmin12.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnInicioSesionAdmin12.setForeground(new java.awt.Color(255, 255, 255));
        btnInicioSesionAdmin12.setText("APROBAR");
        btnInicioSesionAdmin12.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnInicioSesionAdmin12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioSesionAdmin12ActionPerformed(evt);
            }
        });

        btnInicioSesionAdmin10.setBackground(new java.awt.Color(0, 0, 102));
        btnInicioSesionAdmin10.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnInicioSesionAdmin10.setForeground(new java.awt.Color(255, 255, 255));
        btnInicioSesionAdmin10.setText("RECHAZAR");
        btnInicioSesionAdmin10.setToolTipText("");
        btnInicioSesionAdmin10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnInicioSesionAdmin10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioSesionAdmin10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 920, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(121, 121, 121)
                .addComponent(btnInicioSesionAdmin10)
                .addGap(220, 220, 220)
                .addComponent(btnInicioSesionAdmin12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnRegresar7, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(81, 81, 81))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRegresar7)
                    .addComponent(btnInicioSesionAdmin12)
                    .addComponent(btnInicioSesionAdmin10))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("", jPanel2);

        Administrador.addTab("Solicitudes", jTabbedPane2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Administrador, javax.swing.GroupLayout.PREFERRED_SIZE, 970, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Administrador, javax.swing.GroupLayout.PREFERRED_SIZE, 503, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        Administrador.getAccessibleContext().setAccessibleName("Administrador");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private String mapEstado(int estado) {
        switch (estado) {
            case 1: return "Pendiente";
            case 2: return "En Proceso";
            case 3: return "Finalizado";
            default: return "Desconocido";
        }
    }
    
    private String mapEstado1(int estado) {
        switch (estado) {
            case 1: return "Aprobado";
            case 2: return "Rechazado";
            case 3: return "En espera";
            default: return "";
        }
    }
    
    private void cargarReportesATablaAdmin(String filtroCuenta) {
    DefaultTableModel modelo = (DefaultTableModel) tblReporteSolicitud.getModel();
    modelo.setRowCount(0);
    int i = 1;

    for (Reporte rep : banco.getReportes()) {
        if (!filtroCuenta.isEmpty() && !rep.getNumeroCuenta().equals(filtroCuenta)) {
            continue;
        }
        modelo.addRow(new Object[]{
            i++,
            rep.getDescripcion(),
            mapEstado(rep.getEstado())
        });
    }
}

     private void cambiarEstadoReporte(int nuevoEstado) {
    int fila = tblReporteSolicitud.getSelectedRow();

    if (fila < 0) {
        JOptionPane.showMessageDialog(this, "Selecciona un reporte primero.");
        return;
    }

    // Obtiene el reporte correspondiente
    Reporte rep = banco.getReportes().get(fila);
    rep.setEstado(nuevoEstado);

    // Actualiza solo la celda del estado en la tabla
    String textoNuevoEstado = mapEstado(nuevoEstado);
    DefaultTableModel modelo = (DefaultTableModel) tblReporteSolicitud.getModel();
    modelo.setValueAt(textoNuevoEstado, fila, 2); 

    // Muestra mensaje de confirmación
    JOptionPane.showMessageDialog(this,
        "El estado del reporte ha sido cambiado a: " + textoNuevoEstado,
        "Estado actualizado",
        JOptionPane.INFORMATION_MESSAGE);
}
     
private void cargarSolicitudesATablaAdmin() {
    DefaultTableModel modelo = (DefaultTableModel) tblSolicitud.getModel();
    modelo.setRowCount(0);
    int i = 1;

    for (SolicitudInversion sol : banco.getSolicitudes()) {
        modelo.addRow(new Object[]{
            i++,
            sol.getNumeroCuenta(),
            mapEstado1(sol.getEstado()),
            sol.getCuenta1()
        });
    }
}

    private void cambiarEstadoSolicitud(int nuevoEstado) {
    int fila = tblSolicitud.getSelectedRow();
    SubCuenta subcuentaEliminar=null;

    if (fila < 0) {
        JOptionPane.showMessageDialog(this, "Selecciona una solicitud primero.");
        return;
    }

    // Obtiene el reporte correspondiente
    SolicitudInversion sol = banco.getSolicitudes().get(fila);
    int actualEstado = sol.getEstado();
    
    switch(actualEstado){
        case 1:
            JOptionPane.showMessageDialog(this,
                "La cuenta ya ha sido aprobada",
                "Atencion",
                JOptionPane.INFORMATION_MESSAGE);
            break;
        case 2:
            JOptionPane.showMessageDialog(this,
                "La cuenta ya ha sido rechazada",
                "Atencion",
            JOptionPane.INFORMATION_MESSAGE);
            break;
        case 3:
            sol.setEstado(nuevoEstado);
        
            //Si la solicitud fue Rechazada
            if(nuevoEstado==2){

                //entonces eliminar SubCuenta
                for(SubCuenta subcuenta: subCuentas){
                    if(subcuenta.getSubNumeroTarjeta().equals(sol.getNumeroCuenta())){
                        subcuentaEliminar = subcuenta;
                        break;
                    }
                }

                if (subcuentaEliminar != null) {
                    subCuentas.remove(subcuentaEliminar);
                }        
                cargarSubCuentasATabla(); 
            }

           //fue aprobada no hacer ningun movimiento

            // Actualiza solo la celda del estado en la tabla
            String textoNuevoEstado = mapEstado1(nuevoEstado);
            DefaultTableModel modelo = (DefaultTableModel) tblSolicitud.getModel();
            modelo.setValueAt(textoNuevoEstado, fila, 2); 

            // Muestra mensaje de confirmación
            JOptionPane.showMessageDialog(this,
                "El estado de la solicitud ha sido cambiado a: " + textoNuevoEstado,
                "Estado actualizado",
                JOptionPane.INFORMATION_MESSAGE);
            break;
    }

}

    
    
    private void inicializarTablaBanco() {
    // Configuración básica de la tabla
    DefaultTableModel modeloTabla = new DefaultTableModel(new Object[]{"ID", "Movimiento"}, 0);
    tblMovimientosBanco.setModel(modeloTabla);

    // Configurar el renderer para las celdas de texto
    tblMovimientosBanco.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, 
                                                       boolean isSelected, boolean hasFocus, 
                                                       int row, int column) {
            JLabel label = new JLabel("<html>" + value.toString().replace("\n", "<br>") + "</html>");
            if (isSelected) {
                label.setBackground(table.getSelectionBackground());
                label.setForeground(table.getSelectionForeground());
            } else {
                label.setBackground(table.getBackground());
                label.setForeground(table.getForeground());
            }
            return label;
        }
    });
    
    tblMovimientosBanco.setRowHeight(70); 
}
    
private void inicializarTablaMovimientos() {
    // Configuración básica de la tabla
    DefaultTableModel modeloTabla = new DefaultTableModel(new Object[]{"ID", "Movimiento"}, 0);
    txtMovimientos.setModel(modeloTabla);

    // Configurar el renderer para las celdas de texto
    txtMovimientos.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, 
                                                       boolean isSelected, boolean hasFocus, 
                                                       int row, int column) {
            JLabel label = new JLabel("<html>" + value.toString().replace("\n", "<br>") + "</html>");
            if (isSelected) {
                label.setBackground(table.getSelectionBackground());
                label.setForeground(table.getSelectionForeground());
            } else {
                label.setBackground(table.getBackground());
                label.setForeground(table.getForeground());
            }
            return label;
        }
    });
    
    txtMovimientos.setRowHeight(95); 
}
    

    
    private void btnRegresar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar4ActionPerformed
        // TODO add your handling code here:
        InicioSesion nextFrame = new InicioSesion(banco);
        nextFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresar4ActionPerformed

    private void btnBuscarReporteSolicitudActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarReporteSolicitudActionPerformed
        String filtro = txtReporteSolicitud.getText().trim();
        cargarReportesATablaAdmin(filtro);
        if (!filtro.isEmpty() && tblReporteSolicitud.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this,
                "No se encontraron reportes para la cuenta " + filtro,
                "Sin resultados",
                JOptionPane.INFORMATION_MESSAGE);
        }

    }//GEN-LAST:event_btnBuscarReporteSolicitudActionPerformed

    private void txtReporteSolicitudActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtReporteSolicitudActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtReporteSolicitudActionPerformed

    private void btnRegresar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar3ActionPerformed
        // TODO add your handling code here:
        InicioSesion nextFrame = new InicioSesion(banco);
        nextFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresar3ActionPerformed

    private void txtClaveIntSubcuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtClaveIntSubcuentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtClaveIntSubcuentaActionPerformed

    private void txtCorreoSubcuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoSubcuentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoSubcuentaActionPerformed

    private void txtTitularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTitularActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTitularActionPerformed

    private void txtNipCuentaEjeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNipCuentaEjeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNipCuentaEjeActionPerformed

    private void txtNipCuentaEjeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNipCuentaEjeFocusLost
        // TODO add your handling code here:
        verificarCuentaEjeYNip();
    }//GEN-LAST:event_txtNipCuentaEjeFocusLost

    private void btnActualizarSubcuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarSubcuentaActionPerformed
        // TODO add your handling code here:

        int fila = tblSubcuentas.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una subcuenta para actualizar");
            return;
        }

        String tipoCuenta = (String) cmbTipoCuenta.getSelectedItem();
        String numeroSubTarjeta = txtNumeroSubcuenta.getText();
        String claveSubInterbancaria = txtClaveIntSubcuenta.getText();
        String claveSubTransferencia = txtClaveTranSubcuenta.getText();
        String idUsuariosub = txtIdUsuario.getText();
        String nipSubCuenta = txtNipSubcuenta.getText();
        String saldoSubCuenta = txtSaldoSubcuenta.getText();
        
        //Checar si la subcuenta no está en estado de espera
        for(SolicitudInversion solicitud: banco.getSolicitudes()){
            if(solicitud.getNumeroCuenta().equals(numeroSubTarjeta) && (solicitud.getEstado()==3)){
                JOptionPane.showMessageDialog(this, "La subcuenta seleccionada está en revision", "Movimiento Denegado", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }

        //Validar que los campos no estén vacíos
        if (nipSubCuenta.isEmpty() || tipoCuenta.isEmpty() || saldoSubCuenta.isEmpty() ) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double saldo;
        try {
            saldo = Double.parseDouble(saldoSubCuenta);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Saldo inválido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String idSubCuenta = txtIdSubcuenta.getText();

        //Confirmación
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Deseas actualizar los datos de esta subcuenta?",
            "Confirmar actualización",
            JOptionPane.YES_NO_OPTION
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Operación cancelada", "Cancelado", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        //Actualizar en listas
        for (SubCuenta subcuenta : subCuentas) {
            if (subcuenta.getIdCuenta().equals(idSubCuenta)) {
                subcuenta.setSaldo(saldo);
                subcuenta.setNip(nipSubCuenta);
                subcuenta.setTipoCuenta(tipoCuenta);
                break;
            }
        }

        // Actualizar visualmente en la tabla
        DefaultTableModel modelo = (DefaultTableModel) tblSubcuentas.getModel();
        modelo.setValueAt(tipoCuenta, fila, 3);
        modelo.setValueAt(saldo, fila, 4);

        JOptionPane.showMessageDialog(this, "Subcuenta actualizada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        String nombreTitular = txtTitular.getText();
        
        //Limpiar campos
        txtIdSubcuenta.setText("");
        txtCuentaEje.setText("");
        txtNipCuentaEje.setText("");
        txtNumeroSubcuenta.setText("");
        txtClaveIntSubcuenta.setText("");
        txtClaveTranSubcuenta.setText("");
        txtIdUsuario.setText("");
        txtNipSubcuenta.setText("");
        txtSaldoSubcuenta.setText("");

        tblSubcuentas.clearSelection();
        
        //Registrar movimiento en el banco
        int contador = banco.getCont_Movimientos();
        String movimiento;
            
        movimiento=
                    "Acción: El administrador ha modificado la subcuenta "+numeroSubTarjeta+".\n" +
                            "Rol: Usuario\n" +
                            "Nombre del titular: " + nombreTitular + "\n" +
                            "Fecha: " + fechaActual();
        banco.setMovimientos(movimiento, contador);
        contador++;
        cargarMovimientosBancoATabla();
        
        inicializarValores();

    }//GEN-LAST:event_btnActualizarSubcuentaActionPerformed

    private void btnIngresarSubcuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarSubcuentaActionPerformed
        // TODO add your handling code here:
        int[] contadores = banco.getContadores();

        //simular saldo con intereses
        contadores[6]++;
        actualizarSaldoConInteres(contadores[6]);

        if(contadores[0] == 1){
            JOptionPane.showMessageDialog(this, "No hay cuentas ejes registradas");
            return;
        }

        String idSubCuenta = txtIdSubcuenta.getText();
        String tipoCuenta = (String) cmbTipoCuenta.getSelectedItem();
        String numeroSubTarjeta = txtNumeroSubcuenta.getText();
        String claveSubInterbancaria = txtClaveIntSubcuenta.getText();
        String claveSubTransferencia = txtClaveTranSubcuenta.getText();
        String idUsuariosub = txtIdUsuario.getText();
        String nipSubCuenta = txtNipSubcuenta.getText();
        String saldoSubCuenta = txtSaldoSubcuenta.getText();

        //Validar que los campos no estén vacíos
        if (nipSubCuenta.isEmpty() || tipoCuenta.isEmpty() || saldoSubCuenta.isEmpty() ) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double saldo;
        double saldoBanco = banco.getSaldoBanco();

        try {
            saldo = Double.parseDouble(saldoSubCuenta);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Saldo inválido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (saldo > saldoBanco) {
            JOptionPane.showMessageDialog(this, "El banco no tiene fondos suficientes", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        //Si hay suficiente saldo en el banco se descuenta
        saldoBanco = saldoBanco - saldo;
        banco.setSaldoBanco(saldoBanco);

        String [] movimientossubc = new String [99];
        int cont_movimientossubc = 0;
        boolean estadosub = true; //activar la tarjeta

        // Mostrar ventana de confirmación
        int opcion = JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de que deseas agregar esta subcuenta?",
            "Confirmar ingreso",
            JOptionPane.YES_NO_OPTION
        );

        if (opcion == JOptionPane.YES_OPTION) {
            SubCuenta subcuenta = new SubCuenta(idSubCuenta,tipoCuenta,numeroSubTarjeta,claveSubInterbancaria,claveSubTransferencia,idUsuariosub,nipSubCuenta,saldo,movimientossubc,cont_movimientossubc,estadosub, contadores[6]);
            contadores[5]++;
            subCuentas.add(subcuenta);
            JOptionPane.showMessageDialog(this, "Subcuenta agregada con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);

            // Agregar a la tabla
            DefaultTableModel modeloTabla = (DefaultTableModel) tblSubcuentas.getModel();
            modeloTabla.addRow(new Object[]{
                idSubCuenta,
                numeroSubTarjeta,
                idUsuariosub,
                tipoCuenta,
                saldo
            });

            String nombreTitular = txtTitular.getText();
            
            //Limpiar campos

            txtIdSubcuenta.setText("");
            txtCuentaEje.setText("");
            txtNipCuentaEje.setText("");
            txtNumeroSubcuenta.setText("");
            txtClaveIntSubcuenta.setText("");
            txtClaveTranSubcuenta.setText("");
            txtIdUsuario.setText("");
            txtNipSubcuenta.setText("");
            txtSaldoSubcuenta.setText("");

        //Registrar movimiento en el banco
        int contador = banco.getCont_Movimientos();
        String movimiento;
            
        movimiento=
                    "Acción: El administrador ha creado la subcuenta "+numeroSubTarjeta+".\n" +
                            "Rol: Usuario\n" +
                            "Nombre del titular: " + nombreTitular + "\n" +
                            "Fecha: " + fechaActual();
        banco.setMovimientos(movimiento, contador);
        contador++;
        cargarMovimientosBancoATabla();
        
            inicializarValores();
        } else {
            JOptionPane.showMessageDialog(this, "Operación cancelada", "Cancelado", JOptionPane.INFORMATION_MESSAGE);
        }

    }//GEN-LAST:event_btnIngresarSubcuentaActionPerformed

    private void btnEliminarSubcuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarSubcuentaActionPerformed
        // TODO add your handling code here:
        int fila = tblSubcuentas.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una subcuenta a eliminar");
            return;
        }

        // Obtener el modelo de la tabla
        DefaultTableModel modelo = (DefaultTableModel) tblSubcuentas.getModel();

        String idSubcuentaEli = modelo.getValueAt(fila, 0).toString();
        SubCuenta subcuentaEliminar = null;
        String numeroCuenta = "";

        for (SubCuenta subcuenta : subCuentas) {
            if (subcuenta.getIdCuenta().equals(idSubcuentaEli)) {
                subcuentaEliminar = subcuenta;
                numeroCuenta = subcuenta.getSubNumeroTarjeta();
                break;
            }
        }
        
        //Checar si la subcuenta no está en estado de espera
        for(SolicitudInversion solicitud: banco.getSolicitudes()){
            if(solicitud.getNumeroCuenta().equals(numeroCuenta) && (solicitud.getEstado()==3)){
                JOptionPane.showMessageDialog(this, "La subcuenta seleccionada está en revision", "Movimiento Denegado", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        
        String nombreTitular="";
        for(Usuario usuario: usuarios){
            if(usuario.getIdUsuario().equals(subcuentaEliminar.getIdUsuario())){
                nombreTitular=usuario.getNombre();
            }
        }

        if (subcuentaEliminar != null) {
            subCuentas.remove(subcuentaEliminar);
        }

        // Eliminar la fila seleccionada
        modelo.removeRow(fila);

        JOptionPane.showMessageDialog(this, "Subcuenta eliminada");
        
        //Registrar movimiento en el banco
        int contador = banco.getCont_Movimientos();
        String movimiento;
            
        movimiento=
                    "Acción: El administrador ha eliminado la subcuenta "+numeroCuenta+".\n" +
                            "Rol: Usuario\n" +
                            "Nombre del titular: " + nombreTitular + "\n" +
                            "Fecha: " + fechaActual();
        banco.setMovimientos(movimiento, contador);
        contador++;
        cargarMovimientosBancoATabla();
        

    }//GEN-LAST:event_btnEliminarSubcuentaActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        // TODO add your handling code here:
        InicioSesion nextFrame = new InicioSesion(banco);
        nextFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void txtSaldoInicialCuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSaldoInicialCuentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSaldoInicialCuentaActionPerformed

    private void txtClaveTransferenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtClaveTransferenciaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtClaveTransferenciaActionPerformed

    private void txtClaveInterbancariaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtClaveInterbancariaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtClaveInterbancariaActionPerformed

    private void btnActualizarCuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarCuentaActionPerformed
        // TODO add your handling code here:
        int fila = tblCuentas.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una cuenta para actualizar");
            return;
        }

        // Validar campos
        String nombreTitular = txtNombreTitular.getText();
        String fecha = txtFecha.getText();
        String nipCuenta = txtNipCuenta.getText();
        String saldoInicialCuenta = txtSaldoInicialCuenta.getText();
        String usuarioCuenta = txtUsuarioCuenta.getText();
        String contraseniaCuenta = txtContraseniaCuenta.getText();
        String correoCuenta = txtCorreoCuenta.getText();
        String numeroCuenta = txtNumeroTarjeta.getText();

        if (nombreTitular.isEmpty() || fecha.isEmpty() || nipCuenta.isEmpty() || saldoInicialCuenta.isEmpty()
            || usuarioCuenta.isEmpty() || contraseniaCuenta.isEmpty() || correoCuenta.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double saldo;
        try {
            saldo = Double.parseDouble(saldoInicialCuenta);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Saldo inválido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String idCuenta = txtIdCuenta.getText();

        // Confirmación
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Deseas actualizar los datos de esta cuenta?",
            "Confirmar actualización",
            JOptionPane.YES_NO_OPTION
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Operación cancelada", "Cancelado", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Actualizar en listas
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getIdCuenta().equals(idCuenta)) {
                cuenta.setSaldo(saldo);
                cuenta.setNip(nipCuenta);
                break;
            }
        }

        for (Usuario usuario : usuarios) {
            if (usuario.getIdUsuario().equals(idCuenta)) {
                usuario.setNombreCompleto(nombreTitular);
                usuario.setFechaNacimiento(fecha);
                usuario.setNombreUsuario(usuarioCuenta);
                usuario.setContrasenia(contraseniaCuenta);
                usuario.setCorreoElectronico(correoCuenta);
                break;
            }
        }

        // Actualizar visualmente en la tabla
        DefaultTableModel modelo = (DefaultTableModel) tblCuentas.getModel();
        modelo.setValueAt(nombreTitular, fila, 2);
        modelo.setValueAt(saldo, fila, 3);

        JOptionPane.showMessageDialog(this, "Cuenta actualizada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        //Registrar movimiento en el banco
        int contador = banco.getCont_Movimientos();
        String movimiento;
            
        movimiento=
                    "Acción: El administrador ha modificado la cuenta "+numeroCuenta+".\n" +
                            "Rol: Usuario\n" +
                            "Nombre del titular: " + nombreTitular + "\n" +
                            "Fecha: " + fechaActual();
        banco.setMovimientos(movimiento, contador);
        contador++;
        cargarMovimientosBancoATabla();
        
        limpiarCamposCuenta();
        tblCuentas.clearSelection();
        inicializarValores();
        
        
    }//GEN-LAST:event_btnActualizarCuentaActionPerformed

    private void btnIngresarCuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarCuentaActionPerformed
        // TODO add your handling code here:
        int[] contadores = banco.getContadores();

        String idUsuario = String.valueOf(contadores[1]);
        String idCuenta = String.valueOf(contadores[0]);
        // Obtener los valores de los campos de texto
        String nombreTitular = txtNombreTitular.getText();
        String fecha = txtFecha.getText();
        String nipCuenta = txtNipCuenta.getText();
        String saldoInicialCuenta = txtSaldoInicialCuenta.getText();
        String usuarioCuenta = txtUsuarioCuenta.getText();
        String contraseniaCuenta = txtContraseniaCuenta.getText();
        String correoCuenta = txtCorreoCuenta.getText();

        //Validar que los campos no estén vacíos
        if (nombreTitular.isEmpty() || fecha.isEmpty() || nipCuenta.isEmpty() || saldoInicialCuenta.isEmpty()
            || usuarioCuenta.isEmpty() || contraseniaCuenta.isEmpty() || correoCuenta.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        double saldo;
        double saldoBanco = banco.getSaldoBanco();

        try {
            saldo = Double.parseDouble(saldoInicialCuenta);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Saldo inválido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (saldo > saldoBanco) {
            JOptionPane.showMessageDialog(this, "El banco no tiene fondos suficientes", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        //Si hay suficiente saldo en el banco se descuenta
        saldoBanco = saldoBanco - saldo;
        banco.setSaldoBanco(saldoBanco);
       
        
        String [] movimientosc = new String [99];
        int cont_movimientosc=0;
        boolean estado = true; //activar la tarjeta

        // Mostrar ventana de confirmación
        int opcion = JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de que deseas agregar esta cuenta?",
            "Confirmar ingreso",
            JOptionPane.YES_NO_OPTION
        );

        if (opcion == JOptionPane.YES_OPTION) {
            Usuario usuario = new Usuario(idUsuario,nombreTitular,fecha,contraseniaCuenta,usuarioCuenta,correoCuenta);
            Cuenta cuenta = new Cuenta(idCuenta,"eje",numeroTarjeta, claveInterbancaria,claveTransferencia,idUsuario,nipCuenta,saldo,movimientosc,cont_movimientosc,estado);
            contadores[0]++;
            contadores[1]++;
            cuentas.add(cuenta);
            usuarios.add(usuario);
            JOptionPane.showMessageDialog(this, "Cuenta agregada con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
            String estadoStringCuenta = "";
            
            if(estado == true){estadoStringCuenta = "Encendida";}
            // Agregar a la tabla
            DefaultTableModel modeloTabla = (DefaultTableModel) tblCuentas.getModel();
            modeloTabla.addRow(new Object[]{
                idCuenta,
                numeroTarjeta,
                nombreTitular,
                saldo,
                estadoStringCuenta
            });

            //Registrar movimiento en el banco
            int contador = banco.getCont_Movimientos();
            String movimiento;
            
            movimiento=
                    "Acción: El administrador ha creado la cuenta "+numeroTarjeta+".\n" +
                            "Rol: Usuario\n" +
                            "Nombre del titular: " + nombreTitular + "\n" +
                            "Fecha: " + fechaActual();
            banco.setMovimientos(movimiento, contador);
            contador++;
            cargarMovimientosBancoATabla();
        
            //Limpiar campos
            limpiarCamposCuenta();
            inicializarValores();
            
           
        
        } else {
            JOptionPane.showMessageDialog(this, "Operación cancelada", "Cancelado", JOptionPane.INFORMATION_MESSAGE);
        }
        
        
        
        
    }//GEN-LAST:event_btnIngresarCuentaActionPerformed

    private void btnEliminarCuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarCuentaActionPerformed
        // TODO add your handling code here:
        String nombreTitular="";
        int fila = tblCuentas.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una cuenta a eliminar");
            return;
        }

        // Obtener el modelo de la tabla
        DefaultTableModel modelo = (DefaultTableModel) tblCuentas.getModel();

        String idCuentaEli = modelo.getValueAt(fila, 0).toString();
        Cuenta cuentaEliminar = null;
        String numeroTarjeta="";

        for (Cuenta cuenta : cuentas) {
            if (cuenta.getIdCuenta().equals(idCuentaEli)) {
                cuentaEliminar = cuenta;
                numeroTarjeta=cuenta.getNumeroTarjeta();
                break;
            }
        }
        
        for(Usuario usuario : usuarios){
            if(usuario.getIdUsuario().equals(cuentaEliminar.getIdUsuario())){
                nombreTitular = usuario.getNombre();
            }
        }

        if (cuentaEliminar != null) {
            cuentas.remove(cuentaEliminar);
        }

        // Eliminar la fila seleccionada
        modelo.removeRow(fila);
        
        //Registrar movimiento en el banco
        int contador = banco.getCont_Movimientos();
        String movimiento;
            
        movimiento=
                    "Acción: El administrador ha eliminado la cuenta "+numeroTarjeta+".\n" +
                            "Rol: Usuario\n" +
                            "Nombre del titular: " + nombreTitular + "\n" +
                            "Fecha: " + fechaActual();
        banco.setMovimientos(movimiento, contador);
        contador++;
        cargarMovimientosBancoATabla();

        JOptionPane.showMessageDialog(this, "Cuenta eliminada");

    }//GEN-LAST:event_btnEliminarCuentaActionPerformed

    private void btnRegresar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar2ActionPerformed
        // TODO add your handling code here:
        InicioSesion nextFrame = new InicioSesion(banco);
        nextFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresar2ActionPerformed

    private void txtFechaSubgerenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaSubgerenteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFechaSubgerenteActionPerformed

    private void btnActualizarSubgerenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarSubgerenteActionPerformed
        // TODO add your handling code here:
        int fila = tblSubgerentes.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un SubGerente para actualizar");
            return;
        }

        // Validar campos
        String nombre= txtNombreSubgerente.getText();
        String fecha = txtFechaSubgerente.getText();
        String correo = txtCorreoSubgerente.getText();
        String usuario = txtUsuarioSubgerente.getText();
        String contrasenia = txtContraseniaSubgerente.getText();

        if (nombre.isEmpty() || fecha.isEmpty() || correo.isEmpty() || usuario.isEmpty()
            || contrasenia.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String idSubGerente = txtIdSubgerente.getText();

        // Confirmación
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Deseas actualizar los datos de esta cuenta?",
            "Confirmar actualización",
            JOptionPane.YES_NO_OPTION
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Operación cancelada", "Cancelado", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Actualizar en listas
        for (SubGerente subgerente : subGerentes) {
            if (subgerente.getIdSubgerente().equals(idSubGerente)) {
                subgerente.setNombre(nombre);
                subgerente.setCorreo(correo);
                subgerente.setNombreUsuario(usuario);
                subgerente.setContrasenia(contrasenia);
                break;
            }
        }

        // Actualizar visualmente en la tabla
        DefaultTableModel modelo = (DefaultTableModel) tblSubgerentes.getModel();
        modelo.setValueAt(nombre, fila, 1);
        modelo.setValueAt(usuario, fila, 2);
        modelo.setValueAt(correo, fila, 3);

        JOptionPane.showMessageDialog(this, "SubGerente actualizado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        //Registrar movimiento en el banco
            int contador = banco.getCont_Movimientos();
            String movimiento;
            
            movimiento=
                    "Acción: El administrador ha editado una cuenta.\n" +
                            "Rol: SubGerente\n" +
                            "Nombre de usuario: " + usuario + "\n" +
                            "Fecha: " + fechaActual();
            
            banco.setMovimientos(movimiento, contador);
            contador++;
            
        limpiarCamposSubGerente();
        tblSubgerentes.clearSelection();
        inicializarValores();
        cargarMovimientosBancoATabla();
      
    }//GEN-LAST:event_btnActualizarSubgerenteActionPerformed

    private void btnIngresarSubgerenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarSubgerenteActionPerformed
        // TODO add your handling code here:
        int[] contadores = banco.getContadores();

        String idSubgerente= String.valueOf(contadores[4]);
        // Obtener los valores de los campos de texto
        String nombre = txtNombreSubgerente.getText();
        String fecha = txtFechaSubgerente.getText();
        String correo = txtCorreoSubgerente.getText();
        String usuario = txtUsuarioSubgerente.getText();
        String contrasenia = txtContraseniaSubgerente.getText();

        //Validar que los campos no estén vacíos
        if (nombre.isEmpty() || fecha.isEmpty() || correo.isEmpty() || usuario.isEmpty()
            || contrasenia.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Mostrar ventana de confirmación
        int opcion = JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de que deseas agregar este subgerente?",
            "Confirmar ingreso",
            JOptionPane.YES_NO_OPTION
        );

        if (opcion == JOptionPane.YES_OPTION) {
            SubGerente subgerente = new SubGerente(idSubgerente,nombre,fecha,contrasenia,usuario,correo);
            contadores[4]++;
            subGerentes.add(subgerente);
            JOptionPane.showMessageDialog(this, "SubGerente agregado con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);

            // Agregar a la tabla
            DefaultTableModel modeloTabla = (DefaultTableModel) tblSubgerentes.getModel();
            modeloTabla.addRow(new Object[]{
                idSubgerente,
                nombre,
                usuario,
                correo,
            });
            
            //Registrar movimiento en el banco
            int contador = banco.getCont_Movimientos();
            String movimiento;
            
            movimiento=
                    "Acción: El administrador ha creado una cuenta.\n" +
                            "Rol: SubGerente\n" +
                            "Nombre de usuario: " + usuario + "\n" +
                            "Fecha: " + fechaActual();
            
            banco.setMovimientos(movimiento, contador);
            contador++;
            
            //Limpiar campos
            limpiarCamposSubGerente();
            inicializarValores();
            cargarMovimientosBancoATabla();
            
        } else {
            JOptionPane.showMessageDialog(this, "Operación cancelada", "Cancelado", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnIngresarSubgerenteActionPerformed

    private void btnEliminarSubgerenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarSubgerenteActionPerformed
        // TODO add your handling code here:
        String usuario = "";
        int fila = tblSubgerentes.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un SubGerente a eliminar");
            return;
        }

        // Obtener el modelo de la tabla
        DefaultTableModel modelo = (DefaultTableModel) tblSubgerentes.getModel();

        String idCuentaEli = modelo.getValueAt(fila, 0).toString();
        SubGerente cuentaEliminar = null;

        for (SubGerente subgerente : subGerentes) {
            if (subgerente.getIdSubgerente().equals(idCuentaEli)) {
                cuentaEliminar = subgerente;
                usuario = subgerente.getNombreUsuario();
                break;
            }
        }

        if (cuentaEliminar != null) {
            subGerentes.remove(cuentaEliminar);
        }

        // Eliminar la fila seleccionada
        modelo.removeRow(fila);

        JOptionPane.showMessageDialog(this, "SubGerente eliminado");
        
        //Registrar movimiento en el banco
        int contador = banco.getCont_Movimientos();
        String movimiento;
            
        movimiento=
                    "Acción: El administrador ha eliminado una cuenta.\n" +
                            "Rol: SubGerente\n" +
                            "Nombre de usuario: " + usuario + "\n" +
                            "Fecha: " + fechaActual();
        banco.setMovimientos(movimiento, contador);
        contador++;
        cargarMovimientosBancoATabla();
    }//GEN-LAST:event_btnEliminarSubgerenteActionPerformed

    private void btnRegresar6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar6ActionPerformed
        // TODO add your handling code here:
        InicioSesion nextFrame = new InicioSesion(banco);
        nextFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresar6ActionPerformed

    private void btnRegresar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar5ActionPerformed
        // TODO add your handling code here:
        InicioSesion nextFrame = new InicioSesion(banco);
        nextFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresar5ActionPerformed

    private void btnBuscarMovimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarMovimientoActionPerformed
        // TODO add your handling code here:
        String numeroTarjetaBuscar;
        numeroTarjetaBuscar = txtMovimiento.getText();

        boolean encontroCuenta = false;
        String idCuenta="";
        String idSubCuenta="";

        //para cuentas
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getNumeroTarjeta().equals(numeroTarjetaBuscar)) {
                encontroCuenta = true;
                idCuenta=cuenta.getIdCuenta();
                break;
            }
        }

        //para subcuentas
        for (SubCuenta subcuenta : subCuentas) {
            if (subcuenta.getSubNumeroTarjeta().equals(numeroTarjetaBuscar)) {
                encontroCuenta = true;
                idSubCuenta=subcuenta.getIdCuenta();
                break;
            }
        }

        if (encontroCuenta) {
            JOptionPane.showMessageDialog(null, "Cuenta encontrada con exito");
            //MOSTRAR LOS DATOS DEL REPORTE
            tblMovimientosBanco.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            cargarMovimientosATabla(idCuenta,idSubCuenta);
        } else {
            JOptionPane.showMessageDialog(null, "La cuenta no existe");
        }
    }//GEN-LAST:event_btnBuscarMovimientoActionPerformed

    private void txtMovimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMovimientoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMovimientoActionPerformed

    private void btnInicioSesionAdmin9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioSesionAdmin9ActionPerformed
        // TODO add your handling code here:
        btnInicioSesionAdmin9.addActionListener(e -> cambiarEstadoReporte(2)); // En proceso
    }//GEN-LAST:event_btnInicioSesionAdmin9ActionPerformed

    private void btnInicioSesionAdmin11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioSesionAdmin11ActionPerformed
        // TODO add your handling code here:
       btnInicioSesionAdmin11.addActionListener(e -> cambiarEstadoReporte(3)); // Finalizado
    }//GEN-LAST:event_btnInicioSesionAdmin11ActionPerformed

    private void btnRegresar7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar7ActionPerformed
        // TODO add your handling code here:
        InicioSesion nextFrame = new InicioSesion(banco);
        nextFrame.setVisible(true);
        this.setVisible(false);
        
    }//GEN-LAST:event_btnRegresar7ActionPerformed

    private void btnInicioSesionAdmin12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioSesionAdmin12ActionPerformed
        // TODO add your handling code here:
         btnInicioSesionAdmin12.addActionListener(e -> cambiarEstadoSolicitud(1)); // Finalizado
    }//GEN-LAST:event_btnInicioSesionAdmin12ActionPerformed

    private void btnInicioSesionAdmin10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioSesionAdmin10ActionPerformed
        // TODO add your handling code here:
        btnInicioSesionAdmin10.addActionListener(e -> cambiarEstadoSolicitud(2)); 
    }//GEN-LAST:event_btnInicioSesionAdmin10ActionPerformed

    private void txtContraseniaCuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContraseniaCuentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContraseniaCuentaActionPerformed

    
private void verificarCuentaEjeYNip() {
        String numeroCuenta = txtCuentaEje.getText().trim();
        String nip = txtNipCuentaEje.getText().trim();

        for (Cuenta cuenta : cuentas) {
            if (cuenta.getNumeroTarjeta().equals(numeroCuenta) && cuenta.getNip().equals(nip)) {
                txtIdUsuario.setText(cuenta.getIdUsuario());
              
                // Buscar usuario por idUsuario
                
                String idUsuariobus = cuenta.getIdUsuario();
                for (Usuario usuario : usuarios) {
                    if (usuario.getIdUsuario().equals(idUsuariobus)) {
                        txtTitular.setText(usuario.getNombre());
                        txtFechaSubcuenta.setText(usuario.getFechaNacimiento());
                        txtNombreUsuarioSubcuenta.setText(usuario.getNombreUsuario());
                        txtCorreoSubcuenta.setText(usuario.getCorreoElectronico());
                        break;
                    }
                }
                
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "Cuenta o NIP incorrecto.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void cargarCuentasATabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) tblCuentas.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos
        String estado="";

        for (Cuenta cuenta : cuentas) {
            // Obtener nombre del titular desde la lista de usuarios
            String nombreTitular = "";
            for (Usuario usuario : usuarios) {
                if (usuario.getIdUsuario().equals(cuenta.getIdUsuario())) {
                    nombreTitular = usuario.getNombre();
                    break;
                }
            }
            
            if(cuenta.getEstado()){ estado="Encendida";}
            if(!cuenta.getEstado()){ estado="Apagada";}
            
            modeloTabla.addRow(new Object[]{
                cuenta.getIdCuenta(),
                cuenta.getNumeroTarjeta(),
                nombreTitular,
                cuenta.getSaldo(),
                estado
            });
        }
    }
    
    private void cargarSubCuentasATabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) tblSubcuentas.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos

        for (SubCuenta subcuenta : subCuentas) {
            // Obtener nombre del titular desde la lista de usuarios
            String nombreTitular = "";
            for (Usuario usuario : usuarios) {
                if (usuario.getIdUsuario().equals(subcuenta.getIdUsuario())) {
                    nombreTitular = usuario.getNombre();
                    break;
                }
            }

            modeloTabla.addRow(new Object[]{
                subcuenta.getIdCuenta(),
                subcuenta.getSubNumeroTarjeta(),
                subcuenta.getIdUsuario(),
                subcuenta.getTipoCuenta(),
                subcuenta.getSaldo(),
            });
        }
    }
    
    private void cargarSubGerentesATabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) tblSubgerentes.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos

        for (SubGerente subgerente : subGerentes) {
            modeloTabla.addRow(new Object[]{
                subgerente.getIdSubgerente(),
                subgerente.getNombre(),
                subgerente.getNombreUsuario(),
                subgerente.getCorreo(),
            });
        }
    }
    
    private void cargarMovimientosBancoATabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) tblMovimientosBanco.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos

        int contador = banco.getCont_Movimientos();
        String[] movimientos = banco.getMovimientos();
        
        for (int i=1; i<contador; i++) {
            modeloTabla.addRow(new Object[]{
                i,
                movimientos[i],
            });
        }
    }
    
    private void cargarMovimientosATabla(String idCuenta, String idSubCuenta) {
        DefaultTableModel modeloTabla = (DefaultTableModel) txtMovimientos.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos
       
        int contador=0;
        String[] movimientos = null;
        
        if(idCuenta.equals("")){
            //entonces tomo una subcuenta
            for(SubCuenta subcuenta : subCuentas){
                if(subcuenta.getIdCuenta().equals(idSubCuenta)){
                    contador = subcuenta.getCont_movimientos();
                    movimientos = subcuenta.getMovimientos();
                }
            }
        } else if(idSubCuenta.equals("")){
            //entonces tomo una cuenta
            for(Cuenta cuenta : cuentas){
                if(cuenta.getIdCuenta().equals(idCuenta)){
                    contador = cuenta.getCont_movimientos();
                    movimientos = cuenta.getMovimientos();
                }
            }
        }
        
        if(contador>0 && movimientos!=null ){
             for (int i=0; i<contador; i++) {
                modeloTabla.addRow(new Object[]{
                i+1,
                movimientos[i],
            });
            }
        }else{
            JOptionPane.showMessageDialog(null, "No hay movimientos en la cuenta");
        }
      
    }
    
    
    
    private void limpiarCamposSubGerente() {
        txtIdSubgerente.setText("");
        txtNombreSubgerente.setText("");
        txtFechaSubgerente.setText("");
        txtCorreoSubgerente.setText("");
        txtUsuarioSubgerente.setText("");
        txtContraseniaSubgerente.setText("");
    }
               
    private void limpiarCamposCuenta() {
        txtIdCuenta.setText("");
        txtNombreTitular.setText("");
        txtFecha.setText("");
        txtNipCuenta.setText("");
        txtSaldoInicialCuenta.setText("");
        txtUsuarioCuenta.setText("");
        txtContraseniaCuenta.setText("");
        txtCorreoCuenta.setText("");
        txtNumeroTarjeta.setText("");
        txtClaveInterbancaria.setText("");
        txtClaveTransferencia.setText("");
    }
    
    
    private void inicializarValores() {
        int[] contadores = banco.getContadores();
        int contador = banco.getCont_Movimientos();
        String[] movimientos = banco.getMovimientos();

        idUsuario = String.valueOf(contadores[1]);
        idCuenta = String.valueOf(contadores[0]);
        idSubGerente = String.valueOf(contadores[4]);
        idSubcuenta = String.valueOf(contadores[5]);
        numeroTarjeta = banco.generarNumeroTarjeta();
        claveInterbancaria = banco.generarClaveInterbancaria();
        claveTransferencia = banco.generarClaveTransferencia();
        
        //comprobar que el numero de tarjeta no exista
        do{
            if (banco.existeNumeroTarjeta(numeroTarjeta)) {
                numeroTarjeta= banco.generarNumeroTarjeta();
            }
        } while(banco.existeNumeroTarjeta(numeroTarjeta));
        
        
        //comprobar que la cable interbancaria no exista
        do{
            if (banco.existeClaveInterbancaria(claveInterbancaria)) {
                claveInterbancaria= banco.generarClaveInterbancaria();
            }
        } while(banco.existeClaveInterbancaria(claveInterbancaria));
        
        
        //comprobar que la clave de transferencia  no exista
        do{
            if (banco.existeClaveTransferencia(claveTransferencia)) {
                claveTransferencia= banco.generarClaveTransferencia();
            }
        } while(banco.existeClaveTransferencia(claveTransferencia));
        
        
        //---------------CUENTA EJE---------------------------
        //Mostrar en los campos de texto
        txtIdCuenta.setText(idCuenta);
        txtNumeroTarjeta.setText(numeroTarjeta);
        txtClaveInterbancaria.setText(claveInterbancaria);
        txtClaveTransferencia.setText(claveTransferencia);
        txtIdUsuario.setText(idUsuario); 

        //Evitar que se editen
        txtIdCuenta.setEditable(false);
        txtNumeroTarjeta.setEditable(false);
        txtClaveInterbancaria.setEditable(false);
        txtClaveTransferencia.setEditable(false);
        txtIdUsuario.setEditable(false);
        
        //--------------SUBCUENTAS-------------------------------
        
        //Mostrar en los campos de texto
        txtIdSubcuenta.setText(idSubcuenta);
        txtNumeroSubcuenta.setText(numeroTarjeta);
        txtClaveIntSubcuenta.setText(claveInterbancaria);
        txtClaveTranSubcuenta.setText(claveTransferencia);
       
        //Evitar que se editen
        txtIdSubcuenta.setEditable(false);
        txtNumeroSubcuenta.setEditable(false);
        txtClaveIntSubcuenta.setEditable(false);
        txtClaveTranSubcuenta.setEditable(false);
        txtIdUsuario.setEditable(false);
        txtTitular.setEditable(false);
        txtFechaSubcuenta.setEditable(false);
        
        //--------------SUBGERENTES-------------------------------
        
        //Mostrar en los campos de texto
        txtIdSubgerente.setText(idSubGerente);
        
        //Evitar que se edite
         txtIdSubgerente.setEditable(false);
        
    }
    
    
    
    
    
    
    
    
    public void actualizarSaldoConInteres(int semanaActual) {

        for(SubCuenta subcuentas : subCuentas) {
            if (subcuentas.getTipoCuenta().equals("Ahorro") || subcuentas.getTipoCuenta().equals("Plazo Fijo")){
                int semanasTranscurridas = semanaActual - subcuentas.getSemanaUltimaConsulta();
                if (semanasTranscurridas > 0) {
                    double tasaInteres = 0.0005; //ejemplo 0.05% semanal
                    double saldoConInteres = subcuentas.getSaldo() * Math.pow(1 + tasaInteres, semanasTranscurridas);
                    subcuentas.setSaldo(saldoConInteres);
                    subcuentas.setSemanaUltimaConsulta(semanaActual); //actualizar la última semana consultada
                }
            }
        }
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Scanner scanner = new Scanner(System.in);
                Banco banco = new Banco(scanner);
                new MenuAdministrador(banco).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane Administrador;
    private javax.swing.JPanel Cuentas;
    private javax.swing.JPanel Movimientos;
    private javax.swing.JPanel ReportesSolicitudes;
    private javax.swing.JPanel Subcuentas;
    private javax.swing.JPanel Subgerentes;
    private javax.swing.JButton btnActualizarCuenta;
    private javax.swing.JButton btnActualizarSubcuenta;
    private javax.swing.JButton btnActualizarSubgerente;
    private javax.swing.JButton btnBuscarMovimiento;
    private javax.swing.JButton btnBuscarReporteSolicitud;
    private javax.swing.JButton btnEliminarCuenta;
    private javax.swing.JButton btnEliminarSubcuenta;
    private javax.swing.JButton btnEliminarSubgerente;
    private javax.swing.JButton btnIngresarCuenta;
    private javax.swing.JButton btnIngresarSubcuenta;
    private javax.swing.JButton btnIngresarSubgerente;
    private javax.swing.JButton btnInicioSesionAdmin10;
    private javax.swing.JButton btnInicioSesionAdmin11;
    private javax.swing.JButton btnInicioSesionAdmin12;
    private javax.swing.JButton btnInicioSesionAdmin9;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnRegresar2;
    private javax.swing.JButton btnRegresar3;
    private javax.swing.JButton btnRegresar4;
    private javax.swing.JButton btnRegresar5;
    private javax.swing.JButton btnRegresar6;
    private javax.swing.JButton btnRegresar7;
    private javax.swing.JComboBox<String> cmbTipoCuenta;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable tblCuentas;
    private javax.swing.JTable tblMovimientosBanco;
    private javax.swing.JTable tblReporteSolicitud;
    private javax.swing.JTable tblSolicitud;
    private javax.swing.JTable tblSubcuentas;
    private javax.swing.JTable tblSubgerentes;
    private javax.swing.JTextField txtClaveIntSubcuenta;
    private javax.swing.JTextField txtClaveInterbancaria;
    private javax.swing.JTextField txtClaveTranSubcuenta;
    private javax.swing.JTextField txtClaveTransferencia;
    private javax.swing.JTextField txtContraseniaCuenta;
    private javax.swing.JTextField txtContraseniaSubgerente;
    private javax.swing.JTextField txtCorreoCuenta;
    private javax.swing.JTextField txtCorreoSubcuenta;
    private javax.swing.JTextField txtCorreoSubgerente;
    private javax.swing.JTextField txtCuentaEje;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtFechaSubcuenta;
    private javax.swing.JTextField txtFechaSubgerente;
    private javax.swing.JTextField txtIdCuenta;
    private javax.swing.JTextField txtIdSubcuenta;
    private javax.swing.JTextField txtIdSubgerente;
    private javax.swing.JTextField txtIdUsuario;
    private javax.swing.JTextField txtMovimiento;
    private javax.swing.JTable txtMovimientos;
    private javax.swing.JTextField txtNipCuenta;
    private javax.swing.JTextField txtNipCuentaEje;
    private javax.swing.JTextField txtNipSubcuenta;
    private javax.swing.JTextField txtNombreSubgerente;
    private javax.swing.JTextField txtNombreTitular;
    private javax.swing.JTextField txtNombreUsuarioSubcuenta;
    private javax.swing.JTextField txtNumeroSubcuenta;
    private javax.swing.JTextField txtNumeroTarjeta;
    private javax.swing.JTextField txtReporteSolicitud;
    private javax.swing.JTextField txtSaldoInicialCuenta;
    private javax.swing.JTextField txtSaldoSubcuenta;
    private javax.swing.JTextField txtTitular;
    private javax.swing.JTextField txtUsuarioCuenta;
    private javax.swing.JTextField txtUsuarioSubgerente;
    // End of variables declaration//GEN-END:variables

}
