/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package banco;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.OverlayLayout;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class UsuarioApp extends javax.swing.JFrame {
    
    private Timer timerInactividad;
    private final int TIEMPO_INACTIVIDAD = 180000; // tiempo en milisegundos
    private JDialog dialogAdvertencia;
    private static boolean temporizadorActivo = false;

    private Banco banco;
    private String idUsuario;
    private List<Cuenta> cuentas;
    private List<SubCuenta> subcuentas;
    private List<Contacto> contactos;
    private List<Reporte> reportes;
    private String numeroTransferencia;
    private double saldoCuenta;
    /**
     * Creates new form UsuarioApp
     */
    public UsuarioApp(Banco banco, String idUsuario) {
        activarTemporizador();
        
        this.banco = banco;
        this.idUsuario = idUsuario;
        this.numeroTransferencia = "";
        this.saldoCuenta=0.0;
        this.contactos= banco.getContactos();
        this.reportes=banco.getReportes();
        this.cuentas = banco.getCuentas();
        this.subcuentas=banco.getSubCuentas();
       
        initComponents();
        
        inicializarTablaMovimientos();
        
        tblCuentas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 
        tblReporteSolicitud.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 
        tblCuentas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 
        tblHistorial.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 
        
        mostrarDatosUsuario();
        cargarCuentasATabla();
        cargarContactosATabla();       
        cargarReportesATabla();
        cargarHistorialATabla();
        cargarCuentasEnComboHistorial();
        btnBuscarReporteSolicitud1.addActionListener(e -> filtrarHistorialPorCuenta());
        this.setLocationRelativeTo(null);
        
        
        
        tblCuentas1.getModel().addTableModelListener(e -> {
            int columna = e.getColumn();
            int filaSeleccionada = e.getFirstRow();

            // Solo si se modificó la columna "Elección"
            if (columna == 5) {
                Boolean valorSeleccionado = (Boolean) tblCuentas1.getValueAt(filaSeleccionada, columna);

                // Si se marcó en true, desmarcar el resto
                if (valorSeleccionado != null && valorSeleccionado) {
                    for (int i = 0; i < tblCuentas1.getRowCount(); i++) {
                        if (i != filaSeleccionada) {
                            tblCuentas1.setValueAt(false, i, columna);
                        }
                    }
                }
            }
        });
        
        tblContactos1.getModel().addTableModelListener(e -> {
            int columna = e.getColumn();
            int filaSeleccionada = e.getFirstRow();

            // Solo si se modificó la columna "Elección"
            if (columna == 2) {
                Boolean valorSeleccionado = (Boolean) tblContactos1.getValueAt(filaSeleccionada, columna);

                // Si se marcó en true, desmarcar el resto
                if (valorSeleccionado != null && valorSeleccionado) {
                    for (int i = 0; i < tblContactos1.getRowCount(); i++) {
                        if (i != filaSeleccionada) {
                            tblContactos1.setValueAt(false, i, columna);
                        }
                    }
                }
            }
        });
        
        //Bloquear campos que no deben editarse tanto en cuenta como subcuentas
        
        //Datos de cuenta
        txtUsuarioCuenta.setEditable(false);
        txtUsuarioCorreo.setEditable(false);
        txtFecha.setEditable(false);
        txtNumeroCuenta.setEditable(false);
        txtClaveInterbancaria1.setEditable(false);
        txtClaveTransferencia.setEditable(false);
        txtSaldo.setEditable(false);
        
        tblContactos1.getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent event) {
                if (!event.getValueIsAdjusting() && tblContactos1.getSelectedRow() != -1) {
                    int fila = tblContactos1.getSelectedRow();
                    DefaultTableModel modelo = (DefaultTableModel) tblContactos1.getModel();

                    // Cargar datos visibles de la tabla
                    txtNombre.setText(modelo.getValueAt(fila, 0).toString());
                    txtClave.setText(modelo.getValueAt(fila, 1).toString());        
                }
            }
        });
        
        tblCuentas1.getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent event) {
                if (!event.getValueIsAdjusting() && tblCuentas1.getSelectedRow() != -1) {
                    int fila = tblCuentas1.getSelectedRow();
                    DefaultTableModel modelo = (DefaultTableModel) tblCuentas1.getModel();

                    // guardar datos de transferencia
                    numeroTransferencia = (modelo.getValueAt(fila,1)).toString();
                    saldoCuenta = Double.parseDouble((modelo.getValueAt(fila, 4)).toString());       
                }
            }
        });  
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        App = new javax.swing.JTabbedPane();
        Cuenta = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtUsuarioCuenta = new javax.swing.JTextField();
        txtClaveTransferencia = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtUsuarioCorreo = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        txtClaveInterbancaria1 = new javax.swing.JTextField();
        txtNumeroCuenta = new javax.swing.JTextField();
        btnRegresar3 = new javax.swing.JButton();
        Consultas = new javax.swing.JTabbedPane();
        Cuentas = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblCuentas = new javax.swing.JTable();
        btnRegresar4 = new javax.swing.JButton();
        Contactos = new javax.swing.JPanel();
        btnAgregarContacto = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblContactos = new javax.swing.JTable();
        txtNombreContacto = new javax.swing.JTextField();
        txtCuentaContacto = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        btnRegresar5 = new javax.swing.JButton();
        Saldo = new javax.swing.JPanel();
        txtSaldo = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        btnRegresar6 = new javax.swing.JButton();
        Historial = new javax.swing.JPanel();
        comboboxCuentas = new javax.swing.JComboBox<>();
        btnBuscarReporteSolicitud1 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblHistorial = new javax.swing.JTable();
        btnRegresar7 = new javax.swing.JButton();
        Tarjeta = new javax.swing.JPanel();
        jToggleButton1 = new javax.swing.JToggleButton();
        btnRegresar8 = new javax.swing.JButton();
        Solicitudes = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblReporteSolicitud = new javax.swing.JTable();
        btnBuscarReporteSolicitud = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtReporte = new javax.swing.JTextArea();
        jLabel18 = new javax.swing.JLabel();
        btnRegresar9 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblContactos1 = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();
        txtClave = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblCuentas1 = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        txtnip = new javax.swing.JTextField();
        btnTransferir = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        txtCantidad = new javax.swing.JTextField();
        btnRegresar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        App.setBackground(new java.awt.Color(206, 231, 255));

        Cuenta.setBackground(new java.awt.Color(255, 255, 255));

        jLabel11.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 102));
        jLabel11.setText("Fecha de Nacimiento:");

        txtFecha.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        jLabel12.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 102));
        jLabel12.setText("Nombre:");

        txtUsuarioCuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        txtClaveTransferencia.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        jLabel35.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(0, 0, 102));
        jLabel35.setText("Clave Transferencia:");

        jLabel13.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 102));
        jLabel13.setText("Correo Electrónico:");

        txtUsuarioCorreo.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        jLabel36.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(0, 0, 102));
        jLabel36.setText("Cuenta Principal:");

        jLabel37.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(0, 0, 102));
        jLabel37.setText("Clave Interbancaria:");

        txtClaveInterbancaria1.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        txtNumeroCuenta.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        btnRegresar3.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar3.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar3.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar3.setText("CERRAR SESION");
        btnRegresar3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout CuentaLayout = new javax.swing.GroupLayout(Cuenta);
        Cuenta.setLayout(CuentaLayout);
        CuentaLayout.setHorizontalGroup(
            CuentaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CuentaLayout.createSequentialGroup()
                .addGroup(CuentaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CuentaLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(CuentaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtUsuarioCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 568, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(CuentaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 634, Short.MAX_VALUE)
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtUsuarioCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 568, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(CuentaLayout.createSequentialGroup()
                                    .addGap(30, 30, 30)
                                    .addComponent(jLabel36)
                                    .addGap(80, 80, 80)
                                    .addComponent(jLabel37)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(70, 70, 70))
                                .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 566, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(CuentaLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(CuentaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnRegresar3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(CuentaLayout.createSequentialGroup()
                                .addComponent(txtNumeroCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtClaveInterbancaria1, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtClaveTransferencia, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        CuentaLayout.setVerticalGroup(
            CuentaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CuentaLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtUsuarioCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(txtUsuarioCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(CuentaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CuentaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtClaveTransferencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtClaveInterbancaria1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNumeroCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(btnRegresar3)
                .addGap(27, 27, 27))
        );

        App.addTab("Info. Cuenta", Cuenta);

        Consultas.setBackground(new java.awt.Color(255, 255, 255));

        Cuentas.setBackground(new java.awt.Color(255, 255, 255));

        tblCuentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "# de cuenta", "# de Transferencia", "Clave Interbancaria", "Tipo de Cuenta", "Saldo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblCuentas);

        btnRegresar4.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar4.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar4.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar4.setText("CERRAR SESION");
        btnRegresar4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout CuentasLayout = new javax.swing.GroupLayout(Cuentas);
        Cuentas.setLayout(CuentasLayout);
        CuentasLayout.setHorizontalGroup(
            CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CuentasLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnRegresar4, javax.swing.GroupLayout.PREFERRED_SIZE, 631, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 631, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        CuentasLayout.setVerticalGroup(
            CuentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CuentasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnRegresar4)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        Consultas.addTab("Cuentas", Cuentas);

        Contactos.setBackground(new java.awt.Color(255, 255, 255));

        btnAgregarContacto.setBackground(new java.awt.Color(0, 0, 102));
        btnAgregarContacto.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnAgregarContacto.setForeground(new java.awt.Color(255, 255, 255));
        btnAgregarContacto.setText("ENVIAR");
        btnAgregarContacto.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAgregarContacto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarContactoActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 102));
        jLabel20.setText("Nombre del contacto:");

        tblContactos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Nombre", "# de Cuenta"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane6.setViewportView(tblContactos);

        txtNombreContacto.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        txtCuentaContacto.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        jLabel21.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 102));
        jLabel21.setText("Número de cuenta del contacto:");

        btnRegresar5.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar5.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar5.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar5.setText("REGRESAR");
        btnRegresar5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ContactosLayout = new javax.swing.GroupLayout(Contactos);
        Contactos.setLayout(ContactosLayout);
        ContactosLayout.setHorizontalGroup(
            ContactosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContactosLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(ContactosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ContactosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnAgregarContacto, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtNombreContacto, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtCuentaContacto, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnRegresar5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(52, Short.MAX_VALUE))
        );
        ContactosLayout.setVerticalGroup(
            ContactosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContactosLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNombreContacto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtCuentaContacto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(btnAgregarContacto)
                .addGap(18, 18, 18)
                .addComponent(btnRegresar5)
                .addContainerGap(59, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ContactosLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );

        Consultas.addTab("Contactos", Contactos);

        Saldo.setBackground(new java.awt.Color(255, 255, 255));

        txtSaldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSaldoActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 102));
        jLabel19.setText("Saldo actual de la cuenta: ");

        btnRegresar6.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar6.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar6.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar6.setText("REGRESAR");
        btnRegresar6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SaldoLayout = new javax.swing.GroupLayout(Saldo);
        Saldo.setLayout(SaldoLayout);
        SaldoLayout.setHorizontalGroup(
            SaldoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SaldoLayout.createSequentialGroup()
                .addGap(155, 155, 155)
                .addGroup(SaldoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtSaldo)
                    .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, 311, Short.MAX_VALUE)
                    .addComponent(btnRegresar6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(203, Short.MAX_VALUE))
        );
        SaldoLayout.setVerticalGroup(
            SaldoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SaldoLayout.createSequentialGroup()
                .addContainerGap(103, Short.MAX_VALUE)
                .addComponent(jLabel19)
                .addGap(18, 18, 18)
                .addComponent(txtSaldo, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnRegresar6)
                .addGap(88, 88, 88))
        );

        Consultas.addTab("Saldo", Saldo);

        Historial.setBackground(new java.awt.Color(255, 255, 255));

        comboboxCuentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboboxCuentasActionPerformed(evt);
            }
        });

        btnBuscarReporteSolicitud1.setBackground(new java.awt.Color(0, 0, 102));
        btnBuscarReporteSolicitud1.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnBuscarReporteSolicitud1.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscarReporteSolicitud1.setText("BUSCAR");
        btnBuscarReporteSolicitud1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBuscarReporteSolicitud1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarReporteSolicitud1ActionPerformed(evt);
            }
        });

        tblHistorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "ID", "Descripcion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(tblHistorial);

        btnRegresar7.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar7.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar7.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar7.setText("REGRESAR");
        btnRegresar7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout HistorialLayout = new javax.swing.GroupLayout(Historial);
        Historial.setLayout(HistorialLayout);
        HistorialLayout.setHorizontalGroup(
            HistorialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HistorialLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(HistorialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(HistorialLayout.createSequentialGroup()
                        .addComponent(comboboxCuentas, javax.swing.GroupLayout.PREFERRED_SIZE, 431, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnBuscarReporteSolicitud1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 657, Short.MAX_VALUE)
                    .addComponent(btnRegresar7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        HistorialLayout.setVerticalGroup(
            HistorialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HistorialLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(HistorialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnBuscarReporteSolicitud1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboboxCuentas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE)
                .addGap(12, 12, 12)
                .addComponent(btnRegresar7)
                .addContainerGap())
        );

        Consultas.addTab("Historial de Movimientos", Historial);

        App.addTab("Consultas", Consultas);

        Tarjeta.setBackground(new java.awt.Color(255, 255, 255));

        jToggleButton1.setBackground(new java.awt.Color(0, 0, 102));
        jToggleButton1.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        jToggleButton1.setForeground(new java.awt.Color(255, 255, 255));
        jToggleButton1.setText("Encendido-Apagado");
        jToggleButton1.setAlignmentY(0.0F);
        jToggleButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        btnRegresar8.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar8.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar8.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar8.setText("CERRAR SESION");
        btnRegresar8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout TarjetaLayout = new javax.swing.GroupLayout(Tarjeta);
        Tarjeta.setLayout(TarjetaLayout);
        TarjetaLayout.setHorizontalGroup(
            TarjetaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TarjetaLayout.createSequentialGroup()
                .addGap(157, 157, 157)
                .addGroup(TarjetaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jToggleButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRegresar8, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(177, Short.MAX_VALUE))
        );
        TarjetaLayout.setVerticalGroup(
            TarjetaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TarjetaLayout.createSequentialGroup()
                .addGap(138, 138, 138)
                .addComponent(jToggleButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnRegresar8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(123, Short.MAX_VALUE))
        );

        App.addTab("Tarjeta", Tarjeta);

        Solicitudes.setBackground(new java.awt.Color(255, 255, 255));

        tblReporteSolicitud.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Id", "Descripcion", "Estado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(tblReporteSolicitud);

        btnBuscarReporteSolicitud.setBackground(new java.awt.Color(0, 0, 102));
        btnBuscarReporteSolicitud.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnBuscarReporteSolicitud.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscarReporteSolicitud.setText("ENVIAR");
        btnBuscarReporteSolicitud.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBuscarReporteSolicitud.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarReporteSolicitudActionPerformed(evt);
            }
        });

        txtReporte.setColumns(20);
        txtReporte.setRows(5);
        jScrollPane1.setViewportView(txtReporte);

        jLabel18.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 102));
        jLabel18.setText("Ingrese la descripción del reporte:");

        btnRegresar9.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar9.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar9.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar9.setText("CERRAR SESION");
        btnRegresar9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SolicitudesLayout = new javax.swing.GroupLayout(Solicitudes);
        Solicitudes.setLayout(SolicitudesLayout);
        SolicitudesLayout.setHorizontalGroup(
            SolicitudesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SolicitudesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(SolicitudesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SolicitudesLayout.createSequentialGroup()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 271, Short.MAX_VALUE)
                    .addComponent(btnBuscarReporteSolicitud, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRegresar9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(22, 22, 22))
        );
        SolicitudesLayout.setVerticalGroup(
            SolicitudesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SolicitudesLayout.createSequentialGroup()
                .addGroup(SolicitudesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(SolicitudesLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBuscarReporteSolicitud)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnRegresar9))
                    .addGroup(SolicitudesLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        App.addTab("Reportes", Solicitudes);

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        tblContactos1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Nombre", "# de Cuenta", "Eleccion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane7.setViewportView(tblContactos1);

        jLabel14.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 102));
        jLabel14.setText("Clave:");

        txtClave.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        jLabel15.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 102));
        jLabel15.setText("Nombre:");

        txtNombre.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        tblCuentas1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "# de cuenta", "# de Transferencia", "Clave Interbancaria", "Tipo de Cuenta", "Saldo", "Eleccion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(tblCuentas1);

        jLabel16.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 102));
        jLabel16.setText("Cantidad a transferir:");

        txtnip.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        btnTransferir.setBackground(new java.awt.Color(0, 0, 102));
        btnTransferir.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnTransferir.setForeground(new java.awt.Color(255, 255, 255));
        btnTransferir.setText("TRANSFERIR");
        btnTransferir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnTransferir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTransferirActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 0, 102));
        jLabel17.setText("NIP:");

        txtCantidad.setFont(new java.awt.Font("Candara", 0, 12)); // NOI18N

        btnRegresar.setBackground(new java.awt.Color(0, 0, 102));
        btnRegresar.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        btnRegresar.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar.setText("CERRAR SESION");
        btnRegresar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 606, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtClave, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addContainerGap(35, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtnip, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnTransferir, javax.swing.GroupLayout.DEFAULT_SIZE, 233, Short.MAX_VALUE)
                            .addComponent(btnRegresar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(31, 31, 31))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(18, 18, 18))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtClave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)))
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtnip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnTransferir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRegresar)))
                .addGap(18, 18, 18))
        );

        jTabbedPane1.addTab("", jPanel1);

        App.addTab("Transferir", jTabbedPane1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(App, javax.swing.GroupLayout.PREFERRED_SIZE, 651, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(App, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
    * Activa el temporizador 
    */

    public void activarTemporizador() {
        temporizadorActivo = true;
        if (timerInactividad == null) {
            timerInactividad = new Timer(TIEMPO_INACTIVIDAD, e -> {
                if (temporizadorActivo) {
                    mostrarAdvertenciaInactividad();
                }
            });
            timerInactividad.setRepeats(false);
        }
        timerInactividad.start();
    }

    /**
     * Reinicia el temporizador solo si está activo
     */
    public void reiniciarTemporizador() {
        if (temporizadorActivo && timerInactividad != null) {
            timerInactividad.restart();
        }
    }

    /**
     * Desactiva completamente el temporizador
     */
    public void desactivarTemporizador() {
        temporizadorActivo = false;
        if (timerInactividad != null) {
            timerInactividad.stop();
        }
    }
    
    private BufferedImage aplicarDesenfoque(Component component) {
        BufferedImage image = new BufferedImage(
            component.getWidth(), 
            component.getHeight(), 
            BufferedImage.TYPE_INT_RGB);

        Graphics2D g2d = image.createGraphics();
        component.paint(g2d);
        g2d.dispose();

        // Aplicar filtro de desenfoque
        float[] blurKernel = {
            0.1f, 0.1f, 0.1f,
            0.1f, 0.2f, 0.1f,
            0.1f, 0.1f, 0.1f
        };

        BufferedImageOp blurFilter = new ConvolveOp(
            new Kernel(3, 3, blurKernel), 
            ConvolveOp.EDGE_NO_OP, null);

        return blurFilter.filter(image, null);
    }
    
    private void mostrarAdvertenciaInactividad() {
        // Capturar pantalla actual con desenfoque
        BufferedImage blurredImage = aplicarDesenfoque(this);
        JLabel background = new JLabel(new ImageIcon(blurredImage));

        // Crear capa de oscurecimiento
        JPanel dimPanel = new JPanel(new BorderLayout());
        dimPanel.setBackground(new Color(0, 0, 0, 150)); // Fondo semitransparente

        // Crear diálogo sin decoraciones
        dialogAdvertencia = new JDialog((Frame) SwingUtilities.getWindowAncestor(this));
        dialogAdvertencia.setUndecorated(true);
        dialogAdvertencia.setModal(true);

        // Panel de contenido
        JPanel contentPanel = new JPanel(new BorderLayout(10, 10));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.setBackground(new Color(240, 240, 240));
        contentPanel.setOpaque(true);

        // Mensaje
        JLabel mensaje = new JLabel("<html><center><b>Por seguridad, la sesión se cerrará</b><br>"
                + "¿Desea continuar?</center></html>", JLabel.CENTER);
        mensaje.setFont(new Font("Arial", Font.BOLD, 14));

        // Botones
        JButton btnContinuar = new JButton("Continuar");
        btnContinuar.addActionListener(e -> {
            reiniciarTemporizador();
            dialogAdvertencia.dispose();
        });

        JButton btnCerrar = new JButton("Cerrar sesión");
        btnCerrar.addActionListener(e -> {
            desactivarTemporizador();
            InicioSesion nextFrame = new InicioSesion(banco);
            nextFrame.setVisible(true);
            this.setVisible(false);
            dialogAdvertencia.setVisible(false);
        });

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelBotones.setOpaque(false);
        panelBotones.add(btnContinuar);
        panelBotones.add(btnCerrar);

        // añadir componentes
        contentPanel.add(mensaje, BorderLayout.CENTER);
        contentPanel.add(panelBotones, BorderLayout.SOUTH);

        // configurar capas
        dimPanel.add(contentPanel, BorderLayout.CENTER);

        // configurar ventana
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setLayout(new OverlayLayout(layeredPane));

        background.setBounds(0, 0, getWidth(), getHeight());
        dimPanel.setBounds(0, 0, getWidth(), getHeight());

        layeredPane.add(background, JLayeredPane.DEFAULT_LAYER);
        layeredPane.add(dimPanel, JLayeredPane.PALETTE_LAYER);

        dialogAdvertencia.setContentPane(layeredPane);
        dialogAdvertencia.setSize(getSize());
        dialogAdvertencia.setLocationRelativeTo(null);
        dialogAdvertencia.setVisible(true);
    }

    
    private void cargarCuentasEnComboHistorial() {
        comboboxCuentas.removeAllItems();
        SolicitudInversion sol=null;
        // Cuentas principales
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getIdUsuario().equals(idUsuario)) {
                comboboxCuentas.addItem(cuenta.getNumeroTarjeta());
            }
        }
        // Subcuentas
        for (SubCuenta sub : subcuentas) {
            if (sub.getIdUsuario().equals(idUsuario)) {
                //buscar si existe en la lista
                for(SolicitudInversion solicitud: banco.getSolicitudes()){
                    if(solicitud.getNumeroCuenta().equals(sub.getSubNumeroTarjeta())){
                        sol=solicitud;
                    }
                }
                
                //si existe en lista
                if(sol!=null){
                    //si está aprobada mostrar
                    if(sol.getEstado()==1){
                        comboboxCuentas.addItem(sub.getSubNumeroTarjeta());
                    }
                }else {
                    //si no existe en lista mostrar
                    comboboxCuentas.addItem(sub.getSubNumeroTarjeta());
                }
                
            }
        }
    }

    private void filtrarHistorialPorCuenta() {
        String numero = (String) comboboxCuentas.getSelectedItem();
        if (numero == null || numero.isEmpty()) {
            return;
        }
        DefaultTableModel modelo = (DefaultTableModel) tblHistorial.getModel();
        modelo.setRowCount(0);
        // Movimientos de cuenta principal
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getIdUsuario().equals(idUsuario)
                && cuenta.getNumeroTarjeta().equals(numero)) {
                int cnt = cuenta.getCont_movimientos();
                String[] movs = cuenta.getMovimientos();
                for (int i = 0; i < cnt; i++) {
                    modelo.addRow(new Object[]{i + 1, movs[i]});
                }
            }
        }
        // Movimientos de subcuenta
        for (SubCuenta sub : subcuentas) {
            if (sub.getIdUsuario().equals(idUsuario)
                && sub.getSubNumeroTarjeta().equals(numero)) {
                int cnt = sub.getCont_movimientos();
                String[] movs = sub.getMovimientos();
                for (int i = 0; i < cnt; i++) {
                    modelo.addRow(new Object[]{i + 1, movs[i]});
                }
            }
        }
    }
            
        private String buscarNumeroCuenta(String idUsuario) {
        for (Cuenta cuenta : banco.getCuentas()) {
            if (cuenta.getIdUsuario().equals(idUsuario)) {
                return cuenta.getNumeroTarjeta(); 
            }
        }
        return "No encontrada";
    }
    
    private String buscarClaveInterbancaria(String idUsuario) {
        for (Cuenta cuenta : banco.getCuentas()) {
            if (cuenta.getIdUsuario().equals(idUsuario)) {
                return cuenta.getClaveInterbancaria(); 
            }
        }
        return "No encontrada";
    }
    
    private String buscarClaveTransferencia(String idUsuario) {
        for (Cuenta cuenta : banco.getCuentas()) {
            if (cuenta.getIdUsuario().equals(idUsuario)) {
                return cuenta.getClaveTransferencia(); 
            }
        }
        return "No encontrada";
    }
    
    private String buscarNombreUsuario(String idUsuario) {
        for (Usuario user : banco.getUsuarios()) {
            if (user.getIdUsuario().equals(idUsuario)) {
                return user.getNombre(); 
            }
        }
        return "No encontrada";
    }
    
    private String buscarFecha(String idUsuario) {
        for (Usuario user : banco.getUsuarios()) {
            if (user.getIdUsuario().equals(idUsuario)) {
                return user.getFechaNacimiento(); 
            }
        }
        return "No encontrada";
    }
    
    private String buscarCorreo(String idUsuario) {
        for (Usuario user : banco.getUsuarios()) {
            if (user.getIdUsuario().equals(idUsuario)) {
                return user.getCorreoElectronico(); 
            }
        }
        return "No encontrada";
    }
    
    private String ConsultarSaldo(String idUsuario) {
        for (Cuenta user : banco.getCuentas()) {
            if (user.getIdUsuario().equals(idUsuario)) {
                return String.valueOf(user.getSaldo()); 
            }
        }
        return "No encontrada";
    }
    
    private void mostrarDatosUsuario() {
        // muestra los datos del usuario en los campos correspondientes
        
        txtUsuarioCuenta.setText(buscarNombreUsuario(idUsuario));
        txtFecha.setText(buscarFecha(idUsuario));
        txtUsuarioCorreo.setText(buscarCorreo(idUsuario));
        txtNumeroCuenta.setText(buscarNumeroCuenta(idUsuario));
        txtClaveTransferencia.setText(buscarClaveTransferencia(idUsuario));
        txtClaveInterbancaria1.setText(buscarClaveInterbancaria(idUsuario));
        txtSaldo.setText(ConsultarSaldo(idUsuario));
    }
    
    private void cargarContactosATabla() {
        DefaultTableModel modelo = (DefaultTableModel) tblContactos.getModel();
        modelo.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos
        // Llenar la tabla con las solicitudes filtradas
        
        for (Contacto contacto : contactos) {
            if (contacto.getIdUsuario().equals(idUsuario)) {
                modelo.addRow(new Object[]{
                    contacto.getNombre(),
                    contacto.getNumeroCuenta()
                });
            }
        }
        
       DefaultTableModel modelo1 = (DefaultTableModel) tblContactos1.getModel();
        modelo1.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos
        // Llenar la tabla con las solicitudes filtradas
        
        for (Contacto contacto : contactos) {
            if (contacto.getIdUsuario().equals(idUsuario)) {
                modelo1.addRow(new Object[]{
                    contacto.getNombre(),
                    contacto.getNumeroCuenta()
                });
            }
        }
    }
    
    
private String mapEstado(int estado) {
    switch (estado) {
        case 1: return "Pendiente";
        case 2: return "En Proceso";
        case 3: return "Finalizado";
        default: return "Desconocido";
    }
}

    private void cargarReportesATabla() {
    DefaultTableModel modelo = (DefaultTableModel) tblReporteSolicitud.getModel();
    modelo.setRowCount(0); // Limpiar

    int i = 1;
    String numerocuenta = "";

    // obtener número de cuenta del usuario
    for (Cuenta cuenta : cuentas) {
        if (cuenta.getIdUsuario().equals(idUsuario)) {
            numerocuenta = cuenta.getNumeroTarjeta();
            break;
        }
    }

    // poblar tabla con texto de estado
    for (Reporte reporte : reportes) {
        String estado = "";
        if (reporte.getNumeroCuenta().equals(numerocuenta)) { 
            if(reporte.getEstado()==1){estado = "Pendiente";}
            if(reporte.getEstado()==3){estado = "Finalizado";}
            modelo.addRow(new Object[]{
                i++,                                 // No de fila
                reporte.getDescripcion(),            // Descripción
                estado
            });
        }
    }
}

    
    private void cargarCuentasATabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) tblCuentas.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos

        for(Cuenta cuenta : cuentas){
            if(cuenta.getIdUsuario().equals(idUsuario)){
                modeloTabla.addRow(new Object[]{
                        cuenta.getNumeroTarjeta(),
                        cuenta.getClaveTransferencia(),
                        cuenta.getClaveInterbancaria(),
                        cuenta.getTipoCuenta(),
                        cuenta.getSaldo()
                });
            }
        }
        
        SolicitudInversion sol = null;
        
        for (SubCuenta subcuenta : banco.getSubCuentas()) {
                if (subcuenta.getIdUsuario().equals(idUsuario)) {
                    
                    //ver si esta en solicitudes
                    for(SolicitudInversion solicitud: banco.getSolicitudes()){
                        if(subcuenta.getSubNumeroTarjeta().equals(solicitud.getNumeroCuenta())){
                            sol=solicitud;
                        }
                    }
                    
                    //si existe en la lista ver si está aprobada
                    if(sol!=null){
                        if(sol.getEstado()==1){
                            modeloTabla.addRow(new Object[]{
                                subcuenta.getSubNumeroTarjeta(),
                                subcuenta.getSubClaveTransferencia(),
                                subcuenta.getSubClaveInterbancaria(),
                                subcuenta.getTipoCuenta(),
                                subcuenta.getSaldo()
                            });
                        }
                    }else{
                        modeloTabla.addRow(new Object[]{
                                subcuenta.getSubNumeroTarjeta(),
                                subcuenta.getSubClaveTransferencia(),
                                subcuenta.getSubClaveInterbancaria(),
                                subcuenta.getTipoCuenta(),
                                subcuenta.getSaldo()
                        });
                    }
                    sol=null;
                }
        }
        
        DefaultTableModel modeloTabla1 = (DefaultTableModel) tblCuentas1.getModel();
        modeloTabla1.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos

        for(Cuenta cuenta : cuentas){
            if(cuenta.getIdUsuario().equals(idUsuario)){
                modeloTabla1.addRow(new Object[]{
                        cuenta.getNumeroTarjeta(),
                        cuenta.getClaveTransferencia(),
                        cuenta.getClaveInterbancaria(),
                        cuenta.getTipoCuenta(),
                        cuenta.getSaldo()
                });
            }
        }
        
        for (SubCuenta subcuenta : banco.getSubCuentas()) {
                if (subcuenta.getIdUsuario().equals(idUsuario)) {
                    
                    //ver si esta en solicitudes
                    for(SolicitudInversion solicitud: banco.getSolicitudes()){
                        if(subcuenta.getSubNumeroTarjeta().equals(solicitud.getNumeroCuenta())){
                            sol=solicitud;
                        }
                    }
                    
                    //si existe en la lista ver si está aprobada
                    if(sol!=null){
                        if(sol.getEstado()==1){
                            modeloTabla1.addRow(new Object[]{
                                subcuenta.getSubNumeroTarjeta(),
                                subcuenta.getSubClaveTransferencia(),
                                subcuenta.getSubClaveInterbancaria(),
                                subcuenta.getTipoCuenta(),
                                subcuenta.getSaldo()
                            });
                        }
                    }else{
                        modeloTabla1.addRow(new Object[]{
                                subcuenta.getSubNumeroTarjeta(),
                                subcuenta.getSubClaveTransferencia(),
                                subcuenta.getSubClaveInterbancaria(),
                                subcuenta.getTipoCuenta(),
                                subcuenta.getSaldo()
                        });
                    }
                    sol=null;
                }
        }
    }
    
    private void cargarHistorialATabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) tblHistorial.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla antes de cargar datos nuevos
       
        int contador=0;
        String[] movimientos = null;

        //movimientos de cuenta
            for(Cuenta cuenta : cuentas){
                if(cuenta.getIdUsuario().equals(idUsuario)){
                    contador = cuenta.getCont_movimientos();
                    movimientos = cuenta.getMovimientos();
                }
            }
            
            if(contador>0 && movimientos!=null ){
                for (int i=0; i<contador; i++) {
                    modeloTabla.addRow(new Object[]{
                        i+1,
                        movimientos[i],
                    });
                }
            }
      
    }
    //---------------------------------------------------------------------------
    
    //TRANSFERENCIA
    
    //Metodo para verificar si existe la cuenta a la que se va a transferir el dinero
    public void comprobarCuentas(String idUsuario, double cantidadTransferir, String numeroCuenta, String numeroTransfiere) {

        //buscar en cuentas eje
        for (Cuenta cuenta : cuentas) { 
            
            //si la cuenta pertenece al mismo usuario guardar el mensaje de transferencia a la otra cuenta
            if ((cuenta.getClaveTransferencia().equals(numeroCuenta) && cuenta.getIdUsuario().equals(idUsuario))||(cuenta.getClaveInterbancaria().equals(numeroCuenta) && cuenta.getIdUsuario().equals(idUsuario))) {
                double Saldoanterior = cuenta.getSaldo();
                cuenta.setSaldo(cuenta.getSaldo()+cantidadTransferir);

                String mensajeTransferencia = String.format(
                        " Transferencia realizada desde tu cuenta : %s\n" +
                                "  - Cantidad transferida: $%.2f\n" +
                                "  - Saldo anterior: $%.2f\n" +
                                "  - Saldo actual: $%.2f\n",
                        numeroTransfiere,
                        cantidadTransferir,
                        Saldoanterior,
                        cuenta.getSaldo()
                );
                cuenta.setMovimientos(mensajeTransferencia, cuenta.getCont_movimientos());
                return;
            }

            //si la cuenta no es del usuario pero pertenece al mismo banco
            if ((cuenta.getClaveTransferencia().equals(numeroCuenta)) || (cuenta.getClaveInterbancaria().equals(numeroCuenta))) {
                double Saldoanterior = cuenta.getSaldo();
                cuenta.setSaldo(cuenta.getSaldo()+cantidadTransferir);

                String mensajeTransferencia = String.format(
                        " Transferencia realizada desde la cuenta : %s\n" +
                                "  - Cantidad transferida: $%.2f\n" +
                                "  - Saldo anterior: $%.2f\n" +
                                "  - Saldo actual: $%.2f\n",
                        numeroTransfiere,
                        cantidadTransferir,
                        Saldoanterior,
                        cuenta.getSaldo()
                );
                cuenta.setMovimientos(mensajeTransferencia, cuenta.getCont_movimientos());
                return;
            }

        }

        SolicitudInversion sol = null;
 
        //buscar en subcuentas
        for (SubCuenta subcuenta : subcuentas) {

            //si la cuenta pertenece al mismo usuario guardar el mensaje de transferencia a la otra cuenta
            if ((subcuenta.getSubClaveTransferencia().equals(numeroCuenta) && subcuenta.getIdUsuario().equals(idUsuario)) || (subcuenta.getSubClaveInterbancaria().equals(numeroCuenta) && subcuenta.getIdUsuario().equals(idUsuario))) {
                
                //ver si la subcuenta existe en solicitudes
                for(SolicitudInversion solicitud : banco.getSolicitudes()){
                    if(solicitud.getNumeroCuenta().equals(subcuenta.getSubNumeroTarjeta())){
                        sol=solicitud;
                        break;
                    }
                }    
                    
                if(sol!=null){
                    if(sol.getEstado()==1){
                        double Saldoanterior = subcuenta.getSaldo();
                        subcuenta.setSaldo(subcuenta.getSaldo()+cantidadTransferir);

                        String mensajeTransferencia = String.format(
                            " Transferencia realizada desde tu cuenta : %s\n" +
                                "  - Cantidad transferida: $%.2f\n" +
                                "  - Saldo anterior: $%.2f\n" +
                                "  - Saldo actual: $%.2f\n",
                                numeroTransfiere,
                                cantidadTransferir,
                                Saldoanterior,
                                subcuenta.getSaldo()
                            );

                        subcuenta.setMovimientos(mensajeTransferencia, subcuenta.getCont_movimientos());
                        return;
                    }
                }else{
                    double Saldoanterior = subcuenta.getSaldo();
                    subcuenta.setSaldo(subcuenta.getSaldo()+cantidadTransferir);

                    String mensajeTransferencia = String.format(
                        " Transferencia realizada desde tu cuenta : %s\n" +
                            "  - Cantidad transferida: $%.2f\n" +
                            "  - Saldo anterior: $%.2f\n" +
                            "  - Saldo actual: $%.2f\n",
                            numeroTransfiere,
                            cantidadTransferir,
                            Saldoanterior,
                            subcuenta.getSaldo()
                        );
                    subcuenta.setMovimientos(mensajeTransferencia, subcuenta.getCont_movimientos());
                    return;
                }
            }
            

            //si la cuenta no es del usuario pero pertenece al mismo banco
            if ((subcuenta.getSubClaveTransferencia().equals(numeroCuenta)) || (subcuenta.getSubClaveInterbancaria().equals(numeroCuenta))) {
                
                //Ver si la subcuenta esta en solicitudes
                for(SolicitudInversion solicitud: banco.getSolicitudes()){
                    sol=solicitud;
                    break;
                }
                
                //si esta en las solicitudes
                if(sol!=null){
                    //si está aprobada
                    if(sol.getEstado()==1){
                        double Saldoanterior = subcuenta.getSaldo();
                        subcuenta.setSaldo(subcuenta.getSaldo()+cantidadTransferir);

                        String mensajeTransferencia = String.format(
                                " Transferencia realizada desde la cuenta : %s\n" +
                                        "  - Cantidad transferida: $%.2f\n" +
                                        "  - Saldo anterior: $%.2f\n" +
                                        "  - Saldo actual: $%.2f\n",
                                numeroTransfiere,
                                cantidadTransferir,
                                Saldoanterior,
                                subcuenta.getSaldo()
                        );
                        subcuenta.setMovimientos(mensajeTransferencia, subcuenta.getCont_movimientos());
                        return;
                    }
                }else{
                        double Saldoanterior = subcuenta.getSaldo();
                        subcuenta.setSaldo(subcuenta.getSaldo()+cantidadTransferir);

                        String mensajeTransferencia = String.format(
                                " Transferencia realizada desde la cuenta : %s\n" +
                                        "  - Cantidad transferida: $%.2f\n" +
                                        "  - Saldo anterior: $%.2f\n" +
                                        "  - Saldo actual: $%.2f\n",
                                numeroTransfiere,
                                cantidadTransferir,
                                Saldoanterior,
                                subcuenta.getSaldo()
                        );
                        subcuenta.setMovimientos(mensajeTransferencia, subcuenta.getCont_movimientos());
                        return;
                }
            }
            sol=null;
        }
    }

    private void txtSaldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSaldoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSaldoActionPerformed

    private void btnBuscarReporteSolicitud1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarReporteSolicitud1ActionPerformed
        // TODO add your handling code here:
        reiniciarTemporizador();
    }//GEN-LAST:event_btnBuscarReporteSolicitud1ActionPerformed

    private void btnAgregarContactoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarContactoActionPerformed
        // TODO add your handling code here:
        reiniciarTemporizador();
        // Crear un contacto
        String nombre = txtNombreContacto.getText();
        String numeroCuenta = txtCuentaContacto.getText();
        Contacto contacto = new Contacto(
                idUsuario,
                nombre,
                numeroCuenta
        );
            
        contactos.add(contacto);
        cargarContactosATabla();
        
    }//GEN-LAST:event_btnAgregarContactoActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        // TODO add your handling code here:
        InicioSesion nextFrame = new InicioSesion(banco);
        nextFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        // TODO add your handling code here:
        reiniciarTemporizador();
        //recuperar información de la tarjeta
        for (Cuenta user : banco.getCuentas()) {
            if (user.getIdUsuario().equals(String.valueOf(idUsuario))) {
                String estado="";
                if(user.getEstado()){estado="Encendida";}
                else if(!user.getEstado()){estado="Apagada";}

                //si la tarjeta está apagada prenderla
                if(!user.getEstado()){
                    user.setEstado(true);
                } else {
                    //si la tarjeta está prendida apagarla
                    user.setEstado(false);
                }

                if(user.getEstado()){estado="Encendida";}
                else if(!user.getEstado()){estado="Apagada";}

                JOptionPane.showMessageDialog(null, "Su tarjeta ha sido "+estado+" con exito!");

            }
        }
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void btnBuscarReporteSolicitudActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarReporteSolicitudActionPerformed
        // TODO add your handling code here:
        reiniciarTemporizador();
        String descripcion = txtReporte.getText();
        
        Reporte reporte = new Reporte(
                buscarNumeroCuenta(idUsuario), 
                descripcion, 
                1
         );
        
        reportes.add(reporte);
        cargarReportesATabla();
    }//GEN-LAST:event_btnBuscarReporteSolicitudActionPerformed

    private void btnTransferirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTransferirActionPerformed
        // TODO add your handling code here:
        reiniciarTemporizador();
        if(txtnip.getText()==null){
            JOptionPane.showMessageDialog(null, "Ingresa el nip", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(txtCantidad.getText()==null){
            JOptionPane.showMessageDialog(null, "Ingresa una cantidad a transferir", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(numeroTransferencia.equals("")){
            JOptionPane.showMessageDialog(null, "Selecciona una de tus cuentas", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        Double cantidadTransferir = Double.valueOf(txtCantidad.getText());
        String nip = txtnip.getText();
        String cuentaATransferir = txtClave.getText();
        boolean permitir = false;
        SubCuenta subcuentaEncontrada=null;
        Cuenta cuentaEncontrada=null;
        
        //comprobar si el nip es correcto
        
        //si llega a ser de cuenta eje
        for(Cuenta cuenta : cuentas){
            if(cuenta.getClaveTransferencia().equals(numeroTransferencia) && cuenta.getNip().equals(nip)){
                permitir = true;
                cuentaEncontrada=cuenta;
            }
        }
        
        //si llega a ser de subcuenta
        for(SubCuenta subcuenta : subcuentas){
            if(subcuenta.getSubClaveTransferencia().equals(numeroTransferencia) && subcuenta.getNip().equals(nip)){
                permitir = true;
                subcuentaEncontrada=subcuenta;
            }
        }
        
        if(cantidadTransferir<=0){
            JOptionPane.showMessageDialog(null, "Ingresa una cantidad a transferir valida", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if(permitir){
            //realizar proceso de transferencia
            
            //si es de la cuenta eje
            if(cuentaEncontrada!=null){
                        double saldoActual = cuentaEncontrada.getSaldo();
                        if (cantidadTransferir > cuentaEncontrada.getSaldo()) {
                            JOptionPane.showMessageDialog(null, "El saldo en la cuenta no es suficiente!. Saldo Actual $"+saldoActual, "Error", JOptionPane.ERROR_MESSAGE);
                        } else if (cantidadTransferir < 0) {
                            JOptionPane.showMessageDialog(null, "Ingrese una cantidad valida", "Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            Double saldoanterior = cuentaEncontrada.getSaldo();
                            cuentaEncontrada.setSaldo(saldoActual - cantidadTransferir);

                            //comprobar si no es una cuenta suya o de alguien del banco
                            comprobarCuentas(String.valueOf(idUsuario),cantidadTransferir,cuentaATransferir,cuentaEncontrada.getNumeroTarjeta());
                            JOptionPane.showMessageDialog(null, "Transferencia exitosa! Nuevo saldo: $" + cuentaEncontrada.getSaldo());

                            String mensajeTransferencia = String.format(
                                    " Transferencia realizada:\n" +
                                            "  - Cantidad transferida: $%.2f\n" +
                                            "  - Cuenta de destino: %s\n" +
                                            "  - Saldo anterior: $%.2f\n" +
                                            "  - Saldo actual: $%.2f\n",
                                    cantidadTransferir,
                                    cuentaATransferir,
                                    saldoanterior,
                                    cuentaEncontrada.getSaldo()
                            );
                            cuentaEncontrada.setMovimientos(mensajeTransferencia, cuentaEncontrada.getCont_movimientos());
                            mostrarDatosUsuario();
                        }
                
            }
            
            //si es de una subcuenta
            if(subcuentaEncontrada!=null){
                        double saldoActual = subcuentaEncontrada.getSaldo();
                        if (cantidadTransferir > subcuentaEncontrada.getSaldo()) {
                            JOptionPane.showMessageDialog(null, "El saldo en la cuenta no es suficiente!. Saldo Actual $"+saldoActual, "Error", JOptionPane.ERROR_MESSAGE);
                        } else if (cantidadTransferir < 0) {
                            JOptionPane.showMessageDialog(null, "Ingrese una cantidad valida", "Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            Double saldoanterior = subcuentaEncontrada.getSaldo();
                            subcuentaEncontrada.setSaldo(saldoActual - cantidadTransferir);

                            //comprobar si no es una cuenta suya o de alguien del banco
                            comprobarCuentas(String.valueOf(idUsuario),cantidadTransferir,cuentaATransferir,subcuentaEncontrada.getSubNumeroTarjeta());
                            JOptionPane.showMessageDialog(null, "Transferencia exitosa! Nuevo saldo: $" + subcuentaEncontrada.getSaldo());

                            String mensajeTransferencia = String.format(
                                    " Transferencia realizada:\n" +
                                            "  - Cantidad transferida: $%.2f\n" +
                                            "  - Cuenta de destino: %s\n" +
                                            "  - Saldo anterior: $%.2f\n" +
                                            "  - Saldo actual: $%.2f\n",
                                    cantidadTransferir,
                                    cuentaATransferir,
                                    saldoanterior,
                                    subcuentaEncontrada.getSaldo()
                            );
                            subcuentaEncontrada.setMovimientos(mensajeTransferencia, subcuentaEncontrada.getCont_movimientos());
                            mostrarDatosUsuario();
                        }
            }
        }else{
            JOptionPane.showMessageDialog(null, "NIP incorrecto", "Error", JOptionPane.ERROR_MESSAGE);
        }
        cargarCuentasATabla();
         cargarHistorialATabla();
    }//GEN-LAST:event_btnTransferirActionPerformed

    private void btnRegresar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar3ActionPerformed

        //Pregunta la confirmacion al usuario si desea regresar
        int opcion = JOptionPane.showConfirmDialog(    
            this,
            "¿Estás seguro de que deseas salir?\nLos datos ingresados se perderán.",
            "Confirmar salida",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        //Si si, se regresa a la ventana de inicio de sesion del admin
        if (opcion == JOptionPane.YES_OPTION) {
            desactivarTemporizador();
            InicioSesion nextFrame = new InicioSesion(banco);
            nextFrame.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_btnRegresar3ActionPerformed

    private void btnRegresar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar4ActionPerformed
         //Pregunta la confirmacion al usuario si desea regresar
        int opcion = JOptionPane.showConfirmDialog(    
            this,
            "¿Estás seguro de que deseas salir?\nLos datos ingresados se perderán.",
            "Confirmar salida",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        //Si si, se regresa a la ventana de inicio de sesion del admin
        if (opcion == JOptionPane.YES_OPTION) {
            desactivarTemporizador();
            InicioSesion nextFrame = new InicioSesion(banco);
            nextFrame.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_btnRegresar4ActionPerformed

    private void btnRegresar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar5ActionPerformed
        // TODO add your handling code here:
         //Pregunta la confirmacion al usuario si desea regresar
        int opcion = JOptionPane.showConfirmDialog(    
            this,
            "¿Estás seguro de que deseas salir?\nLos datos ingresados se perderán.",
            "Confirmar salida",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        //Si si, se regresa a la ventana de inicio de sesion del admin
        if (opcion == JOptionPane.YES_OPTION) {
            desactivarTemporizador();
            InicioSesion nextFrame = new InicioSesion(banco);
            nextFrame.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_btnRegresar5ActionPerformed

    private void btnRegresar6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar6ActionPerformed
         //Pregunta la confirmacion al usuario si desea regresar
        int opcion = JOptionPane.showConfirmDialog(    
            this,
            "¿Estás seguro de que deseas salir?\nLos datos ingresados se perderán.",
            "Confirmar salida",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        //Si si, se regresa a la ventana de inicio de sesion del admin
        if (opcion == JOptionPane.YES_OPTION) {
            desactivarTemporizador();
            InicioSesion nextFrame = new InicioSesion(banco);
            nextFrame.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_btnRegresar6ActionPerformed

    private void btnRegresar7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar7ActionPerformed
         //Pregunta la confirmacion al usuario si desea regresar
        int opcion = JOptionPane.showConfirmDialog(    
            this,
            "¿Estás seguro de que deseas salir?\nLos datos ingresados se perderán.",
            "Confirmar salida",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        //Si si, se regresa a la ventana de inicio de sesion del admin
        if (opcion == JOptionPane.YES_OPTION) {
            desactivarTemporizador();
            InicioSesion nextFrame = new InicioSesion(banco);
            nextFrame.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_btnRegresar7ActionPerformed

    private void btnRegresar8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar8ActionPerformed
         //Pregunta la confirmacion al usuario si desea regresar
        int opcion = JOptionPane.showConfirmDialog(    
            this,
            "¿Estás seguro de que deseas salir?\nLos datos ingresados se perderán.",
            "Confirmar salida",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        //Si si, se regresa a la ventana de inicio de sesion del admin
        if (opcion == JOptionPane.YES_OPTION) {
            desactivarTemporizador();
            InicioSesion nextFrame = new InicioSesion(banco);
            nextFrame.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_btnRegresar8ActionPerformed

    private void btnRegresar9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar9ActionPerformed
        //Pregunta la confirmacion al usuario si desea regresar
        int opcion = JOptionPane.showConfirmDialog(    
            this,
            "¿Estás seguro de que deseas salir?\nLos datos ingresados se perderán.",
            "Confirmar salida",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        //Si si, se regresa a la ventana de inicio de sesion del admin
        if (opcion == JOptionPane.YES_OPTION) {
            desactivarTemporizador();
            InicioSesion nextFrame = new InicioSesion(banco);
            nextFrame.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_btnRegresar9ActionPerformed

    private void comboboxCuentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboboxCuentasActionPerformed
        // TODO add your handling code here:
        reiniciarTemporizador();
    }//GEN-LAST:event_comboboxCuentasActionPerformed

     private void inicializarTablaMovimientos() {
    // Configuración básica de la tabla
    DefaultTableModel modeloTabla = new DefaultTableModel(new Object[]{"ID", "Movimiento"}, 0);
    tblHistorial.setModel(modeloTabla);

    // Configurar el renderer para las celdas de texto
    tblHistorial.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, 
                                                       boolean isSelected, boolean hasFocus, 
                                                       int row, int column) {
            JLabel label = new JLabel("<html>" + value.toString().replace("\n", "<br>") + "</html>");
            if (isSelected) {
                label.setBackground(table.getSelectionBackground());
                label.setForeground(table.getSelectionForeground());
            } else {
                label.setBackground(table.getBackground());
                label.setForeground(table.getForeground());
            }
            return label;
        }
    });
    
    tblHistorial.setRowHeight(95); 
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UsuarioApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UsuarioApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UsuarioApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UsuarioApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane App;
    private javax.swing.JTabbedPane Consultas;
    private javax.swing.JPanel Contactos;
    private javax.swing.JPanel Cuenta;
    private javax.swing.JPanel Cuentas;
    private javax.swing.JPanel Historial;
    private javax.swing.JPanel Saldo;
    private javax.swing.JPanel Solicitudes;
    private javax.swing.JPanel Tarjeta;
    private javax.swing.JButton btnAgregarContacto;
    private javax.swing.JButton btnBuscarReporteSolicitud;
    private javax.swing.JButton btnBuscarReporteSolicitud1;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnRegresar3;
    private javax.swing.JButton btnRegresar4;
    private javax.swing.JButton btnRegresar5;
    private javax.swing.JButton btnRegresar6;
    private javax.swing.JButton btnRegresar7;
    private javax.swing.JButton btnRegresar8;
    private javax.swing.JButton btnRegresar9;
    private javax.swing.JButton btnTransferir;
    private javax.swing.JComboBox<String> comboboxCuentas;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JTable tblContactos;
    private javax.swing.JTable tblContactos1;
    private javax.swing.JTable tblCuentas;
    private javax.swing.JTable tblCuentas1;
    private javax.swing.JTable tblHistorial;
    private javax.swing.JTable tblReporteSolicitud;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtClave;
    private javax.swing.JTextField txtClaveInterbancaria1;
    private javax.swing.JTextField txtClaveTransferencia;
    private javax.swing.JTextField txtCuentaContacto;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNombreContacto;
    private javax.swing.JTextField txtNumeroCuenta;
    private javax.swing.JTextArea txtReporte;
    private javax.swing.JTextField txtSaldo;
    private javax.swing.JTextField txtUsuarioCorreo;
    private javax.swing.JTextField txtUsuarioCuenta;
    private javax.swing.JTextField txtnip;
    // End of variables declaration//GEN-END:variables
}
